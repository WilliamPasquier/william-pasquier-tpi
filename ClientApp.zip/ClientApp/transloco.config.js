import { paths } from '@appConstants/path';
import { availableLangs } from '@models/locale.model';

module.exports = {
    rootTranslationsPath: paths.public.i18n,
    langs: availableLangs,
    keysManager: {},
};
