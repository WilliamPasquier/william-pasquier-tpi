import { NgModule } from '@angular/core';
import {
    provideRouter,
    withDebugTracing,
    withHashLocation,
} from '@angular/router';
import { routes } from './config/app-routing.config';

/**
 * Module to manage routes at the app level.
 * As the app will be wrapped in a Sitefinity page, we use hash routing.
 */
@NgModule({
    providers: [provideRouter(routes, withDebugTracing(), withHashLocation())],
})
export class AppRoutingModule {}
