import { RouterTestingModule } from '@angular/router/testing';
import { MockBuilder } from 'ng-mocks';

import { DamageClaimComponent } from '@features/damage-claim/damage-claim.component';
import { damageClaimRootFragment } from '@features/damage-claim/config/route.builder';
import { routes } from './app-routing.config';
import { Router} from '@angular/router';
import { TestBed, fakeAsync, tick } from '@angular/core/testing';
import { Location } from '@angular/common';

describe('Router: App', () => {
    let router: Router;
    let location: Location;

  beforeEach(() => {
    return MockBuilder()
      .keep(RouterTestingModule.withRoutes(routes))
  });

  beforeEach(() => {
    router = TestBed.inject(Router);
    location = TestBed.inject(Location);
    router.initialNavigation();
  });

  it('should have a route for damage claims', () => {
    const route = routes.find(r => r.path === damageClaimRootFragment);
    expect(route).toBeTruthy();
    expect(route?.component).toBe(DamageClaimComponent);
  });

  it('should redirect to "/" when navigating to ""', fakeAsync(() => {
    router.navigate(['']);
    tick();
    expect(location.path()).toBe('/');
  }));


});
