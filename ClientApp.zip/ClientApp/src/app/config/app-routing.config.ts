import { Routes } from '@angular/router';
import { damageClaimRootFragment } from '@features/damage-claim/config/route.builder';
import { DamageClaimComponent } from '@features/damage-claim/damage-claim.component';
import {
    confirmationPageFragment,
    thirdPartyLiabilityRootFragment,
} from '@features/third-party-liability/config/route.builder';
import { LiabilityConfirmationPageComponent } from '@features/third-party-liability/liability-confirmation-page/liability-confirmation-page.component';
import { ThirdPartyLiabilityComponent } from '@features/third-party-liability/third-party-liability.component';

/**
 * List all routes available at the app level
 */
export const routes: Routes = [
    {
        path: damageClaimRootFragment,
        component: DamageClaimComponent,
    },
    {
        path: thirdPartyLiabilityRootFragment,
        component: ThirdPartyLiabilityComponent,
    },
    {
        path: confirmationPageFragment,
        component: LiabilityConfirmationPageComponent,
    }
];
