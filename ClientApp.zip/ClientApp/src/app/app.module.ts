import { BrowserModule } from '@angular/platform-browser';
import { AppComponent } from './app.component';
import { CoreModule } from '@core/core.module';
import { SharedModule } from '@shared/shared.module';
import { AppRoutingModule } from './app-routing.module';
import { DamageClaimModule } from '@features/damage-claim/damage-claim.module';
import { NgModule } from '@angular/core';
import { ThirdPartyLiabilityModule } from '@features/third-party-liability/third-party-liability.module';

/**
 * We launch our applications by bootstrapping the App module.
 * We want to keep our App Module pretty compact. There should not be a lot of content in the App Module or App Component.
 * We want to encapsulate our application into domain-specific modules, the Core Module, & the Shared Module.
 * https://thetombomb.com/posts/app-core-shared-feature-modules
 */
@NgModule({
    declarations: [AppComponent],
    imports: [
        BrowserModule,
        CoreModule,
        SharedModule,
        DamageClaimModule,
        ThirdPartyLiabilityModule,
        AppRoutingModule,
    ],
    bootstrap: [AppComponent],
})
export class AppModule {}
