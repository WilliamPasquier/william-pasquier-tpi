import { LiabilityDeclarerGender } from './liability-declarer-gender.enum';

/**
 * The declarer contact information.
 */
export interface LiabilityDeclarerContact {
    /**
     * The property management name.
     */
    propertyManagementName: string;

    /**
     * The gender.
     */
    gender?: LiabilityDeclarerGender | null;

    /**
     * The first name.
     */
    firstName: string;

    /**
     * The last name.
     */
    lastName: string;

    /**
     * The birthdate.
     */
    birthdate?: string | null;

    /**
     * The phone number.
     */
    phoneNumber: string;

    /**
     * The email.
     */
    email: string;

    /**
     * Country of Holder contact.
     */
    country: string | null;

    /**
     * Postal code of Holder contact.
     */
    postalCode: number | null;

    /**
     * Locality of Holder contact.
     */
    locality: string | null;

    /**
     * Street of Holder contact.
     */
    street: string | null;

    /**
     * The legal protection.
     */
    legalProtection: string | null;
}
