/**
 * Enum for the types of damage.
 */
export const enum DamageType {
    FireDamage = 'fireDamage',
    Theft = 'theft',
    NaturalEvent = 'naturalEvent',
    WaterDamage = 'waterDamage',
    GlassBreakage = 'glassBreakage',
    InfrastructureDamage = 'infrastructureDamage',
    Other = 'other',
}
