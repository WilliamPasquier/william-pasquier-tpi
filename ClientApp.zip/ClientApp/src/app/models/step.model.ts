import { DamageClaimFormGroup } from './form-groups/damage-claim-form-group.model';

/**
 * Represents a form step that can group several other child form group
 */
export interface Step {
    /**
     * The code identifier for the step.
     */
    code: string;

    /**
     * The route path to redirect to show this step.
     */
    routePath?: string;

    /**
     * The formGroup name related to the step.
     */
    formGroupName: keyof DamageClaimFormGroup;
}
