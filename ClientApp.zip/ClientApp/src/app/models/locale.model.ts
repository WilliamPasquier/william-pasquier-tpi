/**
 * The list of available languages for the app
 * This list needs to be synced with the transloco.config.js file
 */
export const langs = {
    fr: 'fr',
    de: 'de',
    it: 'it',
} as const;

/**
 * The default language of the app
 */
export const defaultLang = langs.fr;

/**
 * Array of available language for the app
 */
export const availableLangs = Object.values(langs);

/**
 * The type for the key of the lang enum
 */
type LangKey = keyof typeof langs;

/**
 * The type for the lang enum's values
 */
export type Lang = (typeof langs)[LangKey];
