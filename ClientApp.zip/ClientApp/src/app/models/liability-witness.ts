/**
 * Third party liability Witness.
 */
export interface LiabilityWitness {
    /**
     * last name.
     */
    lastName: string | null;

    /**
     * first name.
     */
    firstName: string | null;

    /**
     * phone number.
     */
    phoneNumber: string | null;

    /**
     * email.
     */
    email: string | null;
}
