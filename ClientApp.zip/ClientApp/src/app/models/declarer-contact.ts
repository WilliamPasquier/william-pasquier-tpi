export interface DeclarerContact {
    firstName: string;
    lastName: string;
    phoneNumber: string | null;
    email: string;
}
