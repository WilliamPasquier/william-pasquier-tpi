export interface InventoryDamage {
    objectDescription: string | null;
    objectPrice: string | null;
    objectRepairCost: string | null;
    objectRemarks: string | null;
}
