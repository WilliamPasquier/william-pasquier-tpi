/**
 * Enum for the gender of declarer.
 */
export const enum LiabilityDeclarerGender {
    Mr = 'Monsieur',
    Mrs = 'Madame',
}
