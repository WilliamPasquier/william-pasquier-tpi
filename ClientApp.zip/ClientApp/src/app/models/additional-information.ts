export interface AdditionalInformation {
    hasOtherInsurer: boolean | null;
    otherInsurerName: string | null;
    isOtherInsurerInformed: boolean | null;
    thirdPartyResponsibility: string | null;
    thirdPartyFirstName: string | null;
    thirdPartyLastName: string | null;
    thirdPartyStreet: string | null;
    thirdPartyPostalCode: string | null;
    thirdPartyLocality: string | null;
    thirdPartyCountry: string | null;
    hasPoliceIncidentReport: boolean | null;
    hasEmergencyMeasures: boolean | null;
    shouldOrganizeDamagesRepair: boolean | null;
    emergencyMeasuresDescription: string | null;
    otherRemarks: string | null;
}
