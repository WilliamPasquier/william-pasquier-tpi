import { LiabilityDamageType } from './liability-damage-type.enum';
import { LiabilityInjuredParty } from './liability-injured-party';

export interface LiabilityDamageDescription {
    /**
     * damage type field.
     */
    damageType: Array<LiabilityDamageType>;

    /**
     * injured party.
     */
    injuredParty?: LiabilityInjuredParty | null;

    /**
     * insured injured party relationship field.
     */
    insuredInjuredPartyRelationship: string | null;

    /**
     * damage object type field.
     */
    damagedObjectType: string | null;

    /**
     * repair cost field.
     */
    repairCost: string | null;

    /**
     * property management name field.
     */
    propertyManagementName: string | null;

    /**
     * animal type field.
     */
    animalType: string | null;

    /**
     * injuries type field.
     */
    injuriesType: string | null;

    /**
     * accident insurer field.
     */
    accidentInsurer: string | null;

    /**
     * work incapacity field.
     */
    hasWorkIncapacity: boolean | null;

    /**
     * occupation field.
     */
    occupation: string | null;

    /**
     * employer field.
     */
    employer: string | null;
}
