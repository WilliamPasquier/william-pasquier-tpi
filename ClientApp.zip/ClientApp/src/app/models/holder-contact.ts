export interface HolderContact {
    contractNumber: string | null;
    lastName: string | null;
    firstName: string | null;
    birthdate: Date | null;
    phoneNumber: string | null;
    email: string | null;
    country: string | null;
    postalCode: number | null;
    locality: string | null;
    street: string | null;
    iban: string | null;
}
