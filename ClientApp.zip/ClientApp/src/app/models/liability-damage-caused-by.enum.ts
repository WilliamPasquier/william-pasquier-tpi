/**
 * Enum for the cause of damage.
 */
export const enum LiabilityDamageCausedBy {
    AnimalDamage = 'animalDamage',
    Human = 'human',
    Building = 'building',
}
