/**
 * Enum for the types of damage.
 */
export const enum LiabilityDamageType {
    PropertyDamage = 'propertyDamage',
    CorporalInjury = 'corporalInjury',
    AnimalDamage = 'animalDamage',
    RentedPremisesDamage = 'rentedPremisesDamage',
}
