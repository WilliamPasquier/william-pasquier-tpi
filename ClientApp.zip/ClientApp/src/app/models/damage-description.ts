import { InventoryDamage } from '@models/inventory-damage';

export interface DamageDescription {
    buildingDamageDescription: string | null;
    inventoryDamages: Array<InventoryDamage> | null;
}
