/**
 * Enum for the types of declarer.
 */
export const enum DeclarerType {
    Policyholder = 'policyholder',
    Advisor = 'advisor',
    Broker = 'broker',
}
