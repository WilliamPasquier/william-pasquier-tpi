/**
 * Enum for the types of declarer.
 */
export const enum LiabilityDeclarerType {
    Policyholder = 'policyholder',
    PropertyManagement = 'propertyManagement',
    Advisor = 'advisor',
    InjuredParty = 'injuredParty',
}
