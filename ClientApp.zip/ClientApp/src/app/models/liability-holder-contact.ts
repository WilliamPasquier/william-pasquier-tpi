export interface LiabilityHolderContact {
    /**
     * Last name of Holder contact.
     */
    lastName: string | null;

    /**
     * First name of Holder contact.
     */
    firstName: string | null;

    /**
     * birthdate of Holder contact.
     */
    birthdate: string | null;

    /**
     * Phone number of Holder contact.
     */
    phoneNumber: string | null;

    /**
     * Email of Holder contact.
     */
    email: string | null;

    /**
     * Country of Holder contact.
     */
    country: string | null;

    /**
     * Postal code of Holder contact.
     */
    postalCode: number | null;

    /**
     * Locality of Holder contact.
     */
    locality: string | null;

    /**
     * Street of Holder contact.
     */
    street: string | null;

    /**
     * Contract number of Holder contact
     */
    contractNumber: string | null;

    /**
     * Iban of Holder contact.
     */
    iban: string | null;

    /**
     * Legal protection of Holder contact.
     */
    legalProtection: string | null;
}
