import { LiabilityResponsible } from './liability-responsible';
import { LiabilityWitness } from './liability-witness';

/**
 * The third-party liability event description.
 */
export interface LiabilityEventDescription {
    /**
     * The occurence date.
     */
    occurrenceDate: string;

    /**
     * The occurence time.
     */
    occurrenceTime: string | null;

    /**
     * The occurence place.
     */
    occurrencePlace: string;

    /**
     * The circumstances.
     */
    circumstances: string;

    /**
     * The police report availability: true when available, false otherwise.
     */
    hasPoliceReport: boolean | null;

    /**
     * The insured responsible status: true when responsible, false otherwise.
     */
    isInsuredResponsible: boolean | null;

    /**
     * The third-party responsibility status: true when responsible, false otherwise.
     */
    isThirdPartyResponsible: boolean | null;

    /**
     * The third-party responsible when isThirdPartyResponsible is true.
     */
    thirdPartyResponsible?: LiabilityResponsible | null;

    /**
     * The witnesses availability status: true when there are witnesses, false otherwise.
     */
    hasWitness: boolean;

    /**
     * The witnesses when hasWitness is true.
     */
    witnesses?: Array<LiabilityWitness> | null;
}
