import { DeclarerType } from './declarer-type.enum';

export interface DeclarerContact {
    firstName: string;
    lastName: string;
}

export interface HolderContact {
    firstName: string;
    lastName: string;
}

export interface Declarer {
    declarerType: DeclarerType;
    declarerContact: DeclarerContact;
    holderContact: HolderContact;
}
