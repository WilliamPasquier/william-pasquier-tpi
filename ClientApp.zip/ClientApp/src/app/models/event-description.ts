export interface EventDescription {
    occurrenceDate: string | null;
    occurrenceTime: string | null;
    occurrencePlace: string | null;
    circumstances: string | null;
}
