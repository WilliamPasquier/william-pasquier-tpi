import { LiabilityDeclarerGender } from "./liability-declarer-gender.enum";

/**
 * The third-party liability responsible.
 */
export interface LiabilityResponsible {
    /**
     * The last name.
     */
    lastName: string | null;

    /**
     * The first name.
     */
    firstName: string | null;

    /**
     * The insurer name.
     */
    liabilityInsurerName: string | null;

    /**
     * The phone number.
     */
    phoneNumber: string | null;

    /**
     * The email.
     */
    email: string | null;

    /**
     * The gender.
     */
    gender?: LiabilityDeclarerGender | null;
}
