import { DeclarerType } from '@models/declarer-type.enum';
import { DamageType } from '@models/damage-type.enum';
import { DeclarerContact } from '@models//declarer-contact';
import { HolderContact } from '@models//holder-contact';
import { EventDescription } from '@models//event-description';
import { DamageDescription } from '@models//damage-description';
import { AdditionalInformation } from './additional-information';

export interface Claim {
    declarerType: DeclarerType | null;
    declarerContact: DeclarerContact | null;
    holderContact: HolderContact | null;
    event: EventDescription | null;
    damageType: DamageType | null;
    otherDamageType: string | null;
    damages: DamageDescription | null;
    additionalInformation: AdditionalInformation | null;
    reCaptcha: string | null;
}
