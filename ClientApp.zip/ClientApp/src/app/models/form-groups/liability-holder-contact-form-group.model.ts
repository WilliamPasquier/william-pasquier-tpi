import { FormControl } from '@angular/forms';

/**
 * Damage claim holder contact form group.
 */
export interface LiabilityHolderContactFormGroup {
    /**
     * Last name control.
     */
    lastName: FormControl<string>;

    /**
     * First name control.
     */
    firstName: FormControl<string>;

    /**
     * Birthdate control.
     */
    birthdate: FormControl<string>;

    /**
     * Phone number control.
     */
    phoneNumber: FormControl<string>;

    /**
     * Email control.
     */
    email: FormControl<string>;

    /**
     * Country control.
     */
    country: FormControl<string>;

    /**
     * Postal code control.
     */
    postalCode: FormControl<number | null>;

    /**
     * Locality control.
     */
    locality: FormControl<string>;

    /**
     * Street code control.
     */
    street: FormControl<string>;

    /**
     * Contract number control.
     */
    contractNumber: FormControl<string>;

    /**
     * Iban code control.
     */
    iban: FormControl<string>;

    /**
     * Legal protection
     */
    legalProtection: FormControl<string>;
}
