import { FormArray, FormGroup } from '@angular/forms';
import { InventoryDamageTypeFormGroup } from './inventory-damage-type-form-group.model';

/**
 * Claim damage inventory damage form group.
 */
export interface InventoryDamageFormGroup {
    /**
     * List of inventory damaged objects form groups.
     */
    inventoryDamages: FormArray<FormGroup<InventoryDamageTypeFormGroup>>;
}
