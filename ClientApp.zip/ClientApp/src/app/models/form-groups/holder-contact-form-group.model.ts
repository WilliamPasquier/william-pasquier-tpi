import { FormControl } from '@angular/forms';

/**
 * Damage claim holder contact form group.
 */
export interface HolderContactFormGroup {
    /**
     * Last name control.
     */
    lastName: FormControl<string | null>;

    /**
     * First name control.
     */
    firstName: FormControl<string | null>;

    /**
     * Birthdate control.
     */
    birthdate: FormControl<Date | null>;

    /**
     * Phone number control.
     */
    phoneNumber: FormControl<string | null>;

    /**
     * Email control.
     */
    email: FormControl<string | null>;

    /**
     * Country control.
     */
    country: FormControl<string | null>;

    /**
     * Postal code control.
     */
    postalCode: FormControl<number | null>;

    /**
     * Locality control.
     */
    locality: FormControl<string | null>;

    /**
     * Street code control.
     */
    street: FormControl<string | null>;

    /**
     * Contract number control.
     */
    contractNumber: FormControl<string | null>;

    /**
     * Iban code control.
     */
    iban: FormControl<string | null>;
}
