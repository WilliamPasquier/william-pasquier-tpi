import { FormControl, FormGroup } from '@angular/forms';
import { LiabilityDamageCausedBy } from '@models/liability-damage-caused-by.enum';
import { LiabilityDamageDescriptionFormGroup } from './liability-damage-description-form-group.model';
import { LiabilityEventDescriptionFormGroup } from './liability-event-description-form-group.model';

/**
 * Third party liability damage event step form group.
 */
export interface LiabilityDamageEventStepFormGroup {
    /**
     * Reactive form control for damage cause by field.
     */
    damageCausedBy: FormControl<LiabilityDamageCausedBy | null>;

    /**
     * Event description form group.
     */
    eventDescription?: FormGroup<LiabilityEventDescriptionFormGroup>;

    /**
     * Liability damage description formGroup.
     */
    damageDescription?: FormGroup<LiabilityDamageDescriptionFormGroup>;
}
