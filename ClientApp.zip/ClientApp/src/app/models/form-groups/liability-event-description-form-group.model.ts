import { FormArray, FormControl, FormGroup } from '@angular/forms';
import { LiabilityWitnessFormGroup } from './liability-witness-form-group.model';
import { LiabilityDeclarerGender } from '@models/liability-declarer-gender.enum';

/**
 * Damage claim event descripton form group.
 */
export interface LiabilityEventDescriptionFormGroup {
    /**
     * Occurrence date control.
     */
    occurrenceDate: FormControl<string>;

    /**
     * Occurrence time control.
     */
    occurrenceTime: FormControl<string | null>;

    /**
     * Occurrence place control.
     */
    occurrencePlace: FormControl<string>;

    /**
     * Circumstances control.
     */
    circumstances: FormControl<string>;

    /**
     * Has police report control.
     */
    hasPoliceReport: FormControl<boolean | null>;

    /**
     * Is Insured responsible control.
     */
    isInsuredResponsible: FormControl<boolean | null>;

    /**
     * Is third party responsible control.
     */
    isThirdPartyResponsible: FormControl<boolean | null>;

    /**
     * Responsible last name control.
     */
    responsibleLastName: FormControl<string | null>;

    /**
     * Responsible first name control.
     */
    responsibleFirstName: FormControl<string | null>;

    /**
     * Liability responsible insurer name control.
     */
    responsibleLiabilityInsurerName: FormControl<string | null>;

    /**
     * Responsible phone number control.
     */
    responsiblePhoneNumber: FormControl<string | null>;

    /**
     * Responsible email control.
     */
    responsibleEmail: FormControl<string | null>;

    /**
     * The responsible gender form control.
     */
    responsibleGender?: FormControl<LiabilityDeclarerGender | null>;

    /**
     * Has witnesses control.
     */
    hasWitness: FormControl<boolean | null>;

    /**
     * Witnesses group.
     */
    witnesses?: FormArray<FormGroup<LiabilityWitnessFormGroup>>;
}
