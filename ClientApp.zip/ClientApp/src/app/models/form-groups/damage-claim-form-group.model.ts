import { FormArray, FormControl, FormGroup } from '@angular/forms';
import { AdditionalInformationFormGroup } from './additional-information-form-group.model';
import { DamageEventStepFormGroup } from './damage-event-step-form-group.model';
import { InsuranceHolderStepFormGroup } from './insurance-holder-step-form-group.model';

/**
 * Damage claims form group.
 */
export interface DamageClaimFormGroup {
    /**
     * Represents the current step code.
     */
    currentStep: FormControl<string | null>;

    /**
     * Recaptcha value.
     */
    recaptcha: FormControl<string | null>;

    /**
     * Insurance holder step form group.
     */
    insuranceHolder?: FormGroup<InsuranceHolderStepFormGroup>;

    /**
     * damage event step form group.
     */
    damageEvent?: FormGroup<DamageEventStepFormGroup>;

    /**
     * damage additional information step form group.
     */
    additionalInformation?: FormGroup<AdditionalInformationFormGroup>;

    /**
     * List of uploaded files.
     */
    files: FormArray<FormControl<File>>;
}
