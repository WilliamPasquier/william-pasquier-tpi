import { FormControl } from '@angular/forms';

/**
 * Claim damage inventory damage types form group.
 */
export interface InventoryDamageTypeFormGroup {
    /**
     * Damaged object description.
     */
    objectDescription: FormControl<string | null>;

    /**
     * Damaged object acquisition price.
     */
    objectPrice: FormControl<string | null>;

    /**
     * Damaged object repair cost.
     */
    objectRepairCost: FormControl<string | null>;

    /**
     * Damaged object remarks.
     */
    objectRemarks: FormControl<string | null>;
}
