import { FormControl } from '@angular/forms';

/**
 * Damage additional information form group.
 */
export interface AdditionalInformationFormGroup {
    /**
     * Has other insurer control.
     */
    hasOtherInsurer: FormControl<boolean | null>;

    /**
     * Other insurer name control.
     */
    otherInsurerName: FormControl<string | null>;

    /**
     * Is other insurer informed control.
     */
    isOtherInsurerInformed: FormControl<boolean | null>;

    /**
     * Third party responsibility control.
     */
    thirdPartyResponsibility: FormControl<string | null>;

    /**
     * Third party last name control.
     */
    thirdPartyLastName: FormControl<string | null>;

    /**
     * Third party first name control.
     */
    thirdPartyFirstName: FormControl<string | null>;

    /**
     * Third party country control.
     */
    thirdPartyCountry: FormControl<string | null>;

    /**
     * Third party locality control.
     */
    thirdPartyLocality: FormControl<string | null>;

    /**
     * Third party postal code control.
     */
    thirdPartyPostalCode: FormControl<string | null>;

    /**
     * Third party street control.
     */
    thirdPartyStreet: FormControl<string | null>;

    /**
     * Has police incident report control.
     */
    hasPoliceIncidentReport: FormControl<boolean | null>;

    /**
     * Has emergency measures control.
     */
    hasEmergencyMeasures: FormControl<boolean | null>;

    /**
     * Indicates whether Vaudoise should or not organize damages repair.
     */
    shouldOrganizeDamagesRepair: FormControl<boolean | null>;

    /**
     * Emergency measures Description control.
     */
    emergencyMeasuresDescription: FormControl<string | null>;

    /**
     * Other remarks control.
     */
    otherRemarks: FormControl<string | null>;
}
