import { FormControl, FormGroup } from '@angular/forms';
import { DeclarerType } from '@models/declarer-type.enum';
import { DeclarerContactFormGroup } from './declarer-contact-form-group.model';
import { HolderContactFormGroup } from './holder-contact-form-group.model';

/**
 * Damage claims insurance holder step form group.
 */
export interface InsuranceHolderStepFormGroup {
    /**
     * Reactive form control for declarer type field.
     */
    declarerType: FormControl<DeclarerType | null>;

    /**
     * Declarer contact form group.
     */
    declarerContact: FormGroup<DeclarerContactFormGroup>;

    /**
     * Holder contact form group.
     */
    holderContact: FormGroup<HolderContactFormGroup>;
}
