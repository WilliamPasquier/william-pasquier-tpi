import { FormControl } from '@angular/forms';

/**
 * Third party liability Damage additional information form group.
 */
export interface LiabilityAdditionalInformationFormGroup {
    /**
     * Has relation with another domestic accident.
     */
    isRelatedToAnotherDomesticAccident: FormControl<boolean | null>;

    /**
     * Domestic claim number
     */
    domesticClaimNumber: FormControl<string | null>;

    /**
     * Other remarks control.
     */
    otherRemarks: FormControl<string | null>;
}
