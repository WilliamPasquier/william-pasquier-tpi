import { FormControl } from '@angular/forms';

/**
 * Damage claims declarer contact form group.
 */
export interface DeclarerContactFormGroup {
    /**
     * The last name form control.
     */
    lastName: FormControl<string>;

    /**
     * The first name form control.
     */
    firstName: FormControl<string>;

    /**
     * The phone number form control.
     */
    phoneNumber: FormControl<string | null>;

    /**
     * The email form control.
     */
    email: FormControl<string>;
}
