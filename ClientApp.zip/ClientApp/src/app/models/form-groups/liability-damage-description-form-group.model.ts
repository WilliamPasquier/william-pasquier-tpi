import { FormControl, FormGroup } from '@angular/forms';
import { LiabilityDamageType } from '@models/liability-damage-type.enum';
import { LiabilityInjuredPartyFormGroup } from './liability-injured-party-form-group';

/**
 * Damage claim damages description form group.
 */
export interface LiabilityDamageDescriptionFormGroup {
    /**
     * Reactive form array for damage type field.
     */
    damageType: FormControl<Array<LiabilityDamageType>>;

    /**
     * Reactive form group for injured party.
     */
    injuredParty?: FormGroup<LiabilityInjuredPartyFormGroup>;

    /**
     * Reactive form control for insured injured party relationship field.
     */
    insuredInjuredPartyRelationship: FormControl<string | null>;

    /**
     * Reactive form control for damage object type field.
     */
    damagedObjectType: FormControl<string | null>;

    /**
     * Reactive form control for repair cost field.
     */
    repairCost: FormControl<string | null>;

    /**
     * Reactive form control for property management name field.
     */
    propertyManagementName: FormControl<string | null>;

    /**
     * Reactive form control for animal type field.
     */
    animalType: FormControl<string | null>;

    /**
     * Reactive form control for injuries type field.
     */
    injuriesType: FormControl<string | null>;

    /**
     * Reactive form control for accident insurer field.
     */
    accidentInsurer: FormControl<string | null>;

    /**
     * Reactive form control for work incapacity field.
     */
    hasWorkIncapacity: FormControl<boolean | null>;

    /**
     * Reactive form control for occupation field.
     */
    occupation: FormControl<string | null>;

    /**
     * Reactive form control for employer field.
     */
    employer: FormControl<string | null>;
}
