import { FormControl, FormGroup } from '@angular/forms';
import { LiabilityDeclarerType } from '@models/liability-declarer-type.enum';
import { LiabilityDeclarerContactFormGroup } from './liability-declarer-contact-form-group.model';
import { LiabilityHolderContactFormGroup } from './liability-holder-contact-form-group.model';

/**
 * Third party liability insurance holder step form group.
 */
export interface LiabilityInsuranceHolderStepFormGroup {
    /**
     * Reactive form control for declarer type field.
     */
    declarerType: FormControl<LiabilityDeclarerType | null>;

    /**
     * Declarer contact form group.
     */
    declarerContact?: FormGroup<LiabilityDeclarerContactFormGroup>;

    /**
     * Holder contact form group.
     */
    holderContact?: FormGroup<LiabilityHolderContactFormGroup>;
}
