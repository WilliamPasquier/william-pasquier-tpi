import { FormControl, FormGroup } from '@angular/forms';
import { LiabilityAdditionalInformationFormGroup } from './liability-additional-information-form-group.model';
import { LiabilityDamageEventStepFormGroup } from './liability-damage-event-step-form-group.model';
import { LiabilityInsuranceHolderStepFormGroup } from './liability-insurance-holder-step-form-group.model';

/**
 * Liability Damage claims form group.
 */
export interface LiabilityDamageClaimFormGroup {
    /**
     * Recaptcha value.
     */
    recaptcha: FormControl<string | null>;

    /**
     * Insurance holder step form group.
     */
    insuranceHolder?: FormGroup<LiabilityInsuranceHolderStepFormGroup>;

    /**
     * Third party liability damage event step form group.
     */
    damageEvent?: FormGroup<LiabilityDamageEventStepFormGroup>;

    /**
     * Liability additional info.
     */
    additionalInfo?: FormGroup<LiabilityAdditionalInformationFormGroup>;
}
