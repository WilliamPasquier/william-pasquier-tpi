import { FormControl, FormGroup } from '@angular/forms';
import { DamageType } from '@models/damage-type.enum';
import { DamageDescriptionFormGroup } from './damage-description-form-group.model';
import { EventDescriptionFormGroup } from './event-description-form-group.model';

/**
 * Damage claim damage event step form group.
 */
export interface DamageEventStepFormGroup {
    /**
     * Reactive form control for damage type field.
     */
    damageType: FormControl<DamageType | null>;

    /**
     * Reactive form control for other damage type field.
     */
    otherDamageType: FormControl<string | null>;

    /**
     * Damage description form group.
     */
    damageDescription: FormGroup<DamageDescriptionFormGroup>;

    /**
     * Event description form group.
     */
    eventDescription: FormGroup<EventDescriptionFormGroup>;
}
