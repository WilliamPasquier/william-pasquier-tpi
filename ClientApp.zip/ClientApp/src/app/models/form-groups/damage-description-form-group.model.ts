import { FormControl, FormGroup } from '@angular/forms';
import { InventoryDamageFormGroup } from './inventory-damage-form-group.model';

/**
 * Damage claim damages description form group.
 */
export interface DamageDescriptionFormGroup {
    /**
     * Reactive form control to verify if an object has damage.
     */
    hasInventoryDamage: FormControl<boolean | null>;

    /**
     * Reactive form control to verify if the building has damage.
     */
    hasBuildingDamage: FormControl<boolean | null>;

    /**
     * Object remarks form control
     */
    buildingDamageDescription: FormControl<string | null>;

    /**
     * Inventory damage form group
     */
    inventoryDamage: FormGroup<InventoryDamageFormGroup>;
}
