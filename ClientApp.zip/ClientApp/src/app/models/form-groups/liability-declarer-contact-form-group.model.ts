import { FormControl } from '@angular/forms';
import { LiabilityDeclarerGender } from '@models/liability-declarer-gender.enum';

/**
 * Third part liability declarer contact form group.
 */
export interface LiabilityDeclarerContactFormGroup {
    /**
     * The property management name form control.
     */
    propertyManagementName: FormControl<string>;

    /**
     * The gender for control.
     */
    gender?: FormControl<LiabilityDeclarerGender | null>;

    /**
     * The last name form control.
     */
    lastName: FormControl<string>;

    /**
     * The first name form control.
     */
    firstName: FormControl<string>;

    /**
     * The birthdate form control.
     */
    birthdate?: FormControl<string | null>;

    /**
     * The phone number form control.
     */
    phoneNumber: FormControl<string>;

    /**
     * The email form control.
     */
    email: FormControl<string>;

    /**
     * Country control.
     */
    country: FormControl<string>;

    /**
     * Postal code control.
     */
    postalCode: FormControl<number | null>;

    /**
     * Locality control.
     */
    locality: FormControl<string>;

    /**
     * Street code control.
     */
    street: FormControl<string>;

    /**
     * The legal protection form control.
     */
    legalProtection: FormControl<string | null>;
}
