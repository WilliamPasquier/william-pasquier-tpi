import { FormControl } from '@angular/forms';

/**
 * Damage claim event descripton form group.
 */
export interface EventDescriptionFormGroup {
    /**
     * Occurrence date control.
     */
    occurrenceDate: FormControl<string | null>;

    /**
     * Occurrence time control.
     */
    occurrenceTime: FormControl<string | null>;

    /**
     * Occurrence place control.
     */
    occurrencePlace: FormControl<string | null>;

    /**
     * Circumstances control.
     */
    circumstances: FormControl<string | null>;
}
