import { FormControl } from '@angular/forms';

export interface LiabilityInjuredPartyFormGroup {
    /**
     * The last name form control.
     */
    lastName: FormControl<string | null>;

    /**
     * The first name form control.
     */
    firstName: FormControl<string | null>;

    /**
     * The birthdate form control.
     */
    birthdate: FormControl<string | null>;

    /**
     * The phone number form control.
     */
    phoneNumber: FormControl<string | null>;

    /**
     * The email form control.
     */
    email: FormControl<string | null>;

    /**
     * The country form control.
     */
    country: FormControl<string | null>;

    /**
     * The post code form control.
     */
    postalCode: FormControl<number | null>;

    /**
     * The locality form control.
     */
    locality: FormControl<string | null>;

    /**
     * The street form control.
     */
    street: FormControl<string | null>;
}
