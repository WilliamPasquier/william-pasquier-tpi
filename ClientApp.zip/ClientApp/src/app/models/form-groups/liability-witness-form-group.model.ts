import { FormControl } from '@angular/forms';

/**
 * Liability Witness form group.
 */
export interface LiabilityWitnessFormGroup {
    /**
     * last name control.
     */
    lastName: FormControl<string | null>;

    /**
     * first name control.
     */
    firstName: FormControl<string | null>;

    /**
     * phone number control.
     */
    phoneNumber: FormControl<string | null>;

    /**
     * email control.
     */
    email: FormControl<string | null>;
}
