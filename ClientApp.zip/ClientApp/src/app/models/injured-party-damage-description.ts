export interface InjuredPartyDamageDescription {
    /**
     * Last name of Injured party.
     */
    lastName: string;

    /**
     * First name of Injured party.
     */
    firstName: string;

    /**
     * Birthdate of Injured party.
     */
    birthdate: string | null;

    /**
     * Phone number of Injured party.
     */
    phoneNumber: string | null;

    /**
     * Email of Injured party.
     */
    email: string | null;

    /**
     * Country of Injured party.
     */
    country: string;

    /**
     * Postal code of Injured party.
     */
    postalCode: number;

    /**
     * Locality of Injured party.
     */
    locality: string;

    /**
     * Street of Injured party.
     */
    street: string;
}
