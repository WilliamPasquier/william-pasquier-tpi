/**
 * Enum for the controls with yes/no/maybe options.
 */
export const enum OptionsYesNoMaybe {
    Yes = 'yes',
    No = 'no',
    Maybe = 'maybe',
}
