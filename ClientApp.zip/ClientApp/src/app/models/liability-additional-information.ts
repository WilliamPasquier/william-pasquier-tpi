/**
 * Interface for the Additional informations at the end of the form.
 */
export interface LiabilityAdditionalInformation {
    /**
     * To know if the event is related to another household claim.
     */
    isRelatedToAnotherDomesticAccident: boolean | null;

    /**
     * It is the household claim number
     */
    domesticClaimNumber: string | null;

    /**
     * For further information
     */
    otherRemarks: string | null;
}
