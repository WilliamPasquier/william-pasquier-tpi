import { LiabilityAdditionalInformation } from './liability-additional-information';
import { LiabilityDamageCausedBy } from './liability-damage-caused-by.enum';
import { LiabilityDamageDescription } from './liability-damage-description';
import { LiabilityDeclarerContact } from './liability-declarer-contact';
import { LiabilityDeclarerType } from './liability-declarer-type.enum';
import { LiabilityEventDescription } from './liability-event-description';
import { LiabilityHolderContact } from './liability-holder-contact';

/**
 * The claim for third party liability.
 */
export interface LiabilityClaim {
    /**
     * The declarer type.
     */
    declarerType: LiabilityDeclarerType | null;

    /**
     * The declarer contact.
     */
    declarerContact?: LiabilityDeclarerContact | null;

    /**
     * The holder contact.
     */
    holderContact: LiabilityHolderContact;

    /**
     * Damage caused by.
     */
    damageCausedBy: LiabilityDamageCausedBy | null;

    /**
     * Event description.
     */
    eventDescription: LiabilityEventDescription | null;

    /**
     * Liability damage description.
     */
    damageDescription: LiabilityDamageDescription;

    /**
     * Liability additional info.
     */
    additionalInfo: LiabilityAdditionalInformation | null;

    /**
     * The reCaptcha response.
     */
    reCaptcha: string | null;
}
