import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { CommonModule } from '@angular/common';
import { TranslocoRootModule } from '@core/i18n/transloco-root.module';
import { RouterModule } from '@angular/router';

/**
 * The Core Module is where we want to put our shared singleton services.
 * So the services that we want only one instance of while having them shared among multiple modules should live here.
 * Another piece of our application that should live in the Core Modules is app-level components such as the navigation bar.
 * https://thetombomb.com/posts/app-core-shared-feature-modules
 */
@NgModule({
    declarations: [],
    imports: [CommonModule, TranslocoRootModule, HttpClientModule],
    exports: [TranslocoRootModule, RouterModule],
})
export class CoreModule {}
