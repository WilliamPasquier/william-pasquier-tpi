import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Translation, TranslocoLoader } from '@ngneat/transloco';
import { paths } from '@appConstants/path';

@Injectable({ providedIn: 'root' })
export class TranslocoHttpLoader implements TranslocoLoader {
    constructor(private http: HttpClient) {}

    /**
     * @inheritdoc
     */
    getTranslation(lang: string) {
        return this.http.get<Translation>(`${paths.public.i18n}/${lang}.json`);
    }
}
