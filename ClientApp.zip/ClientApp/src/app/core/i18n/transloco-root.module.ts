import {
    TranslocoModule,
    provideTransloco,
} from '@ngneat/transloco';
import { NgModule } from '@angular/core';
import { environment } from 'src/environments/environment';
import { CommonModule } from '@angular/common';
import { availableLangs, defaultLang } from '@models/locale.model';

import { TranslocoHttpLoader } from './loaders/transloco.loader';

@NgModule({
    declarations: [],
    imports: [CommonModule],
    exports: [TranslocoModule],
    providers: [
        provideTransloco({
            config: {
                availableLangs,
                defaultLang,
                fallbackLang: 'fr',
                // Remove this option if your application doesn't support changing language in runtime.
                reRenderOnLangChange: true,
                prodMode:  environment.production,
            },
            loader: TranslocoHttpLoader
        })
    ],
})
export class TranslocoRootModule {}
