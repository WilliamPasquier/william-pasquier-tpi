import { inject } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivateFn } from '@angular/router';
import { DamageClaimNavigatorService } from '@features/damage-claim/services/damage-claim-navigator/damage-claim-navigator.service';

/**
 * Gaurd to infer if the requested route is available to be navigated. Check : https://angular.io/api/router/CanActivateFn.
 * @param route - The activated route snapshot.
 * @returns - True if we can navigate or it navigates ti the root.
 */
export const canActivateStep: CanActivateFn = (
    route: ActivatedRouteSnapshot,
) => {
    return inject(DamageClaimNavigatorService).canActivateStep(
        route.routeConfig?.path,
    );
};
