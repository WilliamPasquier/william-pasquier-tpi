import { TestBed } from '@angular/core/testing';
import { MockProvider } from 'ng-mocks';
import { EnvironmentInjector, runInInjectionContext } from '@angular/core';
import { DamageClaimNavigatorService } from '@features/damage-claim/services/damage-claim-navigator/damage-claim-navigator.service';
import { canActivateStep } from './can-activate-step.guard';
import { ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';

describe('canActivateStep', () => {
    let navigatorServiceMock: jasmine.SpyObj<DamageClaimNavigatorService>;

    beforeEach(() => {
        navigatorServiceMock =
            jasmine.createSpyObj<DamageClaimNavigatorService>([
                'canActivateStep',
            ]);

        TestBed.configureTestingModule({
            providers: [
                MockProvider(DamageClaimNavigatorService, navigatorServiceMock),
            ],
        });
    });

    it('should check if can activate step from navigator service', () => {
        navigatorServiceMock.canActivateStep
            .withArgs('route-1')
            .and.returnValue(true);

        const result = runInInjectionContext(
            TestBed.inject(EnvironmentInjector),
            () =>
                canActivateStep(
                    {
                        routeConfig: {
                            path: 'route-1',
                        },
                    } as ActivatedRouteSnapshot,
                    {} as RouterStateSnapshot,
                ),
        );

        expect(result).toBeTrue();
        expect(navigatorServiceMock.canActivateStep).toHaveBeenCalledOnceWith(
            'route-1',
        );
    });
});
