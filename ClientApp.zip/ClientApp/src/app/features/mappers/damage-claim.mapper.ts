/* eslint-disable max-params */
import { Injectable } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { Claim } from '@models/claim';
import { DeclarerType } from '@models/declarer-type.enum';
import { DamageClaimFormGroup } from '@models/form-groups/damage-claim-form-group.model';

@Injectable({
    providedIn: 'root',
})
export class DamageClaimMapper {
    // eslint-disable-next-line complexity
    map(formGroup: FormGroup<DamageClaimFormGroup>): Claim {
        const formObject = formGroup.getRawValue();

        const hasBuildingDamage =
            formObject.damageEvent?.damageDescription?.hasBuildingDamage;
        const hasInventoryDamage =
            formObject.damageEvent?.damageDescription?.hasInventoryDamage;
        const hasDeclarerContact =
            formObject.insuranceHolder?.declarerType === DeclarerType.Advisor ||
            formObject.insuranceHolder?.declarerType === DeclarerType.Broker;

        return {
            declarerType: formObject.insuranceHolder?.declarerType || null,
            declarerContact: hasDeclarerContact
                ? formObject.insuranceHolder?.declarerContact || null
                : null,
            holderContact: formObject.insuranceHolder?.holderContact || null,
            event: formObject.damageEvent?.eventDescription || null,
            damageType: formObject.damageEvent?.damageType || null,
            otherDamageType: formObject.damageEvent?.otherDamageType || null,
            damages: {
                buildingDamageDescription: hasBuildingDamage
                    ? formObject.damageEvent?.damageDescription
                          ?.buildingDamageDescription || null
                    : '',
                inventoryDamages: hasInventoryDamage
                    ? formObject.damageEvent?.damageDescription?.inventoryDamage
                          ?.inventoryDamages || null
                    : [],
            },
            additionalInformation: formObject.additionalInformation || null,
            reCaptcha: formObject.recaptcha,
        };
    }
}
