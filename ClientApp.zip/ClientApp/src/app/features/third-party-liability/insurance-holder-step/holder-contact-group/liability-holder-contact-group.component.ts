import { Component, Input, OnInit } from '@angular/core';
import {
    FormBuilder,
    FormGroup,
    FormGroupDirective,
    Validators,
} from '@angular/forms';
import { ValidatorsConstants } from '@appConstants/validators-constants';
import { LiabilityHolderContactFormGroup } from '@models/form-groups/liability-holder-contact-form-group.model';
import { LiabilityInsuranceHolderStepFormGroup } from '@models/form-groups/liability-insurance-holder-step-form-group.model';
import { LiabilityDeclarerType } from '@models/liability-declarer-type.enum';
import { date } from '@shared/validators/date';

@Component({
    selector: 'hf-liability-holder-contact-group',
    templateUrl: './liability-holder-contact-group.component.html',
    styleUrls: ['./liability-holder-contact-group.component.scss'],
})
export class LiabilityHolderContactGroupComponent implements OnInit {
    /**
     * The max date length.
     */
    maxDateLength = ValidatorsConstants.date.maxLength;

    /**
     * The declarer type.
     */
    private _declarerType: LiabilityDeclarerType | null;

    /**
     * The declarer type input setter.
     */
    @Input() set declarerType(declarerType: LiabilityDeclarerType | null) {
        this._declarerType = declarerType;

        this.toggleFieldStatuses(declarerType);
    }

    /**
     * Get's whether the declarer of the claim is the property management agency.
     * @returns True whether the declarer of the claim is the property management agency, false otherwise.
     */
    get isPropertyManagement(): boolean {
        return this._declarerType === LiabilityDeclarerType.PropertyManagement;
    }

    /**
     * Get's whether the declarer of the claim is the injured party.
     * @returns True whether the declarer of the claim is the injured party, false otherwise.
     */
    get isInjuredParty(): boolean {
        return this._declarerType === LiabilityDeclarerType.InjuredParty;
    }

    /**
     * Get's whether the declarer of the claim is an injured party or an advisor.
     * @returns True whether the declarer of the claim is an injured party or an advisor, false otherwise.
     */
    get isAdvisor(): boolean {
        return this._declarerType === LiabilityDeclarerType.Advisor;
    }

    /**
     * Holder contact form group.
     */
    formGroup: FormGroup<LiabilityHolderContactFormGroup>;

    /**
     * Last name control.
     */
    lastName = this.fb.nonNullable.control<string>('', [Validators.required]);

    /**
     * First name control.
     */
    firstName = this.fb.nonNullable.control<string>('', [Validators.required]);

    /**
     * Birthdate control.
     */
    birthdate = this.fb.nonNullable.control<string>('', {
        validators: [date],
        updateOn: 'blur',
    });

    /**
     * Phone number control.
     */
    phoneNumber = this.fb.nonNullable.control<string>('', {
        validators: [Validators.required],
        updateOn: 'blur',
    });

    /**
     * Email control.
     */
    email = this.fb.nonNullable.control<string>('', {
        validators: [Validators.required, Validators.email],
        updateOn: 'blur',
    });

    /**
     * Country control.
     */
    country = this.fb.nonNullable.control<string>('', [Validators.required]);

    /**
     * Postal code control.
     */
    postalCode = this.fb.control<number | null>(null, [Validators.required]);

    /**
     * Locality control.
     */
    locality = this.fb.nonNullable.control<string>('', [Validators.required]);

    /**
     * Street code control.
     */
    street = this.fb.nonNullable.control<string>('', [Validators.required]);

    /**
     * Contract number control.
     */
    contractNumber = this.fb.nonNullable.control<string>('', [
        Validators.required,
    ]);

    /**
     * Street code control.
     */
    iban = this.fb.nonNullable.control<string>('');

    /**
     * The legal protection control.
     */
    legalProtection = this.fb.nonNullable.control<string>('');

    constructor(
        private readonly fb: FormBuilder,
        private readonly parent: FormGroupDirective,
    ) {}

    /**
     * @inheritdoc
     */
    ngOnInit(): void {
        this.formGroup = this.fb.group<LiabilityHolderContactFormGroup>({
            lastName: this.lastName,
            firstName: this.firstName,
            birthdate: this.birthdate,
            phoneNumber: this.phoneNumber,
            email: this.email,
            country: this.country,
            postalCode: this.postalCode,
            locality: this.locality,
            street: this.street,
            contractNumber: this.contractNumber,
            iban: this.iban,
            legalProtection: this.legalProtection,
        });

        (
            this.parent.form as FormGroup<LiabilityInsuranceHolderStepFormGroup>
        ).setControl('holderContact', this.formGroup);
    }

    /**
     * Toggle field statuses based on declarer type.
     * @param declarerType - the declarer type.
     */
    private toggleFieldStatuses(declarerType: LiabilityDeclarerType | null) {
        if (declarerType === LiabilityDeclarerType.InjuredParty) {
            this.birthdate.removeValidators(Validators.required);
        } else if (declarerType === LiabilityDeclarerType.Policyholder) {
            this.birthdate.setValidators(Validators.required);
        } else {
            this.birthdate.removeValidators(Validators.required);
        }
        if (declarerType === LiabilityDeclarerType.InjuredParty || declarerType === LiabilityDeclarerType.PropertyManagement){
            this.contractNumber.removeValidators(Validators.required);
        }
        else {
            this.contractNumber.setValidators(Validators.required);
        }

        this.birthdate.updateValueAndValidity();
        this.contractNumber.updateValueAndValidity();
    }
}
