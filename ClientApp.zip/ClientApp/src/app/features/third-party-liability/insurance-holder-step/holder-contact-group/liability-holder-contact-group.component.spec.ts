import {
    ComponentFixture,
    fakeAsync,
    TestBed,
    tick,
} from '@angular/core/testing';
import {
    FormBuilder,
    FormGroup,
    FormGroupDirective,
    ReactiveFormsModule,
    Validators,
} from '@angular/forms';
import { ValidationMessagesComponent } from '@shared/components/validation-messages/validation-messages.component';
import { getTranslocoTestingModule } from '@testing/transloco-testing.module';
import { MockComponents } from 'ng-mocks';
import { LiabilityHolderContactGroupComponent } from './liability-holder-contact-group.component';
import { PhoneNumberComponent } from '@shared/components/phone-number/phone-number.component';
import { FieldInfoComponent } from '@shared/components/field-info/field-info.component';
import { LiabilityInsuranceHolderStepFormGroup } from '@models/form-groups/liability-insurance-holder-step-form-group.model';
import { LiabilityDeclarerType } from '@models/liability-declarer-type.enum';

describe('LiabilityHolderContactGroupComponent', () => {
    let component: LiabilityHolderContactGroupComponent;
    let fixture: ComponentFixture<LiabilityHolderContactGroupComponent>;
    let mockFormGroup: FormGroup<LiabilityInsuranceHolderStepFormGroup>;

    beforeEach(async () => {
        const fb = new FormBuilder();
        mockFormGroup = new FormGroup<LiabilityInsuranceHolderStepFormGroup>({
            declarerType: fb.control<LiabilityDeclarerType | null>(null),
        });

        const formGroupDirective = new FormGroupDirective([], []);
        formGroupDirective.form = mockFormGroup;

        await TestBed.configureTestingModule({
            imports: [getTranslocoTestingModule(), ReactiveFormsModule],
            declarations: [
                LiabilityHolderContactGroupComponent,
                ...MockComponents(
                    ValidationMessagesComponent,
                    PhoneNumberComponent,
                    FieldInfoComponent,
                ),
            ],
            providers: [
                FormBuilder,
                { provide: FormGroupDirective, useValue: formGroupDirective },
            ],
        }).compileComponents();

        fixture = TestBed.createComponent(LiabilityHolderContactGroupComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });

    it('should add the FormControl to the parent form', () => {
        expect(mockFormGroup.controls.holderContact).toBeDefined();
    });

    [
        [LiabilityDeclarerType.Policyholder],
        [
            LiabilityDeclarerType.Policyholder,
            LiabilityDeclarerType.PropertyManagement,
        ],
        [
            LiabilityDeclarerType.Policyholder,
            LiabilityDeclarerType.PropertyManagement,
            LiabilityDeclarerType.InjuredParty,
        ],
        [LiabilityDeclarerType.PropertyManagement],
        [
            LiabilityDeclarerType.PropertyManagement,
            LiabilityDeclarerType.InjuredParty,
        ],
        [
            LiabilityDeclarerType.PropertyManagement,
            LiabilityDeclarerType.InjuredParty,
            LiabilityDeclarerType.Policyholder,
        ],
        [LiabilityDeclarerType.InjuredParty],
        [
            LiabilityDeclarerType.InjuredParty,
            LiabilityDeclarerType.PropertyManagement,
        ],
        [
            LiabilityDeclarerType.InjuredParty,
            LiabilityDeclarerType.PropertyManagement,
            LiabilityDeclarerType.Policyholder,
        ],
    ].forEach((declarerTypes) => {
        it(`should have the expected validator status for declarer type advisor`, () => {
            for (const x of declarerTypes) {
                component.declarerType = x;
            }

            component.declarerType = LiabilityDeclarerType.Advisor;
            expect(component.lastName.hasValidator(Validators.required)).toBe(
                true,
            );
            expect(component.firstName.hasValidator(Validators.required)).toBe(
                true,
            );
            expect(component.birthdate.hasValidator(Validators.required)).toBe(
                false,
            );
            expect(
                component.phoneNumber.hasValidator(Validators.required),
            ).toBe(true);
            expect(component.country.hasValidator(Validators.required)).toBe(
                true,
            );
            expect(component.postalCode.hasValidator(Validators.required)).toBe(
                true,
            );
            expect(component.locality.hasValidator(Validators.required)).toBe(
                true,
            );
            expect(component.street.hasValidator(Validators.required)).toBe(
                true,
            );
            expect(
                component.contractNumber.hasValidator(Validators.required),
            ).toBe(true);
            expect(component.iban.hasValidator(Validators.required)).toBe(
                false,
            );
            expect(
                component.legalProtection.hasValidator(Validators.required),
            ).toBe(false);
        });
    });

    [
        [LiabilityDeclarerType.Advisor],
        [
            LiabilityDeclarerType.Advisor,
            LiabilityDeclarerType.PropertyManagement,
        ],
        [
            LiabilityDeclarerType.Advisor,
            LiabilityDeclarerType.PropertyManagement,
            LiabilityDeclarerType.InjuredParty,
        ],
        [LiabilityDeclarerType.PropertyManagement],
        [
            LiabilityDeclarerType.PropertyManagement,
            LiabilityDeclarerType.InjuredParty,
        ],
        [
            LiabilityDeclarerType.PropertyManagement,
            LiabilityDeclarerType.InjuredParty,
            LiabilityDeclarerType.Advisor,
        ],
        [LiabilityDeclarerType.InjuredParty],
        [
            LiabilityDeclarerType.InjuredParty,
            LiabilityDeclarerType.PropertyManagement,
        ],
        [
            LiabilityDeclarerType.InjuredParty,
            LiabilityDeclarerType.PropertyManagement,
            LiabilityDeclarerType.Advisor,
        ],
    ].forEach((declarerTypes) => {
        it(`should have the expected validator status for declarer type property management`, () => {
            for (const x of declarerTypes) {
                component.declarerType = x;
            }

            component.declarerType = LiabilityDeclarerType.Policyholder;
            expect(component.lastName.hasValidator(Validators.required)).toBe(
                true,
            );
            expect(component.firstName.hasValidator(Validators.required)).toBe(
                true,
            );
            expect(component.birthdate.hasValidator(Validators.required)).toBe(
                true,
            );
            expect(
                component.phoneNumber.hasValidator(Validators.required),
            ).toBe(true);
            expect(component.country.hasValidator(Validators.required)).toBe(
                true,
            );
            expect(component.postalCode.hasValidator(Validators.required)).toBe(
                true,
            );
            expect(component.locality.hasValidator(Validators.required)).toBe(
                true,
            );
            expect(component.street.hasValidator(Validators.required)).toBe(
                true,
            );
            expect(
                component.contractNumber.hasValidator(Validators.required),
            ).toBe(true);
            expect(component.iban.hasValidator(Validators.required)).toBe(false);
            expect(
                component.legalProtection.hasValidator(Validators.required),
            ).toBe(false);
        });
    });

    [
        [LiabilityDeclarerType.Advisor],
        [
            LiabilityDeclarerType.Advisor,
            LiabilityDeclarerType.PropertyManagement,
        ],
        [
            LiabilityDeclarerType.Advisor,
            LiabilityDeclarerType.PropertyManagement,
            LiabilityDeclarerType.Policyholder,
        ],
        [LiabilityDeclarerType.PropertyManagement],
        [
            LiabilityDeclarerType.PropertyManagement,
            LiabilityDeclarerType.Policyholder,
        ],
        [
            LiabilityDeclarerType.PropertyManagement,
            LiabilityDeclarerType.Policyholder,
            LiabilityDeclarerType.Advisor,
        ],
        [LiabilityDeclarerType.Policyholder],
        [
            LiabilityDeclarerType.Policyholder,
            LiabilityDeclarerType.PropertyManagement,
        ],
        [
            LiabilityDeclarerType.Policyholder,
            LiabilityDeclarerType.PropertyManagement,
            LiabilityDeclarerType.Advisor,
        ],
    ].forEach((declarerTypes) => {
        it(`should have the expected validator status for declarer type injured party`, () => {
            for (const x of declarerTypes) {
                component.declarerType = x;
            }

            component.declarerType = LiabilityDeclarerType.InjuredParty;
            expect(component.lastName.hasValidator(Validators.required)).toBe(
                true,
            );
            expect(component.firstName.hasValidator(Validators.required)).toBe(
                true,
            );
            expect(component.birthdate.hasValidator(Validators.required)).toBe(
                false,
            );
            expect(
                component.phoneNumber.hasValidator(Validators.required),
            ).toBe(true);
            expect(component.country.hasValidator(Validators.required)).toBe(
                true,
            );
            expect(component.postalCode.hasValidator(Validators.required)).toBe(
                true,
            );
            expect(component.locality.hasValidator(Validators.required)).toBe(
                true,
            );
            expect(component.street.hasValidator(Validators.required)).toBe(
                true,
            );
            expect(
                component.contractNumber.hasValidator(Validators.required),
            ).toBe(false);
            expect(component.iban.hasValidator(Validators.required)).toBe(
                false,
            );
            expect(
                component.legalProtection.hasValidator(Validators.required),
            ).toBe(false);
        });
    });

    [
        [LiabilityDeclarerType.Advisor],
        [LiabilityDeclarerType.Advisor, LiabilityDeclarerType.InjuredParty],
        [
            LiabilityDeclarerType.Advisor,
            LiabilityDeclarerType.InjuredParty,
            LiabilityDeclarerType.Policyholder,
        ],
        [LiabilityDeclarerType.InjuredParty],
        [
            LiabilityDeclarerType.InjuredParty,
            LiabilityDeclarerType.Policyholder,
        ],
        [
            LiabilityDeclarerType.InjuredParty,
            LiabilityDeclarerType.Policyholder,
            LiabilityDeclarerType.Advisor,
        ],
        [LiabilityDeclarerType.Policyholder],
        [
            LiabilityDeclarerType.Policyholder,
            LiabilityDeclarerType.InjuredParty,
        ],
        [
            LiabilityDeclarerType.Policyholder,
            LiabilityDeclarerType.InjuredParty,
            LiabilityDeclarerType.Advisor,
        ],
    ].forEach((declarerTypes) => {
        it(`should have the expected validator status for declarer type property management`, () => {
            for (const x of declarerTypes) {
                component.declarerType = x;
            }

            component.declarerType = LiabilityDeclarerType.PropertyManagement;
            expect(component.lastName.hasValidator(Validators.required)).toBe(
                true,
            );
            expect(component.firstName.hasValidator(Validators.required)).toBe(
                true,
            );
            expect(component.birthdate.hasValidator(Validators.required)).toBe(
                false,
            );
            expect(
                component.phoneNumber.hasValidator(Validators.required),
            ).toBe(true);
            expect(component.country.hasValidator(Validators.required)).toBe(
                true,
            );
            expect(component.postalCode.hasValidator(Validators.required)).toBe(
                true,
            );
            expect(component.locality.hasValidator(Validators.required)).toBe(
                true,
            );
            expect(component.street.hasValidator(Validators.required)).toBe(
                true,
            );
            expect(
                component.contractNumber.hasValidator(Validators.required),
            ).toBe(false);
            expect(component.iban.hasValidator(Validators.required)).toBe(
                false,
            );
            expect(
                component.legalProtection.hasValidator(Validators.required),
            ).toBe(false);
        });
    });

    [
        { declarerType: LiabilityDeclarerType.Advisor },
        { declarerType: LiabilityDeclarerType.InjuredParty },
        { declarerType: LiabilityDeclarerType.PropertyManagement },
        { declarerType: LiabilityDeclarerType.Policyholder },
    ].forEach((testObject) => {
        it(`should validate last name control for declarer type ${testObject.declarerType}`, () => {
            const lastName = component.lastName;
            expect(lastName.valid).toBe(false);

            lastName.setValue('');
            expect(lastName.hasError('required')).toBe(true);
        });
    });

    [
        { declarerType: LiabilityDeclarerType.Advisor },
        { declarerType: LiabilityDeclarerType.InjuredParty },
        { declarerType: LiabilityDeclarerType.PropertyManagement },
        { declarerType: LiabilityDeclarerType.Policyholder },
    ].forEach((testObject) => {
        it(`should validate first name control for declarer type ${testObject.declarerType}`, () => {
            const firstName = component.firstName;
            expect(firstName.valid).toBe(false);

            firstName.setValue('');
            expect(firstName.hasError('required')).toBe(true);
        });
    });

    [{ declarerType: LiabilityDeclarerType.Policyholder }].forEach(
        (testObject) => {
            it(`should validate birthdate control for declarer type ${testObject.declarerType}`, () => {
                const birthdate = component.birthdate;
                expect(birthdate.valid).toBe(true);

                birthdate.setValue('');
                expect(birthdate.hasError('required')).toBe(false);
            });
        },
    );

    [
        { declarerType: LiabilityDeclarerType.Advisor },
        { declarerType: LiabilityDeclarerType.InjuredParty },
        { declarerType: LiabilityDeclarerType.PropertyManagement },
        { declarerType: LiabilityDeclarerType.Policyholder },
    ].forEach((testObject) => {
        it(`should validate phone number control for declarer type ${testObject.declarerType}`, () => {
            const phoneNumber = component.phoneNumber;
            expect(phoneNumber.valid).toBe(false);

            phoneNumber.setValue('');
            expect(phoneNumber.hasError('required')).toBe(true);
        });
    });

    [
        { declarerType: LiabilityDeclarerType.Advisor },
        { declarerType: LiabilityDeclarerType.InjuredParty },
        { declarerType: LiabilityDeclarerType.PropertyManagement },
        { declarerType: LiabilityDeclarerType.Policyholder },
    ].forEach((testObject) => {
        it(`should validate country control for declarer type ${testObject.declarerType}`, () => {
            const country = component.country;
            expect(country.valid).toBe(false);

            country.setValue('');
            expect(country.hasError('required')).toBe(true);
        });
    });

    [
        { declarerType: LiabilityDeclarerType.Advisor },
        { declarerType: LiabilityDeclarerType.InjuredParty },
        { declarerType: LiabilityDeclarerType.PropertyManagement },
        { declarerType: LiabilityDeclarerType.Policyholder },
    ].forEach((testObject) => {
        it(`should validate postal code control for declarer type ${testObject.declarerType}`, () => {
            const postalCode = component.postalCode;
            expect(postalCode.valid).toBe(false);

            postalCode.setValue(null);
            expect(postalCode.hasError('required')).toBe(true);
        });
    });

    [
        { declarerType: LiabilityDeclarerType.Advisor },
        { declarerType: LiabilityDeclarerType.InjuredParty },
        { declarerType: LiabilityDeclarerType.PropertyManagement },
        { declarerType: LiabilityDeclarerType.Policyholder },
    ].forEach((testObject) => {
        it(`should validate locality control for declarer type ${testObject.declarerType}`, () => {
            const locality = component.locality;
            expect(locality.valid).toBe(false);

            locality.setValue('');
            expect(locality.hasError('required')).toBe(true);
        });
    });

    [
        { declarerType: LiabilityDeclarerType.Advisor },
        { declarerType: LiabilityDeclarerType.InjuredParty },
        { declarerType: LiabilityDeclarerType.PropertyManagement },
        { declarerType: LiabilityDeclarerType.Policyholder },
    ].forEach((testObject) => {
        it(`should validate street control for declarer type ${testObject.declarerType}`, () => {
            const street = component.street;
            expect(street.valid).toBe(false);

            street.setValue('');
            expect(street.hasError('required')).toBe(true);
        });
    });

    [
        { declarerType: LiabilityDeclarerType.Advisor },
        { declarerType: LiabilityDeclarerType.Policyholder },
        { declarerType: LiabilityDeclarerType.PropertyManagement },
    ].forEach((testObject) => {
        it(`should validate contract number control for declarer type ${testObject.declarerType}`, () => {
            const contractNumber = component.contractNumber;
            expect(contractNumber.valid).toBe(false);

            contractNumber.setValue('');
            expect(contractNumber.hasError('required')).toBe(true);
        });
    });

    [{ declarerType: LiabilityDeclarerType.Policyholder }].forEach(
        (testObject) => {
            it(`should validate iban control for declarer type ${testObject.declarerType}`, () => {
                const iban = component.iban;
                expect(iban.valid).toBe(true);

                iban.setValue('');
                expect(iban.hasError('required')).toBe(false);
            });
        },
    );

    it('should not show error message for valid email', fakeAsync(() => {
        fixture.detectChanges();
        tick();

        component.email.setValue('asdasada@vaudoise.ch');

        expect(component.email.errors).toBeNull();
    }));
});
