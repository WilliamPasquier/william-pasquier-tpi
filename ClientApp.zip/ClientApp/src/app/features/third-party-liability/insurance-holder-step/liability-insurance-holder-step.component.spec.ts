import { ComponentFixture, TestBed } from '@angular/core/testing';
import {
    FormBuilder,
    FormControl,
    FormGroup,
    FormGroupDirective,
    ReactiveFormsModule,
} from '@angular/forms';
import { LiabilityDeclarerContactFormGroup } from '@models/form-groups/liability-declarer-contact-form-group.model';
import { LiabilityFormGroup } from '@models/form-groups/liability-form-group.model';
import { LiabilityDeclarerType } from '@models/liability-declarer-type.enum';
import { FieldInfoComponent } from '@shared/components/field-info/field-info.component';
import { RadioButtonGroupComponent } from '@shared/components/radio-button-group/radio-button-group.component';
import { ValidationMessagesComponent } from '@shared/components/validation-messages/validation-messages.component';
import { getTranslocoTestingModule } from '@testing/transloco-testing.module';
import { MockComponents } from 'ng-mocks';
import { LiabilityDeclarerContactGroupComponent } from './declarer-contact-group/liability-declarer-contact-group.component';
import { LiabilityHolderContactGroupComponent } from './holder-contact-group/liability-holder-contact-group.component';
import { LiabilityInsuranceHolderStepComponent } from './liability-insurance-holder-step.component';

describe('LiabilityInsuranceHolderStepComponent', () => {
    let component: LiabilityInsuranceHolderStepComponent;
    let fixture: ComponentFixture<LiabilityInsuranceHolderStepComponent>;
    let mockFormGroup: FormGroup<LiabilityFormGroup>;

    beforeEach(async () => {
        const fb = new FormBuilder();
        mockFormGroup = new FormGroup<LiabilityFormGroup>({
            recaptcha: fb.control<string | null>(''),
            files: fb.array<FormControl<File>>([]),
        });

        const formGroupDirective = new FormGroupDirective([], []);
        formGroupDirective.form = mockFormGroup;

        await TestBed.configureTestingModule({
            imports: [getTranslocoTestingModule(), ReactiveFormsModule],
            declarations: [
                LiabilityInsuranceHolderStepComponent,
                ...MockComponents(
                    ValidationMessagesComponent,
                    RadioButtonGroupComponent,
                    LiabilityDeclarerContactGroupComponent,
                    LiabilityHolderContactGroupComponent,
                    FieldInfoComponent,
                ),
            ],
            providers: [
                FormBuilder,
                {
                    provide: FormGroupDirective,
                    useValue: formGroupDirective,
                },
            ],
        }).compileComponents();

        fixture = TestBed.createComponent(
            LiabilityInsuranceHolderStepComponent,
        );
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });

    it('should add the FormControl to the parent form', () => {
        expect(mockFormGroup.controls.insuranceHolder).toBeDefined();
    });

    [
        { declarerType: LiabilityDeclarerType.Advisor, expectedStatus: false },
        {
            declarerType: LiabilityDeclarerType.InjuredParty,
            expectedStatus: false,
        },
        {
            declarerType: LiabilityDeclarerType.PropertyManagement,
            expectedStatus: false,
        },
        {
            declarerType: LiabilityDeclarerType.Policyholder,
            expectedStatus: true,
        },
    ].forEach((testObject) => {
        it(`should show the correct fields for declarer type ${testObject.declarerType}`, () => {
            const fb = new FormBuilder();
            component.formGroup.setControl(
                'declarerContact',
                new FormGroup<LiabilityDeclarerContactFormGroup>({
                    propertyManagementName: fb.nonNullable.control<string>(''),
                    firstName: fb.nonNullable.control<string>(''),
                    lastName: fb.nonNullable.control<string>(''),
                    birthdate: fb.nonNullable.control<string>(''),
                    email: fb.nonNullable.control<string>(''),
                    phoneNumber: fb.nonNullable.control<string>(''),
                    country: fb.nonNullable.control<string>(''),
                    locality: fb.nonNullable.control<string>(''),
                    postalCode: fb.nonNullable.control<number | null>(null),
                    street: fb.nonNullable.control<string>(''),
                    legalProtection: fb.nonNullable.control<string>(''),
                }),
            );
            component.declarerType.setValue(testObject.declarerType);
            fixture.detectChanges();

            expect(component.formGroup.controls.declarerContact?.disabled).toBe(
                testObject.expectedStatus,
            );
        });
    });
});
