import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import {
    FormBuilder,
    FormGroup,
    FormGroupDirective,
    Validators,
} from '@angular/forms';
import { LiabilityFormGroup } from '@models/form-groups/liability-form-group.model';
import { LiabilityInsuranceHolderStepFormGroup } from '@models/form-groups/liability-insurance-holder-step-form-group.model';
import { LiabilityDeclarerType } from '@models/liability-declarer-type.enum';
import { ListItem } from '@shared/models/list-item';

@Component({
    selector: 'hf-liability-insurance-holder-step',
    templateUrl: './liability-insurance-holder-step.component.html',
    styleUrls: ['./liability-insurance-holder-step.component.scss'],
})
export class LiabilityInsuranceHolderStepComponent implements OnInit {
    /**
     * Output of the declarer type to the parent component.
     */
    @Output() declarerTypeOutput =
        new EventEmitter<LiabilityDeclarerType | null>();

    /**
     * Declarer form group to enforce FormGroupDirective on child forms.
     */
    formGroup: FormGroup<LiabilityInsuranceHolderStepFormGroup>;

    /**
     * List of declarer type for radio button group.
     */
    declarerTypeItems: Array<ListItem> = [
        {
            i18nKey: 'thirdPartyLiability.declarerType.policyholder',
            value: LiabilityDeclarerType.Policyholder,
        },
        {
            i18nKey: 'thirdPartyLiability.declarerType.propertyManagement',
            value: LiabilityDeclarerType.PropertyManagement,
        },
        {
            i18nKey: 'thirdPartyLiability.declarerType.injuredParty',
            value: LiabilityDeclarerType.InjuredParty,
        },
        {
            i18nKey: 'thirdPartyLiability.declarerType.advisor',
            value: LiabilityDeclarerType.Advisor,
        },
    ];

    /**
     * Reactive form control for declarer type field.
     */
    declarerType = this.fb.nonNullable.control<LiabilityDeclarerType | null>(
        null,
        [Validators.required],
    );

    constructor(
        private readonly fb: FormBuilder,
        private parent: FormGroupDirective,
    ) {}

    /**
     * @inheritdoc
     */
    ngOnInit(): void {
        this.formGroup = this.fb.group<LiabilityInsuranceHolderStepFormGroup>({
            declarerType: this.declarerType,
        });

        this.declarerType.valueChanges.subscribe(() => {
            this.declarerTypeOutput.emit(this.declarerType.value);
            if (this.isNotPolicyholder()) {
                this.formGroup.controls.declarerContact?.enable();
            } else {
                this.formGroup.controls.declarerContact?.disable();
            }
        });

        (this.parent.form as FormGroup<LiabilityFormGroup>).setControl(
            'insuranceHolder',
            this.formGroup,
        );
    }

    /**
     * Checks if the declarer is not a policyholder.
     * @returns true if value is different of policyholder and not null.
     */
    isNotPolicyholder() {
        return (
            this.declarerType.value !== null &&
            this.declarerType.value !== LiabilityDeclarerType.Policyholder
        );
    }
}
