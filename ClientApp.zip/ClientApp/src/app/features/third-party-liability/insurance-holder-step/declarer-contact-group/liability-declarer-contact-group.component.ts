import { Component, Input, OnInit } from '@angular/core';
import {
    FormBuilder,
    FormControl,
    FormGroup,
    FormGroupDirective,
    Validators,
} from '@angular/forms';
import { LiabilityDeclarerContactFormGroup } from '@models/form-groups/liability-declarer-contact-form-group.model';
import { LiabilityInsuranceHolderStepFormGroup } from '@models/form-groups/liability-insurance-holder-step-form-group.model';
import { ListItem } from '@models/list-item';
import { LiabilityDeclarerGender } from '@models/liability-declarer-gender.enum';
import { LiabilityDeclarerType } from '@models/liability-declarer-type.enum';
import { date } from '@shared/validators/date';

@Component({
    selector: 'hf-liability-declarer-contact-group',
    templateUrl: './liability-declarer-contact-group.component.html',
    styleUrls: ['./liability-declarer-contact-group.component.scss'],
})
export class LiabilityDeclarerContactGroupComponent implements OnInit {
    /**
     * The declarer type.
     */
    private _declarerType: LiabilityDeclarerType | null;

    /**
     * Declarer contact form group.
     */
    formGroup: FormGroup<LiabilityDeclarerContactFormGroup>;

    /**
     * Property management name form control.
     */
    propertyManagementName = this.fb.nonNullable.control<string>('', [
        Validators.required,
    ]);

    /**
     * List of declarer gender for radio button group.
     */
    declarerContactItems: Array<ListItem> = [
        {
            i18nKey: 'thirdPartyLiability.declarerContact.gender.mr',
            value: LiabilityDeclarerGender.Mr,
        },
        {
            i18nKey: 'thirdPartyLiability.declarerContact.gender.mrs',
            value: LiabilityDeclarerGender.Mrs,
        },
    ];

    /**
     * The gender form control.
     */
    gender = this.fb.control<LiabilityDeclarerGender | null>(null);

    /**
     * The last name form control.
     */
    lastName = this.fb.nonNullable.control<string>('', [Validators.required]);

    /**
     * The first name form control.
     */
    firstName = this.fb.nonNullable.control<string>('');

    /**
     * Occurrence date control.
     */
    birthdate = this.fb.control<string | null>('', {
        validators: [date],
        updateOn: 'blur',
    });

    /**
     * The phone number form control.
     */
    phoneNumber = this.fb.nonNullable.control<string>('', {
        validators: [Validators.required],
        updateOn: 'blur',
    });

    /**
     * The email form control.
     */
    email = this.fb.nonNullable.control<string>('', {
        validators: [Validators.required, Validators.email],
        updateOn: 'blur',
    });

    /**
     * The locality form control.
     */
    locality = this.fb.nonNullable.control<string>('', Validators.required);

    /**
     * The country form control.
     */
    country = this.fb.nonNullable.control<string>('', Validators.required);

    /**
     * The postal code form control.
     */
    postalCode = this.fb.control<number | null>(null, Validators.required);

    /**
     * The street form control.
     */
    street = this.fb.nonNullable.control<string>('', Validators.required);

    /**
     * The legal protection form control.
     */
    legalProtection = this.fb.nonNullable.control<string>('');

    /**
     * The declarer type input setter.
     */
    @Input() set declarerType(declarerType: LiabilityDeclarerType | null) {
        this._declarerType = declarerType;

        this.toggleFieldStatuses(declarerType);
    }

    /**
     * Get's whether the declarer of the claim is the property management agency.
     * @returns True whether the declarer of the claim is the property management agency, false otherwise.
     */
    get isPropertyManagement(): boolean {
        return this._declarerType === LiabilityDeclarerType.PropertyManagement;
    }

    /**
     * Get's whether the declarer of the claim is the injured party.
     * @returns True whether the declarer of the claim is the injured party, false otherwise.
     */
    get isInjuredParty(): boolean {
        return this._declarerType === LiabilityDeclarerType.InjuredParty;
    }

    /**
     * Get's whether the declarer of the claim is a broker or advisor.
     * @returns True whether the declarer of the claim is a broker or advisor, false otherwise.
     */
    get isAdvisor(): boolean {
        return this._declarerType === LiabilityDeclarerType.Advisor;
    }

    constructor(
        private fb: FormBuilder,
        private parent: FormGroupDirective,
    ) {}

    /**
     * @inheritdoc
     */
    ngOnInit(): void {
        const formGroup = this.parent.form.get('declarerContact');

        // To keep the values/validations since when it is destroyed with *ngIf the message errors would be lost
        if (formGroup) {
            formGroup.enable();
            this.propertyManagementName = formGroup.get(
                'propertyManagementName',
            ) as FormControl;
            this.gender = formGroup.get('gender') as FormControl;
            this.lastName = formGroup.get('lastName') as FormControl;
            this.firstName = formGroup.get('firstName') as FormControl;
            this.birthdate = formGroup.get('birthdate') as FormControl;
            this.phoneNumber = formGroup.get('phoneNumber') as FormControl;
            this.email = formGroup.get('email') as FormControl;
            this.country = formGroup.get('country') as FormControl;
            this.locality = formGroup.get('locality') as FormControl;
            this.street = formGroup.get('street') as FormControl;
            this.postalCode = formGroup.get('postalCode') as FormControl;
            this.legalProtection = formGroup.get(
                'legalProtection',
            ) as FormControl;
            this.formGroup = formGroup as FormGroup;
        } else {
            this.formGroup = this.fb.group<LiabilityDeclarerContactFormGroup>({
                propertyManagementName: this.propertyManagementName,
                gender: this.gender,
                lastName: this.lastName,
                firstName: this.firstName,
                birthdate: this.birthdate,
                phoneNumber: this.phoneNumber,
                email: this.email,
                country: this.country,
                locality: this.locality,
                street: this.street,
                postalCode: this.postalCode,
                legalProtection: this.legalProtection,
            });

            (
                this.parent
                    .form as FormGroup<LiabilityInsuranceHolderStepFormGroup>
            ).setControl('declarerContact', this.formGroup);
        }

        this.toggleFieldStatuses(this._declarerType);
    }

    /**
     * Toggle field statuses based on declarer type.
     * @param declarerType - the declarer type.
     */
    private toggleFieldStatuses(declarerType: LiabilityDeclarerType | null) {
        this.propertyManagementName.disable();
        this.gender.disable();
        this.lastName.disable();
        this.firstName.disable();
        this.birthdate.disable();
        this.legalProtection.disable();
        this.country.disable();
        this.postalCode.disable();
        this.locality.disable();

        if (declarerType === LiabilityDeclarerType.PropertyManagement) {
            this.propertyManagementName.enable();
            this.country.enable();
            this.postalCode.enable();
            this.locality.enable();
        } else if (declarerType === LiabilityDeclarerType.InjuredParty) {
            this.gender.enable();
            this.lastName.enable();
            this.firstName.enable();
            this.birthdate.enable();
            this.legalProtection.enable();
            this.country.enable();
            this.postalCode.enable();
            this.locality.enable();
        } else if (declarerType === LiabilityDeclarerType.Advisor) {
            this.lastName.enable();
            this.firstName.enable();
            this.street.disable();
        }
    }
}
