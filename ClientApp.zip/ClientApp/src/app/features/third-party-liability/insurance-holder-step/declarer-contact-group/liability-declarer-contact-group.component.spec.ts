import { ComponentFixture, TestBed } from '@angular/core/testing';
import {
    FormBuilder,
    FormGroup,
    FormGroupDirective,
    ReactiveFormsModule,
} from '@angular/forms';
import { LiabilityInsuranceHolderStepFormGroup } from '@models/form-groups/liability-insurance-holder-step-form-group.model';
import { LiabilityDeclarerType } from '@models/liability-declarer-type.enum';
import { FieldInfoComponent } from '@shared/components/field-info/field-info.component';
import { PhoneNumberComponent } from '@shared/components/phone-number/phone-number.component';
import { RadioButtonGroupComponent } from '@shared/components/radio-button-group/radio-button-group.component';
import { ValidationMessagesComponent } from '@shared/components/validation-messages/validation-messages.component';
import { getTranslocoTestingModule } from '@testing/transloco-testing.module';
import { MockComponents } from 'ng-mocks';
import { LiabilityDeclarerContactGroupComponent } from './liability-declarer-contact-group.component';

describe('LiabilityDeclarerContactGroupComponent', () => {
    let component: LiabilityDeclarerContactGroupComponent;
    let fixture: ComponentFixture<LiabilityDeclarerContactGroupComponent>;
    let mockFormGroup: FormGroup<LiabilityInsuranceHolderStepFormGroup>;

    beforeEach(async () => {
        const fb = new FormBuilder();
        mockFormGroup = new FormGroup<LiabilityInsuranceHolderStepFormGroup>({
            declarerType: fb.control<LiabilityDeclarerType | null>(null),
        });

        const formGroupDirective = new FormGroupDirective([], []);
        formGroupDirective.form = mockFormGroup;

        await TestBed.configureTestingModule({
            imports: [getTranslocoTestingModule(), ReactiveFormsModule],
            declarations: [
                LiabilityDeclarerContactGroupComponent,
                ...MockComponents(
                    ValidationMessagesComponent,
                    RadioButtonGroupComponent,
                    PhoneNumberComponent,
                    FieldInfoComponent,
                ),
            ],
            providers: [
                FormBuilder,
                { provide: FormGroupDirective, useValue: formGroupDirective },
            ],
        }).compileComponents();

        fixture = TestBed.createComponent(
            LiabilityDeclarerContactGroupComponent,
        );
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });

    it('should add the FormControl to the parent form', () => {
        expect(mockFormGroup.controls.declarerContact).toBeDefined();
    });

    it(`should have the expected disabled status for declarer type property management`, () => {
        component.declarerType = LiabilityDeclarerType.PropertyManagement;
        expect(component.propertyManagementName.disabled).toBe(false);
        expect(component.gender.disabled).toBe(true);
        expect(component.lastName.disabled).toBe(true);
        expect(component.firstName.disabled).toBe(true);
        expect(component.birthdate.disabled).toBe(true);
        expect(component.legalProtection.disabled).toBe(true);
        expect(component.street.disabled).toBe(false);
        expect(component.country.disabled).toBe(false);
        expect(component.postalCode.disabled).toBe(false);
        expect(component.locality.disabled).toBe(false);
    });

    it(`should have the expected disabled status for declarer type advisor`, () => {
        component.declarerType = LiabilityDeclarerType.Advisor;
        expect(component.propertyManagementName.disabled).toBe(true);
        expect(component.gender.disabled).toBe(true);
        expect(component.lastName.disabled).toBe(false);
        expect(component.firstName.disabled).toBe(false);
        expect(component.birthdate.disabled).toBe(true);
        expect(component.legalProtection.disabled).toBe(true);
        expect(component.street.disabled).toBe(true);
        expect(component.country.disabled).toBe(true);
        expect(component.postalCode.disabled).toBe(true);
        expect(component.locality.disabled).toBe(true);
    });

    it(`should have the expected disabled status for declarer type injured party`, () => {
        component.declarerType = LiabilityDeclarerType.InjuredParty;
        expect(component.propertyManagementName.disabled).toBe(true);
        expect(component.gender.disabled).toBe(false);
        expect(component.lastName.disabled).toBe(false);
        expect(component.firstName.disabled).toBe(false);
        expect(component.birthdate.disabled).toBe(false);
        expect(component.legalProtection.disabled).toBe(false);
        expect(component.street.disabled).toBe(false);
        expect(component.country.disabled).toBe(false);
        expect(component.postalCode.disabled).toBe(false);
        expect(component.locality.disabled).toBe(false);
    });

    it('should validate property management name control', () => {
        component.declarerType = LiabilityDeclarerType.PropertyManagement;
        const propertyManagementName = component.propertyManagementName;
        expect(propertyManagementName?.valid).toBe(false);

        propertyManagementName?.setValue('');
        expect(propertyManagementName?.hasError('required')).toBe(true);
    });

    [
        { declarerType: LiabilityDeclarerType.Advisor },
        { declarerType: LiabilityDeclarerType.InjuredParty },
    ].forEach((testObject) => {
        it(`should validate last name control for declarer type ${testObject.declarerType}`, () => {
            component.declarerType = testObject.declarerType;
            const lastName = component.lastName;
            expect(lastName?.valid).toBe(false);

            lastName?.setValue('');
            expect(lastName?.hasError('required')).toBe(true);
        });
    });

    [
        { declarerType: LiabilityDeclarerType.Advisor },
        { declarerType: LiabilityDeclarerType.InjuredParty },
        { declarerType: LiabilityDeclarerType.PropertyManagement },
        { declarerType: LiabilityDeclarerType.Policyholder },
    ].forEach((testObject) => {
        it(`should validate email control for declarer type ${testObject.declarerType}`, () => {
            const email = component.email;
            expect(email?.valid).toBe(false);

            email?.setValue('');
            expect(email?.hasError('required')).toBe(true);
        });
    });

    [
        { declarerType: LiabilityDeclarerType.Advisor },
        { declarerType: LiabilityDeclarerType.InjuredParty },
        { declarerType: LiabilityDeclarerType.PropertyManagement },
        { declarerType: LiabilityDeclarerType.Policyholder },
    ].forEach((testObject) => {
        it(`should validate street control for declarer type ${testObject.declarerType}`, () => {
            const street = component.street;
            expect(street?.valid).toBe(false);

            street?.setValue('');
            expect(street?.hasError('required')).toBe(true);
        });
    });
});
