import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ThirdPartyLiabilityComponent } from './third-party-liability.component';
import { SharedModule } from '@shared/shared.module';
import { LiabilityInsuranceHolderStepComponent } from './insurance-holder-step/liability-insurance-holder-step.component';
import { LiabilityDeclarerContactGroupComponent } from './insurance-holder-step/declarer-contact-group/liability-declarer-contact-group.component';
import { RecaptchaFormsModule, RecaptchaModule } from 'ng-recaptcha';
import { LiabilityHolderContactGroupComponent } from './insurance-holder-step/holder-contact-group/liability-holder-contact-group.component';
import { LiabilityDamageEventStepComponent } from './damage-event-step/liability-damage-event-step.component';
import { LiabilityEventDescriptionGroupComponent } from './damage-event-step/event-description-group/liability-event-description-group.component';
import { LiabilityWitnessesGroupComponent } from './damage-event-step/event-description-group/liability-witnesses-group/liability-witnesses-group.component';
import { LiabilityDamageDescriptionGroupComponent } from './damage-event-step/damage-description-group/liability-damage-description-group.component';
import { InjuredPartyDamageGroupComponent } from './damage-event-step/damage-description-group/injured-party-damage-group/injured-party-damage-group.component';
import { LiabilityAdditionalInfoStepComponent } from './liability-additional-info-step/liability-additional-info-step.component';
import { LiabilityConfirmationPageComponent } from './liability-confirmation-page/liability-confirmation-page.component';
import { TooltipModule } from 'primeng/tooltip';

@NgModule({
    declarations: [
        ThirdPartyLiabilityComponent,
        LiabilityInsuranceHolderStepComponent,
        LiabilityDeclarerContactGroupComponent,
        LiabilityHolderContactGroupComponent,
        LiabilityDamageEventStepComponent,
        LiabilityEventDescriptionGroupComponent,
        LiabilityWitnessesGroupComponent,
        LiabilityDamageDescriptionGroupComponent,
        InjuredPartyDamageGroupComponent,
        LiabilityAdditionalInfoStepComponent,
        LiabilityConfirmationPageComponent,
    ],
    imports: [
        CommonModule,
        SharedModule,
        RecaptchaModule,
        RecaptchaFormsModule,
        TooltipModule,
    ],
    exports: [ThirdPartyLiabilityComponent, SharedModule],
    providers: [],
    schemas: [CUSTOM_ELEMENTS_SCHEMA],
})
export class ThirdPartyLiabilityModule {}
