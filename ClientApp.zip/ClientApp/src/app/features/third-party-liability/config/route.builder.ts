const confirmationPage = 'liability-confirmation-page';

/**
 * The fragment of url related to the third party liability
 */
export const thirdPartyLiabilityRootFragment = 'third-party-liability';

/**
 * The fragment of url related to the confirmation page
 */
export const confirmationPageFragment = `${confirmationPage}/:claim-number`;

/**
 * The route to the confirmation page
 */
export const confirmationPageRoute = `/${confirmationPage}`;
