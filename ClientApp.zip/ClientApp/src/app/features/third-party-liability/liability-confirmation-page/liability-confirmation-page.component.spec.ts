import { ComponentFixture, TestBed } from '@angular/core/testing';
import { getTranslocoTestingModule } from '@testing/transloco-testing.module';
import { RouterTestingModule } from '@angular/router/testing';
import { routes } from '@config/app-routing.config';
import { LiabilityConfirmationPageComponent } from './liability-confirmation-page.component';
import { By } from '@angular/platform-browser';

const claimNumber = '123';

describe('LiabilityConfirmationPageComponent', () => {
    let component: LiabilityConfirmationPageComponent;
    let fixture: ComponentFixture<LiabilityConfirmationPageComponent>;

    beforeEach(async () => {
        await TestBed.configureTestingModule({
            imports: [
                getTranslocoTestingModule(),
                RouterTestingModule.withRoutes(routes),
            ],
            declarations: [LiabilityConfirmationPageComponent],
        }).compileComponents();

        fixture = TestBed.createComponent(LiabilityConfirmationPageComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });

    it('should render the claim number', () => {
        fixture.componentInstance.claimNumber = claimNumber;
        fixture.detectChanges();
        const claimNumberParagraph = fixture.debugElement.query(
            By.css('[data-tui=claim-number-paragraph]'),
        ).nativeElement;
        expect(claimNumberParagraph.innerHTML).toContain(claimNumber);
    });
});
