import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
    selector: 'hf-liability-confirmation-page',
    templateUrl: './liability-confirmation-page.component.html',
    styleUrls: ['./liability-confirmation-page.component.scss'],
})
export class LiabilityConfirmationPageComponent implements OnInit {
    /**
     * The claim number.
     */
    claimNumber: string | null;

    constructor(private route: ActivatedRoute) {}

    /**
     * @inheritdoc
     */
    ngOnInit(): void {
        this.claimNumber = this.route.snapshot.paramMap.get('claim-number');
    }
}
