import { LiabilityEventDescriptionFormGroup } from '@models/form-groups/liability-event-description-form-group.model';
import { LiabilityFormGroup } from '@models/form-groups/liability-form-group.model';
import { LiabilityClaim } from '@models/liability-claim';
import { LiabilityDeclarerType } from '@models/liability-declarer-type.enum';
import { LiabilityEventDescription } from '@models/liability-event-description';
import { FormGroupToModel } from '@shared/helpers/form-group-to-model';

/**
 * Maps the event description form data to the liability event description.
 * @param eventDescription - the event description form data.
 * @returns The liability event description.
 */
function mapEventDescription(
    eventDescription: FormGroupToModel<LiabilityEventDescriptionFormGroup>,
): LiabilityEventDescription {
    const isThirdPartyResponsible =
        eventDescription.isThirdPartyResponsible || false;
    const responsible = isThirdPartyResponsible
        ? {
              lastName: eventDescription.responsibleLastName,
              firstName: eventDescription.responsibleFirstName,
              liabilityInsurerName:
                  eventDescription.responsibleLiabilityInsurerName,
              phoneNumber: eventDescription.responsiblePhoneNumber,
              email: eventDescription.responsibleEmail,
          }
        : null;

    const hasWitness = eventDescription.hasWitness || false;
    return {
        occurrenceDate: eventDescription.occurrenceDate,
        occurrenceTime: eventDescription.occurrenceTime,
        occurrencePlace: eventDescription.occurrencePlace,
        circumstances: eventDescription.circumstances,
        hasPoliceReport: eventDescription.hasPoliceReport,
        isInsuredResponsible: eventDescription.isInsuredResponsible,
        isThirdPartyResponsible,
        thirdPartyResponsible: responsible,
        hasWitness,
        witnesses: hasWitness ? eventDescription.witnesses : null,
    };
}

/**
 * Maps the liability claim form group to the liability claim.
 * @param formObject - the form values.
 * @returns the third party liability claim.
 * @throws if mandatory properties are missing
 */
export function map(
    formObject: FormGroupToModel<LiabilityFormGroup>,
): LiabilityClaim {
    const insuranceHolder = formObject.insuranceHolder;
    if (!insuranceHolder) {
        throw new Error('insuranceHolder is mandatory');
    }

    const holderContact = insuranceHolder.holderContact;
    if (!holderContact) {
        throw new Error('insuranceHolder.holderContact is mandatory');
    }

    const damageEvent = formObject.damageEvent;
    if (!damageEvent) {
        throw new Error('damageEvent is mandatory');
    }

    const damageDescription = damageEvent.damageDescription;
    if (!damageDescription) {
        throw new Error('damageEvent.damageDescription is mandatory');
    }

    const eventDescription = damageEvent.eventDescription;
    if (!eventDescription) {
        throw new Error('damageEvent.eventDescription is mandatory');
    }

    const additionalInfo = formObject.additionalInfo;
    if (!additionalInfo) {
        throw new Error('additionalInfo is mandatory');
    }

    const hasDeclarerContact =
        insuranceHolder.declarerType !== LiabilityDeclarerType.Policyholder;

    return {
        declarerType: insuranceHolder.declarerType,
        declarerContact: hasDeclarerContact
            ? insuranceHolder.declarerContact
            : null,
        holderContact,
        damageCausedBy: damageEvent.damageCausedBy,
        eventDescription: mapEventDescription(eventDescription),
        damageDescription,
        additionalInfo,
        reCaptcha: formObject.recaptcha,
    };
}
