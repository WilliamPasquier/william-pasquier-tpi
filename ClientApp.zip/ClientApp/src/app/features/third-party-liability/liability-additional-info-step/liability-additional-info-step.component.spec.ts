import { ComponentFixture, TestBed } from '@angular/core/testing';
import {
    FormBuilder,
    FormControl,
    FormGroup,
    FormGroupDirective,
    ReactiveFormsModule,
} from '@angular/forms';
import { FieldInfoComponent } from '@shared/components/field-info/field-info.component';
import { PhoneNumberComponent } from '@shared/components/phone-number/phone-number.component';
import { RadioButtonGroupComponent } from '@shared/components/radio-button-group/radio-button-group.component';
import { ValidationMessagesComponent } from '@shared/components/validation-messages/validation-messages.component';
import { getTranslocoTestingModule } from '@testing/transloco-testing.module';
import { MockComponents } from 'ng-mocks';

import { LiabilityAdditionalInfoStepComponent } from './liability-additional-info-step.component';
import { LiabilityDamageClaimFormGroup } from '@models/form-groups/liability-damage-claim-form-group.model';

describe('LiabilityAdditionalInfoStepComponent', () => {
    let component: LiabilityAdditionalInfoStepComponent;
    let fixture: ComponentFixture<LiabilityAdditionalInfoStepComponent>;
    let mockFormGroup: FormGroup<LiabilityDamageClaimFormGroup>;

    beforeEach(async () => {
        mockFormGroup = new FormGroup<LiabilityDamageClaimFormGroup>({
            recaptcha: new FormControl<string | null>(null),
        });

        const formGroupDirective = new FormGroupDirective([], []);
        formGroupDirective.form = mockFormGroup;

        await TestBed.configureTestingModule({
            imports: [getTranslocoTestingModule(), ReactiveFormsModule],
            declarations: [
                LiabilityAdditionalInfoStepComponent,
                ...MockComponents(
                    ValidationMessagesComponent,
                    RadioButtonGroupComponent,
                    FieldInfoComponent,
                    PhoneNumberComponent,
                ),
            ],
            providers: [
                FormBuilder,
                { provide: FormGroupDirective, useValue: formGroupDirective },
            ],
        }).compileComponents();

        fixture = TestBed.createComponent(LiabilityAdditionalInfoStepComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });

    it('should add the FormControl to the parent form', () => {
        expect(mockFormGroup.controls.additionalInfo).toBeDefined();
    });

    [
        { isRelatedToAnotherDomesticAccident: null, disabled: true },
        { isRelatedToAnotherDomesticAccident: true, disabled: false },
        { isRelatedToAnotherDomesticAccident: false, disabled: true },
    ].forEach((testObject) => {
        it('should toggle domesticClaimNumber disabled status', () => {
            component.isRelatedToAnotherDomesticAccident.setValue(
                testObject.isRelatedToAnotherDomesticAccident,
            );
            expect(component.domesticClaimNumber.disabled).toBe(
                testObject.disabled,
            );
        });
    });
});
