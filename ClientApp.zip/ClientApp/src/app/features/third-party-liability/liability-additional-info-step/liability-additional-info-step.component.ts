import { Component, OnInit } from '@angular/core';
import {
    FormBuilder,
    FormGroup,
    FormGroupDirective,
    Validators,
} from '@angular/forms';
import { LiabilityDamageClaimFormGroup } from '@models/form-groups/liability-damage-claim-form-group.model';
import { LiabilityAdditionalInformationFormGroup } from '@models/form-groups/liability-additional-information-form-group.model';
import { ListItem } from '@models/list-item';

@Component({
    selector: 'hf-liability-additional-info-step',
    templateUrl: './liability-additional-info-step.component.html',
    styleUrls: ['./liability-additional-info-step.component.scss'],
})
export class LiabilityAdditionalInfoStepComponent implements OnInit {
    /**
     * Liability additional info form group.
     */
    formGroup: FormGroup<LiabilityAdditionalInformationFormGroup>;

    /**
     * List of option for radio button group.
     */
    isRelatedToAnotherAccidentItems: Array<ListItem> = [
        { i18nKey: 'common.yes', value: true },
        { i18nKey: 'common.no', value: false },
    ];

    /**
     * Has relation with another domestic accident.
     */
    isRelatedToAnotherDomesticAccident = this.fb.control<boolean | null>(null, [
        Validators.required,
    ]);

    /**
     * Domestic claim number
     */
    domesticClaimNumber = this.fb.control<string | null>('');

    /**
     * Other remarks control.
     */
    otherRemarks = this.fb.control<string | null>('');

    constructor(
        private fb: FormBuilder,
        private parent: FormGroupDirective,
    ) {}

    /**
     * @inheritdoc
     */
    ngOnInit(): void {
        this.formGroup = this.fb.group<LiabilityAdditionalInformationFormGroup>(
            {
                isRelatedToAnotherDomesticAccident:
                    this.isRelatedToAnotherDomesticAccident,
                domesticClaimNumber: this.domesticClaimNumber,
                otherRemarks: this.otherRemarks,
            },
        );

        (
            this.parent.form as FormGroup<LiabilityDamageClaimFormGroup>
        ).setControl('additionalInfo', this.formGroup);

        this.isRelatedToAnotherDomesticAccident.valueChanges.subscribe({
            next: (value: boolean | null) => this.toggleFieldStatuses(value),
        });
    }

    /**
     * Toggle field statuses based on isThirdPartyResponsible.
     * @param isRelatedToAnotherDomesticAccident - the related to another domestic accident status.
     */
    private toggleFieldStatuses(
        isRelatedToAnotherDomesticAccident: boolean | null,
    ) {
        if (isRelatedToAnotherDomesticAccident) {
            this.formGroup.controls.domesticClaimNumber?.enable();
        } else {
            this.formGroup.controls.domesticClaimNumber?.disable();
        }
    }
}
