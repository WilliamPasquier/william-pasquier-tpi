import { Component, Input, OnInit, Renderer2, inject } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { map } from '@features/third-party-liability/helpers/liability.mapper';
import { LiabilityFormGroup } from '@models/form-groups/liability-form-group.model';
import { LiabilityDeclarerType } from '@models/liability-declarer-type.enum';
import { LiabilityClaimService } from '@services/liability-claim/liability-claim.service';
import { confirmationPageRoute } from './config/route.builder';
import { FormGroupToModel } from '@shared/helpers/form-group-to-model';

@Component({
    selector: 'hf-third-party-liability',
    templateUrl: './third-party-liability.component.html',
    styleUrls: ['./third-party-liability.component.scss'],
})
export class ThirdPartyLiabilityComponent implements OnInit {
    /**
     * The liability claim service.
     */
    liabilityClaimService = inject(LiabilityClaimService);

    /**
     * The form builder.
     */
    fb = inject(FormBuilder);

    /**
     * The router.
     */
    router = inject(Router);

    /**
     * The form group.
     */
    formGroup: FormGroup<LiabilityFormGroup>;

    /**
     * Form control with the list of uploaded files.
     */
    files = this.fb.array<FormControl<File>>([]);

    /**
     * The data protection page url.
     */
    dataProtectionPageUrl: string;

    /**
     * The cookie policy page url.
     */
    cookiePolicyPageUrl: string;

    /**
     * Declarer type property as defined in liability insurance holder step.
     */
    declarerType: LiabilityDeclarerType | null;

    /**
     * Submit is in progress.
     */
    @Input() isProcessing: boolean;

    /**
     * The recaptcha field.
     */
    recaptcha = this.fb.control<string | null>('', Validators.required);

    constructor(private renderer: Renderer2) {
        const rootComponent = this.renderer.selectRootElement('hf-root', true);
        this.dataProtectionPageUrl = rootComponent.getAttribute(
            'data-data-protection-page',
        );
        this.cookiePolicyPageUrl = rootComponent.getAttribute(
            'data-cookie-policy-page',
        );
    }

    /**
     * @inheritdoc
     */
    ngOnInit(): void {
        this.formGroup = this.fb.group<LiabilityFormGroup>({
            recaptcha: this.recaptcha,
            files: this.files,
        });
    }

    /**
     * Submit the form.
     */
    onSubmit(): void {
        if (!this.formGroup.valid) {
            this.formGroup.markAllAsTouched();
            return;
        }

        const claim = map(
            this.formGroup.value as FormGroupToModel<LiabilityFormGroup>,
        );

        this.isProcessing = true;

        this.liabilityClaimService
            .sendClaimRequest(claim, this.formGroup.controls.files.value)
            .subscribe({
                next: (response) => {
                    this.formGroup.reset();
                    this.router.navigate([
                        confirmationPageRoute,
                        response.claimNumber,
                    ]);
                },
                error: (error) => {
                    // eslint-disable-next-line no-console
                    console.log(error);
                    this.isProcessing = false;
                },
            });
    }

    /**
     * Handle the output of the liability insurance holder step.
     * @param data - The declarer type.
     */
    receiveDataFromChild(data: LiabilityDeclarerType | null) {
        this.declarerType = data;
    }
}
