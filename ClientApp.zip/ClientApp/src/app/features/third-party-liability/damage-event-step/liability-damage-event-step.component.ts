import { Component, Input, OnInit } from '@angular/core';
import {
    FormBuilder,
    FormGroup,
    FormGroupDirective,
    Validators,
} from '@angular/forms';
import { LiabilityDamageClaimFormGroup } from '@models/form-groups/liability-damage-claim-form-group.model';
import { LiabilityDamageEventStepFormGroup } from '@models/form-groups/liability-damage-event-step-form-group.model';
import { LiabilityDamageCausedBy } from '@models/liability-damage-caused-by.enum';
import { LiabilityDeclarerType } from '@models/liability-declarer-type.enum';

@Component({
    selector: 'hf-liability-damage-event-step',
    templateUrl: './liability-damage-event-step.component.html',
    styleUrls: ['./liability-damage-event-step.component.scss'],
})
export class LiabilityDamageEventStepComponent implements OnInit {
    /**
     * Liability damage event step form group to enforce FormGroupDirective on child forms.
     */
    formGroup: FormGroup<LiabilityDamageEventStepFormGroup>;

    /**
     * Reactive form control for damage type field.
     */
    damageCausedBy = this.fb.control<LiabilityDamageCausedBy | null>(null, [
        Validators.required,
    ]);

    /**
     * The declarer type received as input.
     */
    @Input() declarerType: LiabilityDeclarerType | null;

    constructor(
        private readonly fb: FormBuilder,
        private parent: FormGroupDirective,
    ) {}

    /**
     * @inheritdoc
     */
    ngOnInit(): void {
        this.formGroup = this.fb.group<LiabilityDamageEventStepFormGroup>({
            damageCausedBy: this.damageCausedBy,
        });

        (
            this.parent.form as FormGroup<LiabilityDamageClaimFormGroup>
        ).setControl('damageEvent', this.formGroup);
    }
}
