import { Component, OnInit } from '@angular/core';
import {
    FormBuilder,
    FormGroup,
    FormGroupDirective,
    Validators,
} from '@angular/forms';
import { ValidatorsConstants } from '@appConstants/validators-constants';
import { LiabilityDamageEventStepFormGroup } from '@models/form-groups/liability-damage-event-step-form-group.model';
import { LiabilityEventDescriptionFormGroup } from '@models/form-groups/liability-event-description-form-group.model';
import { LiabilityDeclarerGender } from '@models/liability-declarer-gender.enum';
import { ListItem } from '@models/list-item';
import { date } from '@shared/validators/date';
import { time } from '@shared/validators/time';

@Component({
    selector: 'hf-liability-event-description-group',
    templateUrl: './liability-event-description-group.component.html',
    styleUrls: ['./liability-event-description-group.component.scss'],
})
export class LiabilityEventDescriptionGroupComponent implements OnInit {
    /**
     * The date max length.
     */
    maxDateLength = ValidatorsConstants.date.maxLength;

    /**
     * The time max lenght.
     */
    maxTimeLength = ValidatorsConstants.time.maxLength;

    /**
     * Event description form group.
     */
    formGroup: FormGroup<LiabilityEventDescriptionFormGroup>;

    /**
     * The Yes / No options.
     */
    radioButtonYesNoItems: Array<ListItem> = [
        { i18nKey: 'common.yes', value: true },
        { i18nKey: 'common.no', value: false },
    ];

    /**
     * Occurrence date control.
     */
    occurrenceDate = this.fb.nonNullable.control<string>('', {
        validators: [Validators.required, date],
        updateOn: 'blur',
    });

    /**
     * Occurrence time control.
     */
    occurrenceTime = this.fb.control<string | null>('', {
        validators: [time],
        updateOn: 'blur',
    });

    /**
     * Occurrence place control.
     */
    occurrencePlace = this.fb.nonNullable.control<string>('', [
        Validators.required,
    ]);

    /**
     * Circumstances control.
     */
    circumstances = this.fb.nonNullable.control<string>('', [
        Validators.required,
    ]);

    /**
     * Has police report control.
     */
    hasPoliceReport = this.fb.control<boolean | null>(null, [
        Validators.required,
    ]);

    /**
     * Is Insured responsible report control.
     */
    isInsuredResponsible = this.fb.control<boolean | null>(null, [
        Validators.required,
    ]);

    /**
     * Is third party responsible control.
     */
    isThirdPartyResponsible = this.fb.control<boolean | null>(null, [
        Validators.required,
    ]);

    /**
     * responsibleLastName control.
     */
    responsibleLastName = this.fb.nonNullable.control<string>('', [
        Validators.required,
    ]);

    /**
     * responsibleFirstName control.
     */
    responsibleFirstName = this.fb.nonNullable.control<string>('', [
        Validators.required,
    ]);

    /**
     * responsibleLiabilityInsurerName control.
     */
    responsibleLiabilityInsurerName = this.fb.nonNullable.control<string>('');

    /**
     * responsiblePhoneNumber control.
     */
    responsiblePhoneNumber = this.fb.nonNullable.control<string>('', Validators.required);

    /**
     * responsibleEmail control.
     */
    responsibleEmail = this.fb.nonNullable.control<string>('');

    /**
     * Has witnesses control.
     */
    hasWitness = this.fb.control<boolean | null>(null, [Validators.required]);

    /**
     * List of gender for radio button group.
     */
    genderItems: Array<ListItem> = [
        {
            i18nKey: 'thirdPartyLiability.declarerContact.gender.mr',
            value: LiabilityDeclarerGender.Mr,
        },
        {
            i18nKey: 'thirdPartyLiability.declarerContact.gender.mrs',
            value: LiabilityDeclarerGender.Mrs,
        },
    ];
    
    /**
     * The responsible gender form control.
     */
    responsibleGender = this.fb.control<LiabilityDeclarerGender | null>(null, Validators.required);

    constructor(
        private readonly fb: FormBuilder,
        private readonly parent: FormGroupDirective,
    ) {}

    /**
     * @inheritdoc
     */
    ngOnInit(): void {
        this.formGroup = this.fb.group<LiabilityEventDescriptionFormGroup>({
            occurrenceDate: this.occurrenceDate,
            occurrenceTime: this.occurrenceTime,
            occurrencePlace: this.occurrencePlace,
            circumstances: this.circumstances,
            hasPoliceReport: this.hasPoliceReport,
            isInsuredResponsible: this.isInsuredResponsible,
            isThirdPartyResponsible: this.isThirdPartyResponsible,
            responsibleLastName: this.responsibleLastName,
            responsibleFirstName: this.responsibleFirstName,
            responsibleLiabilityInsurerName:
                this.responsibleLiabilityInsurerName,
            responsiblePhoneNumber: this.responsiblePhoneNumber,
            responsibleEmail: this.responsibleEmail,
            hasWitness: this.hasWitness,
            responsibleGender: this.responsibleGender,
        });

        (
            this.parent.form as FormGroup<LiabilityDamageEventStepFormGroup>
        ).setControl('eventDescription', this.formGroup);

        this.responsibleLastName.disable();
        this.responsibleFirstName.disable();
        this.responsibleLiabilityInsurerName.disable();
        this.responsiblePhoneNumber.disable();
        this.responsibleEmail.disable();
        this.responsibleGender.disable();

        this.isThirdPartyResponsible.valueChanges.subscribe({
            next: (value: boolean | null) => this.toggleFieldStatuses(value),
        });
        this.hasWitness.valueChanges.subscribe({
            next: (value: boolean | null) => this.onhasWitnessChanged(value),
        });
    }

    /**
     * Toggle field statuses based on isThirdPartyResponsible.
     * @param isThirdPartyResponsible - the information whether the third party is responsible or not.
     */
    private toggleFieldStatuses(isThirdPartyResponsible: boolean | null) {
        if (isThirdPartyResponsible) {
            this.responsibleLastName.enable();
            this.responsibleFirstName.enable();
            this.responsibleLiabilityInsurerName.enable();
            this.responsiblePhoneNumber.enable();
            this.responsibleEmail.enable();
            this.responsibleGender.enable();
        } else {
            this.responsibleLastName.disable();
            this.responsibleFirstName.disable();
            this.responsibleLiabilityInsurerName.disable();
            this.responsiblePhoneNumber.disable();
            this.responsibleEmail.disable();
            this.responsibleGender.disable();
        }
    }

    /**
     * Handle value change for hasWitness form control.
     * @param hasWitness - the information whether there are witnesses or not.
     */
    onhasWitnessChanged(hasWitness: boolean | null): void {
        if (hasWitness) {
            this.formGroup.controls.witnesses?.enable();
        } else {
            this.formGroup.controls.witnesses?.disable();
        }
    }
}
