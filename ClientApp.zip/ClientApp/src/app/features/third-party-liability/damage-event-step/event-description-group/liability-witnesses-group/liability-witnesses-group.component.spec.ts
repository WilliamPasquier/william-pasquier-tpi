import {
    ComponentFixture,
    TestBed,
    fakeAsync,
    tick,
} from '@angular/core/testing';
import {
    FormBuilder,
    FormGroup,
    FormGroupDirective,
    ReactiveFormsModule,
} from '@angular/forms';
import { LiabilityEventDescriptionFormGroup } from '@models/form-groups/liability-event-description-form-group.model';
import { FieldInfoComponent } from '@shared/components/field-info/field-info.component';
import { PhoneNumberComponent } from '@shared/components/phone-number/phone-number.component';
import { RadioButtonGroupComponent } from '@shared/components/radio-button-group/radio-button-group.component';
import { ValidationMessagesComponent } from '@shared/components/validation-messages/validation-messages.component';
import { getTranslocoTestingModule } from '@testing/transloco-testing.module';
import { MockComponents } from 'ng-mocks';

import { LiabilityWitnessesGroupComponent } from './liability-witnesses-group.component';
import { By } from '@angular/platform-browser';

describe('LiabilityWitnessesGroupComponent', () => {
    let component: LiabilityWitnessesGroupComponent;
    let fixture: ComponentFixture<LiabilityWitnessesGroupComponent>;
    let mockFormGroup: FormGroup<LiabilityEventDescriptionFormGroup>;

    beforeEach(async () => {
        const fb = new FormBuilder();
        mockFormGroup = new FormGroup<LiabilityEventDescriptionFormGroup>({
            occurrenceDate: fb.nonNullable.control<string>(''),
            occurrenceTime: fb.control<string | null>(null),
            occurrencePlace: fb.nonNullable.control<string>(''),
            circumstances: fb.nonNullable.control<string>(''),
            hasPoliceReport: fb.control<boolean | null>(null),
            isInsuredResponsible: fb.control<boolean | null>(null),
            isThirdPartyResponsible: fb.control<boolean | null>(null),
            responsibleLastName: fb.nonNullable.control<string>(''),
            responsibleFirstName: fb.nonNullable.control<string>(''),
            responsibleLiabilityInsurerName: fb.nonNullable.control<string>(''),
            responsiblePhoneNumber: fb.nonNullable.control<string>(''),
            responsibleEmail: fb.nonNullable.control<string>(''),
            hasWitness: fb.control<boolean | null>(true),
        });

        const formGroupDirective = new FormGroupDirective([], []);
        formGroupDirective.form = mockFormGroup;

        await TestBed.configureTestingModule({
            imports: [getTranslocoTestingModule(), ReactiveFormsModule],
            declarations: [
                LiabilityWitnessesGroupComponent,
                ...MockComponents(
                    ValidationMessagesComponent,
                    RadioButtonGroupComponent,
                    FieldInfoComponent,
                    PhoneNumberComponent,
                ),
            ],
            providers: [
                FormBuilder,
                { provide: FormGroupDirective, useValue: formGroupDirective },
            ],
        }).compileComponents();

        fixture = TestBed.createComponent(LiabilityWitnessesGroupComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create that thing', () => {
        expect(component).toBeTruthy();
    });

    it('should contain the expected elements', () => {
        /**
         * Verify if the add button exists when component is created
         */
        const addButton = fixture.debugElement.query(
            By.css('[data-tui="add-btn"]'),
        ).nativeElement;
        expect(addButton).toBeTruthy();

        /**
         * Verify if the remove button does not exist
         */
        const removeButton = fixture.debugElement.query(
            By.css('[data-tui="remove-btn"]'),
        );
        expect(removeButton).toBeFalsy();

        /**
         * Verify if first name input is created
         */
        const firstNameInputElement = fixture.debugElement.query(
            By.css('[data-tui="witness-first-name"]'),
        );
        const firstName = component.witnesses.at(0).controls.firstName;
        const firstNameValue = firstName.value;
        expect(firstNameInputElement).toBeTruthy();
        expect(firstNameInputElement.nativeElement.value).toEqual(
            firstNameValue,
        );
        expect(firstName.valid).toBeFalse();

        /**
         * Verify if last name input is created
         */
        const lastNameInputElement = fixture.debugElement.query(
            By.css('[data-tui="witness-last-name"]'),
        );
        const lastName = component.witnesses.at(0).controls.lastName;
        const lastNameValue = lastName.value;
        expect(lastNameInputElement).toBeTruthy();
        expect(lastNameInputElement.nativeElement.value).toEqual(lastNameValue);
        expect(lastName.valid).toBeFalse();

        /**
         * Verify if phone number input is created
         */
        const phoneNumberInputElement = fixture.debugElement.query(
            By.css('[data-tui="witness-phone-number"]'),
        );
        const phoneNumber = component.witnesses.at(0).controls.phoneNumber;
        expect(phoneNumberInputElement).toBeTruthy();
        expect(phoneNumber.valid).toBeTrue();

        /**
         * Verify if email input is created
         */
        const emailInputElement = fixture.debugElement.query(
            By.css('[data-tui="witness-email"]'),
        );
        const email = component.witnesses.at(0).controls.email;
        const emailValue = email.value;
        expect(emailInputElement).toBeTruthy();
        expect(emailInputElement.nativeElement.value).toEqual(emailValue);
        expect(email.valid).toBeTrue();
    });

    it('form invalid when empty', () => {
        expect(component.formArray.valid).toBeFalsy();
    });

    it('form group element count', () => {
        const formElement = fixture.debugElement.query(
            By.css('[data-tui="witness-form"]'),
        ).nativeElement;
        const inputElements = formElement.querySelectorAll('input');
        expect(inputElements.length).toEqual(3);
        const textareaElements = formElement.querySelectorAll('phone-number');
        expect(textareaElements.length).toEqual(1);
    });

    it('should add element to array when click add button', fakeAsync(() => {
        const button = fixture.debugElement.query(
            By.css('[data-tui="add-btn"]'),
        ).nativeElement;
        button.click();

        expect(button).toBeTruthy();
        expect(component.witnesses.controls.length).toEqual(2);

        fixture.detectChanges();
        tick();

        const buttons = fixture.debugElement.queryAll(
            By.css('[data-tui="remove-btn"]'),
        );
        expect(buttons.length).toBe(2);
    }));

    it('should remove element from array when click remove button', fakeAsync(() => {
        component.addWitness();
        fixture.detectChanges();
        tick();

        const button = fixture.debugElement.query(
            By.css('[data-tui="remove-btn"]'),
        ).nativeElement;
        button.click();
        fixture.detectChanges();
        tick();

        expect(component.witnesses.length).toEqual(1);
    }));

    it('should be valid when all filed are set', fakeAsync(() => {
        const firstNameInputElement = fixture.debugElement.query(
            By.css('[data-tui="witness-first-name"]'),
        );
        firstNameInputElement.nativeElement.value = 'test';
        fixture.detectChanges();
        tick();

        const lastNameInputElement = fixture.debugElement.query(
            By.css('[data-tui="witness-last-name"]'),
        );
        lastNameInputElement.nativeElement.value = '234';
        fixture.detectChanges();
        tick();

        const phoneNumberInputElement = fixture.debugElement.query(
            By.css('[data-tui="witness-phone-number"]'),
        );
        phoneNumberInputElement.nativeElement.value = '+41795869898';
        fixture.detectChanges();
        tick();

        const emailInputElement = fixture.debugElement.query(
            By.css('[data-tui="witness-email"]'),
        );
        emailInputElement.nativeElement.value = 'plouf@me.com';
        fixture.detectChanges();
        tick();

        const inventoryDamage = {
            firstName: firstNameInputElement.nativeElement.value,
            lastName: lastNameInputElement.nativeElement.value,
            phoneNumber: phoneNumberInputElement.nativeElement.value,
            email: emailInputElement.nativeElement.value,
        };

        component.formArray.setValue([inventoryDamage]);
        expect(component.formArray.valid).toBeTruthy();
    }));

    it('firstName field validity', () => {
        const firstName = component.witnesses.at(0).controls.firstName;

        firstName.setValue('');
        expect(firstName.hasError('required')).toBeTruthy();
    });

    it('lastName field validity', () => {
        const lastName = component.witnesses.at(0).controls.lastName;

        lastName.setValue('');
        expect(lastName.hasError('required')).toBeTruthy();
    });

    it('email field validity', () => {
        const email = component.witnesses.at(0).controls.email;

        email.setValue('notanemail');
        expect(email.hasError('email')).toBeTruthy();
    });
});
