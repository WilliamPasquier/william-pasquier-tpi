import { ComponentFixture, TestBed } from '@angular/core/testing';
import {
    FormBuilder,
    FormGroup,
    FormGroupDirective,
    ReactiveFormsModule,
} from '@angular/forms';
import { LiabilityDamageEventStepFormGroup } from '@models/form-groups/liability-damage-event-step-form-group.model';
import { LiabilityDamageCausedBy } from '@models/liability-damage-caused-by.enum';
import { FieldInfoComponent } from '@shared/components/field-info/field-info.component';
import { PhoneNumberComponent } from '@shared/components/phone-number/phone-number.component';
import { RadioButtonGroupComponent } from '@shared/components/radio-button-group/radio-button-group.component';
import { ValidationMessagesComponent } from '@shared/components/validation-messages/validation-messages.component';
import { getTranslocoTestingModule } from '@testing/transloco-testing.module';
import { MockComponents } from 'ng-mocks';

import { LiabilityEventDescriptionGroupComponent } from './liability-event-description-group.component';
import { LiabilityWitnessesGroupComponent } from './liability-witnesses-group/liability-witnesses-group.component';
import { TooltipModule } from 'primeng/tooltip';

describe('LiabilityEventDescriptionGroupComponent', () => {
    let component: LiabilityEventDescriptionGroupComponent;
    let fixture: ComponentFixture<LiabilityEventDescriptionGroupComponent>;
    let mockFormGroup: FormGroup<LiabilityDamageEventStepFormGroup>;

    beforeEach(async () => {
        const fb = new FormBuilder();
        mockFormGroup = new FormGroup<LiabilityDamageEventStepFormGroup>({
            damageCausedBy: fb.control<LiabilityDamageCausedBy | null>(null),
        });

        const formGroupDirective = new FormGroupDirective([], []);
        formGroupDirective.form = mockFormGroup;

        await TestBed.configureTestingModule({
            imports: [
                getTranslocoTestingModule(),
                ReactiveFormsModule,
                TooltipModule,
            ],
            declarations: [
                LiabilityEventDescriptionGroupComponent,
                LiabilityWitnessesGroupComponent,
                ...MockComponents(
                    ValidationMessagesComponent,
                    RadioButtonGroupComponent,
                    FieldInfoComponent,
                    PhoneNumberComponent,
                ),
            ],
            providers: [
                FormBuilder,
                { provide: FormGroupDirective, useValue: formGroupDirective },
            ],
        }).compileComponents();

        fixture = TestBed.createComponent(
            LiabilityEventDescriptionGroupComponent,
        );
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create that thing', () => {
        expect(component).toBeTruthy();
    });

    it('should add the FormControl to the parent form', () => {
        expect(mockFormGroup.controls.eventDescription).toBeDefined();
    });

    it('should validate occurrence date control', () => {
        const occurrenceDate = component.occurrenceDate;
        expect(occurrenceDate?.valid).toBeFalsy();

        occurrenceDate?.setValue('');
        expect(occurrenceDate?.hasError('required')).toBeTruthy();
    });

    it('should fail to validate occurrence time control', () => {
        const occurrenceTime = component.occurrenceTime;
        occurrenceTime.setValue('invalid time');
        expect(occurrenceTime.valid).toBeFalsy();
    });

    it('should validate occurrence time control successfully', () => {
        const occurrenceTime = component.occurrenceTime;
        occurrenceTime.setValue('10:00');
        expect(occurrenceTime.valid).toBeTruthy();
    });

    it('should validate occurrence place control', () => {
        const occurrencePlace = component.occurrencePlace;
        expect(occurrencePlace?.valid).toBeFalsy();

        occurrencePlace?.setValue('');
        expect(occurrencePlace?.hasError('required')).toBeTruthy();
    });

    it('should validate circumstances control', () => {
        const circumstances = component.circumstances;
        expect(circumstances?.valid).toBeFalsy();

        circumstances?.setValue('');
        expect(circumstances?.hasError('required')).toBeTruthy();
    });

    [
        { isResponsible: null, disabled: true },
        { isResponsible: true, disabled: false },
        { isResponsible: false, disabled: true },
    ].forEach((testObject) => {
        it('should toggle third party responibility controls disabled status', () => {
            component.isThirdPartyResponsible.setValue(
                testObject.isResponsible,
            );

            expect(component.responsibleFirstName.disabled).toBe(
                testObject.disabled,
            );
            expect(component.responsibleLastName.disabled).toBe(
                testObject.disabled,
            );
            expect(component.responsibleLiabilityInsurerName.disabled).toBe(
                testObject.disabled,
            );
            expect(component.responsiblePhoneNumber.disabled).toBe(
                testObject.disabled,
            );
            expect(component.responsibleEmail.disabled).toBe(
                testObject.disabled,
            );
            expect(component.responsibleGender.disabled).toBe(
                testObject.disabled,
            );
        });
    });

    it('should enable witnesses form', () => {
        component.hasWitness.setValue(true);
        expect(component.formGroup.controls.witnesses).toBeDefined();
        expect(component.formGroup.controls.witnesses?.disabled).toBe(false);
    });

    it('should disable witnesses form', () => {
        component.hasWitness.setValue(false);
        expect(component.formGroup.controls.witnesses).toBeDefined();
        expect(component.formGroup.controls.witnesses?.disabled).toBe(true);
    });
});
