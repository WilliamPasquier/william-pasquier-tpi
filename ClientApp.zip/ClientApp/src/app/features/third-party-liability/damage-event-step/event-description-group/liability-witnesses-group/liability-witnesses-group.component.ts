import { Component, OnInit } from '@angular/core';
import {
    ControlContainer,
    FormArray,
    FormBuilder,
    FormGroup,
    FormGroupDirective,
    Validators,
} from '@angular/forms';
import { LiabilityEventDescriptionFormGroup } from '@models/form-groups/liability-event-description-form-group.model';
import { LiabilityWitnessFormGroup } from '@models/form-groups/liability-witness-form-group.model';

@Component({
    selector: 'hf-liability-witnesses-group',
    templateUrl: './liability-witnesses-group.component.html',
    styleUrls: ['./liability-witnesses-group.component.scss'],
    viewProviders: [
        {
            provide: ControlContainer,
            useExisting: FormGroupDirective,
        },
    ],
})
export class LiabilityWitnessesGroupComponent implements OnInit {
    /**
     * Witnesses form group.
     */
    formArray: FormArray<FormGroup<LiabilityWitnessFormGroup>>;

    /**
     * Group of witnesses that will be added to the form
     * @returns array of witnesses
     */
    get witnesses(): FormArray<FormGroup<LiabilityWitnessFormGroup>> {
        return this.formArray;
    }

    constructor(
        private fb: FormBuilder,
        private parent: FormGroupDirective,
    ) {}

    /**
     * @inheritdoc
     */
    ngOnInit(): void {
        this.formArray = this.fb.array([this.buildWitnessGroup()]);

        (
            this.parent.form as FormGroup<LiabilityEventDescriptionFormGroup>
        ).setControl('witnesses', this.formArray);
    }

    /**
     * Builds a witness with all its properties
     * @returns witness group object
     */
    buildWitnessGroup(): FormGroup<LiabilityWitnessFormGroup> {
        const witness = this.fb.group<LiabilityWitnessFormGroup>({
            lastName: this.fb.control<string | null>('', [Validators.required]),
            firstName: this.fb.control<string | null>('', [
                Validators.required,
            ]),
            phoneNumber: this.fb.nonNullable.control<string>('', {
                updateOn: 'blur',
            }),
            email: this.fb.control<string | null>('', [Validators.email]),
        });

        return witness;
    }

    /**
     * Adds new witness to the array of witnesses
     */
    addWitness(): void {
        const witnessdObject = this.buildWitnessGroup();
        this.witnesses.push(witnessdObject);
    }

    /**
     * Removes witness from the array with the selected index
     * @param objectIndex - index of the witnesses
     */
    removeWitness(objectIndex: number): void {
        this.witnesses.removeAt(objectIndex);
    }
}
