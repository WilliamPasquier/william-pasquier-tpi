import { Component, Input, OnInit } from '@angular/core';
import {
    FormBuilder,
    FormGroup,
    FormGroupDirective,
    Validators,
} from '@angular/forms';
import { LiabilityDamageDescriptionFormGroup } from '@models/form-groups/liability-damage-description-form-group.model';
import { LiabilityDamageEventStepFormGroup } from '@models/form-groups/liability-damage-event-step-form-group.model';
import { LiabilityDamageType } from '@models/liability-damage-type.enum';
import { LiabilityDeclarerType } from '@models/liability-declarer-type.enum';
import { TranslocoService } from '@ngneat/transloco';
import { ListItem } from '@shared/models/list-item';

/**
 * The ordered list of damage types to be displayed on the component.
 */
const damageTypeOrderedList = [
    LiabilityDamageType.PropertyDamage,
    LiabilityDamageType.CorporalInjury,
    LiabilityDamageType.AnimalDamage,
    LiabilityDamageType.RentedPremisesDamage,
];

@Component({
    selector: 'hf-liability-damage-description-group',
    templateUrl: './liability-damage-description-group.component.html',
    styleUrls: ['./liability-damage-description-group.component.scss'],
})
export class LiabilityDamageDescriptionGroupComponent implements OnInit {
    /**
     * The declarer type.
     */
    private _declarerType: LiabilityDeclarerType | null;

    /**
     * True if the damage type is rented premises.
     */
    isRentedPremisesOrPropertyDamage: boolean;

    /**
     * True if the damage type is an animal.
     */
    isAnimalDamage: boolean;

    /**
     * True if the damage type is a corporal injury.
     */
    isCorporalInjury: boolean;

    /**
     * Get's whether the declarer of the claim is the injured party.
     * @returns True whether the declarer of the claim is the injured party, false otherwise.
     */
    isInjuredParty: boolean;

    /**
     * Damage description form group.
     */
    formGroup: FormGroup<LiabilityDamageDescriptionFormGroup>;

    /**
     * List of option for the has work incapacity field.
     */
    hasWorkIncapacityItems: Array<ListItem> = [
        { i18nKey: 'common.yes', value: true },
        { i18nKey: 'common.no', value: false },
        { i18nKey: 'common.noInformation', value: '' },
    ];

    /**
     * The insured relationship with the injured party field.
     */
    insuredInjuredPartyRelationship = this.fb.control<string | null>('', [
        Validators.required,
    ]);

    /**
     * The damaged object type field.
     */
    damagedObjectType = this.fb.control<string | null>('', [
        Validators.required,
    ]);

    /**
     * The repair cost field.
     */
    repairCost = this.fb.control<string | null>('');

    /**
     * the property management name field.
     */
    propertyManagementName = this.fb.control<string | null>('');

    /**
     * The animal type field.
     */
    animalType = this.fb.control<string | null>('', [Validators.required]);

    /**
     * The injuries type field.
     */
    injuriesType = this.fb.control<string | null>('', [Validators.required]);

    /**
     * The accident insurer field.
     */
    accidentInsurer = this.fb.control<string | null>('');

    /**
     * The work incapacity status field.
     */
    hasWorkIncapacity = this.fb.control<boolean | null>(null);

    /**
     * The occupation field.
     */
    occupation = this.fb.control<string | null>('');

    /**
     * The employer field.
     */
    employer = this.fb.control<string | null>('');

    /**
     * Reactive form control for damage type field.
     */
    damageType = this.fb.nonNullable.control<Array<LiabilityDamageType>>(
        [],
        [Validators.required],
    );

    /**
     * List of damage yype used in damageType formcontrol.
     */
    damageTypeItems: Array<ListItem> = [];

    /**
     * The declarer type input setter.
     */
    @Input() set declarerType(declarerType: LiabilityDeclarerType | null) {
        this._declarerType = declarerType;

        this.toggleInjuredPartyForm();
        this.toggleDamageType(this.damageType.value);
    }

    constructor(
        private fb: FormBuilder,
        private parent: FormGroupDirective,
        private readonly translocoService: TranslocoService,
    ) {}

    /**
     * @inheritdoc
     */
    ngOnInit(): void {
        this.initDamageTypeItems();
        this.formGroup = this.fb.group<LiabilityDamageDescriptionFormGroup>({
            damageType: this.damageType,
            insuredInjuredPartyRelationship:
                this.insuredInjuredPartyRelationship,
            damagedObjectType: this.damagedObjectType,
            repairCost: this.repairCost,
            propertyManagementName: this.propertyManagementName,
            animalType: this.animalType,
            injuriesType: this.injuriesType,
            accidentInsurer: this.accidentInsurer,
            hasWorkIncapacity: this.hasWorkIncapacity,
            occupation: this.occupation,
            employer: this.employer,
        });

        this.damageType.valueChanges.subscribe({
            next: (value: Array<LiabilityDamageType>) =>
                this.toggleDamageType(value),
        });

        (
            this.parent.form as FormGroup<LiabilityDamageEventStepFormGroup>
        ).setControl('damageDescription', this.formGroup);

        this.toggleInjuredPartyForm();
    }

    /**
     * Toggle injured party.
     */
    toggleInjuredPartyForm() {
        if (this._declarerType !== LiabilityDeclarerType.InjuredParty) {
            this.formGroup?.controls.injuredParty?.enable();
            this.isInjuredParty = true;
        } else {
            this.isInjuredParty = false;
            this.formGroup?.controls.injuredParty?.disable();
        }
    }

    /**
     * Toggle fields based on the damage type.
     * @param type - the liability damage type.
     */
    toggleDamageType(type: Array<LiabilityDamageType>) {
        this.propertyManagementName?.disable();
        this.damagedObjectType?.disable();
        this.damagedObjectType?.disable();
        this.repairCost?.disable();
        this.animalType?.disable();
        this.injuriesType?.disable();
        this.accidentInsurer?.disable();
        this.hasWorkIncapacity?.disable();
        this.occupation?.disable();
        this.employer?.disable();
        this.isRentedPremisesOrPropertyDamage = false;
        this.isAnimalDamage = false;
        this.isCorporalInjury = false;

        if (type.includes(LiabilityDamageType.RentedPremisesDamage)) {
            if (
                this._declarerType !== LiabilityDeclarerType.PropertyManagement
            ) {
                this.propertyManagementName?.enable();
            }
            this.damagedObjectType?.enable();
            this.repairCost?.enable();
            this.isRentedPremisesOrPropertyDamage = true;
        }
        if (type.includes(LiabilityDamageType.PropertyDamage)) {
            this.damagedObjectType?.enable();
            this.repairCost?.enable();
            this.isRentedPremisesOrPropertyDamage = true;
        }
        if (type.includes(LiabilityDamageType.AnimalDamage)) {
            this.animalType?.enable();
            this.isAnimalDamage = true;
        }
        if (type.includes(LiabilityDamageType.CorporalInjury)) {
            this.injuriesType?.enable();
            this.accidentInsurer?.enable();
            this.hasWorkIncapacity?.enable();
            this.occupation?.enable();
            this.employer?.enable();
            this.isCorporalInjury = true;
        }
    }

    initDamageTypeItems(): void {

        this.damageTypeItems = damageTypeOrderedList.map((value)=> {

            const item: ListItem = {
                i18nKey: `thirdPartyLiability.damageType.${value}`,
                value,
                
            };
            item.text = this.translocoService
                // eslint-disable-next-line @typescript-eslint/no-non-null-assertion
                .translate(item.i18nKey!);
            return item;
        });
    }
}
