import { ComponentFixture, TestBed } from '@angular/core/testing';
import {
    FormBuilder,
    FormControl,
    FormGroup,
    FormGroupDirective,
    ReactiveFormsModule,
} from '@angular/forms';
import { LiabilityDamageDescriptionFormGroup } from '@models/form-groups/liability-damage-description-form-group.model';
import { LiabilityDamageType } from '@models/liability-damage-type.enum';
import { FieldInfoComponent } from '@shared/components/field-info/field-info.component';
import { PhoneNumberComponent } from '@shared/components/phone-number/phone-number.component';
import { RadioButtonGroupComponent } from '@shared/components/radio-button-group/radio-button-group.component';
import { ValidationMessagesComponent } from '@shared/components/validation-messages/validation-messages.component';
import { getTranslocoTestingModule } from '@testing/transloco-testing.module';
import { MockComponents } from 'ng-mocks';

import { InjuredPartyDamageGroupComponent } from './injured-party-damage-group.component';
import { LiabilityDeclarerType } from '@models/liability-declarer-type.enum';

describe('InjuredPartyDamageGroupComponent', () => {
    let component: InjuredPartyDamageGroupComponent;
    let fixture: ComponentFixture<InjuredPartyDamageGroupComponent>;
    let mockFormGroup: FormGroup<LiabilityDamageDescriptionFormGroup>;

    beforeEach(async () => {
        mockFormGroup = new FormGroup<LiabilityDamageDescriptionFormGroup>({
            damageType: new FormBuilder().nonNullable.control<Array<LiabilityDamageType>>([]),
            insuredInjuredPartyRelationship: new FormControl<string | null>(
                null,
            ),
            damagedObjectType: new FormControl<string | null>(null),
            repairCost: new FormControl<string | null>(null),
            propertyManagementName: new FormControl<string | null>(null),
            animalType: new FormControl<string | null>(null),
            injuriesType: new FormControl<string | null>(null),
            accidentInsurer: new FormControl<string | null>(null),
            hasWorkIncapacity: new FormControl<boolean | null>(null),
            occupation: new FormControl<string | null>(null),
            employer: new FormControl<string | null>(null),
        });

        const formGroupDirective = new FormGroupDirective([], []);
        formGroupDirective.form = mockFormGroup;

        await TestBed.configureTestingModule({
            imports: [getTranslocoTestingModule(), ReactiveFormsModule],
            declarations: [
                InjuredPartyDamageGroupComponent,
                ...MockComponents(
                    ValidationMessagesComponent,
                    RadioButtonGroupComponent,
                    FieldInfoComponent,
                    PhoneNumberComponent,
                ),
            ],
            providers: [
                FormBuilder,
                { provide: FormGroupDirective, useValue: formGroupDirective },
            ],
        }).compileComponents();

        fixture = TestBed.createComponent(InjuredPartyDamageGroupComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });

    it('should add the FormControl to the parent form', () => {
        expect(mockFormGroup.controls.injuredParty).toBeDefined();
    });

    it('should be enabled for declarer type advisor', () => {
        component.declarerType = LiabilityDeclarerType.Advisor;
        expect(component.formGroup.disabled).toBe(false);
    });

    it('should be enabled for declarer type injuredParty', () => {
        component.declarerType = LiabilityDeclarerType.InjuredParty;
        expect(component.formGroup.disabled).toBe(true);
    });

    it('should be disabled for declarer type policyholder', () => {
        component.declarerType = LiabilityDeclarerType.Policyholder;
        expect(component.formGroup.disabled).toBe(false);
    });

    it('should be enabled for declarer type propertyManagement', () => {
        component.declarerType = LiabilityDeclarerType.PropertyManagement;
        expect(component.formGroup.disabled).toBe(false);
    });
});
