import { ComponentFixture, TestBed } from '@angular/core/testing';
import {
    FormBuilder,
    FormControl,
    FormGroup,
    FormGroupDirective,
    ReactiveFormsModule,
} from '@angular/forms';
import { FieldInfoComponent } from '@shared/components/field-info/field-info.component';
import { PhoneNumberComponent } from '@shared/components/phone-number/phone-number.component';
import { RadioButtonGroupComponent } from '@shared/components/radio-button-group/radio-button-group.component';
import { ValidationMessagesComponent } from '@shared/components/validation-messages/validation-messages.component';
import { getTranslocoTestingModule } from '@testing/transloco-testing.module';
import { MockComponents } from 'ng-mocks';
import { LiabilityDamageDescriptionGroupComponent } from './liability-damage-description-group.component';
import { InjuredPartyDamageGroupComponent } from './injured-party-damage-group/injured-party-damage-group.component';
import { LiabilityDamageEventStepFormGroup } from '@models/form-groups/liability-damage-event-step-form-group.model';
import { LiabilityDamageCausedBy } from '@models/liability-damage-caused-by.enum';
import { LiabilityDamageType } from '@models/liability-damage-type.enum';
import { LiabilityDeclarerType } from '@models/liability-declarer-type.enum';
import { CheckboxGroupComponent } from '@shared/components/checkbox-group/checkbox-group.component';

describe('LiabilityDamageDescriptionGroupComponent', () => {
    let component: LiabilityDamageDescriptionGroupComponent;
    let fixture: ComponentFixture<LiabilityDamageDescriptionGroupComponent>;
    let mockFormGroup: FormGroup<LiabilityDamageEventStepFormGroup>;

    beforeEach(async () => {
        mockFormGroup = new FormGroup<LiabilityDamageEventStepFormGroup>({
            damageCausedBy: new FormControl<LiabilityDamageCausedBy | null>(
                null,
            ),
        });

        const formGroupDirective = new FormGroupDirective([], []);
        formGroupDirective.form = mockFormGroup;

        await TestBed.configureTestingModule({
            imports: [getTranslocoTestingModule(), ReactiveFormsModule],
            declarations: [
                LiabilityDamageDescriptionGroupComponent,
                ...MockComponents(
                    InjuredPartyDamageGroupComponent,
                    ValidationMessagesComponent,
                    RadioButtonGroupComponent,
                    FieldInfoComponent,
                    PhoneNumberComponent,
                    CheckboxGroupComponent,
                ),
            ],
            providers: [
                FormBuilder,
                { provide: FormGroupDirective, useValue: formGroupDirective },
            ],
        }).compileComponents();

        fixture = TestBed.createComponent(
            LiabilityDamageDescriptionGroupComponent,
        );
        component = fixture.componentInstance;
        component.damageType = new FormBuilder().nonNullable.control<Array<LiabilityDamageType>>(
            [],
        );
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });

    it('should add the FormControl to the parent form', () => {
        expect(mockFormGroup.controls.damageDescription).toBeDefined();
    });

    it(`should have the expected disabled status for animal damage type`, () => {
        component.damageType.setValue([LiabilityDamageType.AnimalDamage]);
        fixture.detectChanges();
        expect(component.insuredInjuredPartyRelationship.disabled).toBe(false);
        expect(component.damagedObjectType.disabled).toBe(true);
        expect(component.repairCost.disabled).toBe(true);
        expect(component.propertyManagementName.disabled).toBe(true);
        expect(component.animalType.disabled).toBe(false);
        expect(component.injuriesType.disabled).toBe(true);
        expect(component.accidentInsurer.disabled).toBe(true);
        expect(component.hasWorkIncapacity.disabled).toBe(true);
        expect(component.occupation.disabled).toBe(true);
        expect(component.employer.disabled).toBe(true);
    });

    it(`should have the expected disabled status for corporal damage type`, () => {
        component.damageType.setValue([LiabilityDamageType.CorporalInjury]);
        expect(component.insuredInjuredPartyRelationship.disabled).toBe(false);
        expect(component.damagedObjectType.disabled).toBe(true);
        expect(component.repairCost.disabled).toBe(true);
        expect(component.propertyManagementName.disabled).toBe(true);
        expect(component.animalType.disabled).toBe(true);
        expect(component.injuriesType.disabled).toBe(false);
        expect(component.accidentInsurer.disabled).toBe(false);
        expect(component.hasWorkIncapacity.disabled).toBe(false);
        expect(component.occupation.disabled).toBe(false);
        expect(component.employer.disabled).toBe(false);
    });

    it(`should have the expected disabled status for selected damage type`, () => {
        component.damageType.setValue([LiabilityDamageType.PropertyDamage]);
        expect(component.insuredInjuredPartyRelationship.disabled).toBe(false);
        expect(component.damagedObjectType.disabled).toBe(false);
        expect(component.repairCost.disabled).toBe(false);
        expect(component.propertyManagementName.disabled).toBe(true);
        expect(component.animalType.disabled).toBe(true);
        expect(component.injuriesType.disabled).toBe(true);
        expect(component.accidentInsurer.disabled).toBe(true);
        expect(component.hasWorkIncapacity.disabled).toBe(true);
        expect(component.occupation.disabled).toBe(true);
        expect(component.employer.disabled).toBe(true);
    });

    it(`should have the expected disabled status for rented premises damage type`, () => {
        component.declarerType = LiabilityDeclarerType.PropertyManagement;
        component.damageType.setValue([LiabilityDamageType.RentedPremisesDamage]);
        expect(component.insuredInjuredPartyRelationship.disabled).toBe(false);
        expect(component.damagedObjectType.disabled).toBe(false);
        expect(component.repairCost.disabled).toBe(false);
        expect(component.propertyManagementName.disabled).toBe(true);
        expect(component.animalType.disabled).toBe(true);
        expect(component.injuriesType.disabled).toBe(true);
        expect(component.accidentInsurer.disabled).toBe(true);
        expect(component.hasWorkIncapacity.disabled).toBe(true);
        expect(component.occupation.disabled).toBe(true);
        expect(component.employer.disabled).toBe(true);

        expect(component.isAnimalDamage).toBe(false);
        expect(component.isCorporalInjury).toBe(false);
        expect(component.isRentedPremisesOrPropertyDamage).toBe(true);
    });

    [
        LiabilityDeclarerType.Advisor,
        LiabilityDeclarerType.InjuredParty,
        LiabilityDeclarerType.Policyholder,
    ].forEach((declarerType) => {
        it(`should have the expected disabled status for ${declarerType} and also after switch to Property Management`, () => {
            component.declarerType = declarerType;
            component.damageType.setValue([LiabilityDamageType.RentedPremisesDamage]);
            expect(component.propertyManagementName.disabled).toBe(false);

            component.declarerType = LiabilityDeclarerType.PropertyManagement;
            expect(component.propertyManagementName.disabled).toBe(true);

            component.declarerType = declarerType;
            expect(component.propertyManagementName.disabled).toBe(false);
        });
    });
});
