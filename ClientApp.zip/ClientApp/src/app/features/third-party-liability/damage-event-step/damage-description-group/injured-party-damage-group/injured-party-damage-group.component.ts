import { Component, Input, OnInit } from '@angular/core';
import {
    FormBuilder,
    FormGroup,
    FormGroupDirective,
    Validators,
} from '@angular/forms';
import { LiabilityInjuredPartyFormGroup } from '@models/form-groups/liability-injured-party-form-group';
import { LiabilityDamageDescriptionFormGroup } from '@models/form-groups/liability-damage-description-form-group.model';
import { LiabilityDeclarerType } from '@models/liability-declarer-type.enum';
import { date } from '@shared/validators/date';

@Component({
    selector: 'hf-injured-party-damage-group',
    templateUrl: './injured-party-damage-group.component.html',
    styleUrls: ['./injured-party-damage-group.component.scss'],
})
export class InjuredPartyDamageGroupComponent implements OnInit {
    /**
     * The declarer type.
     */
    private _declarerType: LiabilityDeclarerType | null;

    formGroup: FormGroup<LiabilityInjuredPartyFormGroup>;

    /**
     * The last name form control.
     */
    lastName = this.fb.nonNullable.control<string>('', [Validators.required]);

    /**
     * The first name form control.
     */
    firstName = this.fb.nonNullable.control<string>('', [Validators.required]);

    /**
     * Birthdate control.
     */
    birthdate = this.fb.control<string | null>('', {
        validators: [date],
        updateOn: 'blur',
    });

    /**
     * The phone number form control.
     */
    phoneNumber = this.fb.nonNullable.control<string>('', { updateOn: 'blur' });

    /**
     * The email form control.
     */
    email = this.fb.nonNullable.control<string>('', {
        validators: [Validators.email],
        updateOn: 'blur',
    });

    /**
     * Country control.
     */
    country = this.fb.control<string | null>('', [Validators.required]);

    /**
     * Postal code control.
     */
    postalCode = this.fb.control<number | null>(null, [Validators.required]);

    /**
     * Locality control.
     */
    locality = this.fb.control<string | null>(null, [Validators.required]);

    /**
     * The first name form control.
     */
    street = this.fb.nonNullable.control<string>('', [Validators.required]);

    /**
     * The declarer type input setter.
     */
    @Input() set declarerType(declarerType: LiabilityDeclarerType | null) {
        this._declarerType = declarerType;

        this.toggleFieldStatuses(declarerType);
    }

    constructor(
        private fb: FormBuilder,
        private parent: FormGroupDirective,
    ) {}

    /**
     * @inheritdoc
     */
    ngOnInit(): void {
        this.formGroup = this.fb.group<LiabilityInjuredPartyFormGroup>({
            lastName: this.lastName,
            firstName: this.firstName,
            birthdate: this.birthdate,
            phoneNumber: this.phoneNumber,
            email: this.email,
            country: this.country,
            postalCode: this.postalCode,
            locality: this.locality,
            street: this.street,
        });

        (
            this.parent.form as FormGroup<LiabilityDamageDescriptionFormGroup>
        ).setControl('injuredParty', this.formGroup);

        this.toggleFieldStatuses(this._declarerType);
    }

    /**
     * Toggle field statuses based on declarer type.
     * @param declarerType - the declarer type.
     */
    private toggleFieldStatuses(declarerType: LiabilityDeclarerType | null) {
        if (declarerType !== LiabilityDeclarerType.InjuredParty) {
            this.formGroup?.enable();
        } else {
            this.formGroup?.disable();
        }
    }
}
