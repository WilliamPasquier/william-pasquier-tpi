import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import {
    FormBuilder,
    FormGroup,
    FormGroupDirective,
    ReactiveFormsModule,
} from '@angular/forms';
import { LiabilityDamageClaimFormGroup } from '@models/form-groups/liability-damage-claim-form-group.model';
import { FieldInfoComponent } from '@shared/components/field-info/field-info.component';
import { ValidationMessagesComponent } from '@shared/components/validation-messages/validation-messages.component';
import { getTranslocoTestingModule } from '@testing/transloco-testing.module';
import { MockComponents } from 'ng-mocks';
import { LiabilityDamageEventStepComponent } from './liability-damage-event-step.component';
import { LiabilityEventDescriptionGroupComponent } from './event-description-group/liability-event-description-group.component';

describe('LiabilityDamageEventStepComponent', () => {
    let component: LiabilityDamageEventStepComponent;
    let fixture: ComponentFixture<LiabilityDamageEventStepComponent>;
    let formGroupDirective: FormGroupDirective;
    let mockFormGroup: FormGroup<LiabilityDamageClaimFormGroup>;

    beforeEach(async () => {
        const fb = new FormBuilder();
        mockFormGroup = new FormGroup({
            recaptcha: fb.nonNullable.control<string | null>(''),
        });

        formGroupDirective = new FormGroupDirective([], []);
        formGroupDirective.form = mockFormGroup;

        await TestBed.configureTestingModule({
            imports: [getTranslocoTestingModule(), ReactiveFormsModule],
            declarations: [
                LiabilityDamageEventStepComponent,
                ...MockComponents(
                    ValidationMessagesComponent,
                    FieldInfoComponent,
                    LiabilityEventDescriptionGroupComponent,
                ),
            ],
            providers: [
                FormBuilder,
                { provide: FormGroupDirective, useValue: formGroupDirective },
            ],
            schemas: [CUSTOM_ELEMENTS_SCHEMA],
        }).compileComponents();

        fixture = TestBed.createComponent(LiabilityDamageEventStepComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });

    it('should add the FormControl to the parent form', () => {
        expect(mockFormGroup.controls.damageEvent).toBeDefined();
    });
});
