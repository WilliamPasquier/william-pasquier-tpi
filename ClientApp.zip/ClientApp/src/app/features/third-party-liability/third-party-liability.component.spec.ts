import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ReactiveFormsModule } from '@angular/forms';
import { RecaptchaComponentMock } from '@shared/components/recaptcha.mock';
import { ValidationMessagesComponent } from '@shared/components/validation-messages/validation-messages.component';
import { getTranslocoTestingModule } from '@testing/transloco-testing.module';
import { MockComponents, MockProvider } from 'ng-mocks';

import { ThirdPartyLiabilityComponent } from './third-party-liability.component';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { LiabilityDamageEventStepComponent } from './damage-event-step/liability-damage-event-step.component';
import { InjuredPartyDamageGroupComponent } from './damage-event-step/damage-description-group/injured-party-damage-group/injured-party-damage-group.component';
import { LiabilityDamageDescriptionGroupComponent } from './damage-event-step/damage-description-group/liability-damage-description-group.component';
import { LiabilityEventDescriptionGroupComponent } from './damage-event-step/event-description-group/liability-event-description-group.component';
import { LiabilityWitnessesGroupComponent } from './damage-event-step/event-description-group/liability-witnesses-group/liability-witnesses-group.component';
import { LiabilityDeclarerContactGroupComponent } from './insurance-holder-step/declarer-contact-group/liability-declarer-contact-group.component';
import { LiabilityHolderContactGroupComponent } from './insurance-holder-step/holder-contact-group/liability-holder-contact-group.component';
import { LiabilityInsuranceHolderStepComponent } from './insurance-holder-step/liability-insurance-holder-step.component';
import { LiabilityAdditionalInfoStepComponent } from './liability-additional-info-step/liability-additional-info-step.component';
import { FieldInfoComponent } from '@shared/components/field-info/field-info.component';
import { PhoneNumberComponent } from '@shared/components/phone-number/phone-number.component';
import { RadioButtonGroupComponent } from '@shared/components/radio-button-group/radio-button-group.component';
import { LiabilityClaimService } from '@services/liability-claim/liability-claim.service';
import { Subject } from 'rxjs';
import { LiabilityDamageCausedBy } from '@models/liability-damage-caused-by.enum';
import { LiabilityDeclarerType } from '@models/liability-declarer-type.enum';
import { Router } from '@angular/router';
import { ClaimFilesComponent } from '@shared/components/claim-files/claim-files.component';
import { CheckboxGroupComponent } from '@shared/components/checkbox-group/checkbox-group.component';
import { LiabilityDamageType } from '@models/liability-damage-type.enum';
import { TooltipModule } from 'primeng/tooltip';

describe('ThirdPartyLiabilityComponent', () => {
    let component: ThirdPartyLiabilityComponent;
    let fixture: ComponentFixture<ThirdPartyLiabilityComponent>;
    let mockLiabilityClaimService: jasmine.SpyObj<LiabilityClaimService>;
    let subject: Subject<{ claimNumber: string }>;
    const buildValidFormData = {
        insuranceHolder: {
            declarerType: LiabilityDeclarerType.Policyholder,
            holderContact: {
                firstName: 'Me',
                lastName: 'Too',
                birthdate: '01.01.1980',
                country: 'CH',
                email: 'test@test.com',
                locality: 'Lausanne',
                phoneNumber: '+41796865959',
                postalCode: 1001,
                street: 'ici 3',
                contractNumber: '123456',
                iban: 'CH00',
                legalProtection: '',
            },
        },
        damageEvent: {
            damageCausedBy: LiabilityDamageCausedBy.AnimalDamage,
            eventDescription: {
                circumstances: 'House Fire',
                occurrenceDate: '12.12.2022',
                occurrencePlace: 'Porto',
                occurrenceTime: '14:32',
                hasPoliceReport: false,
                hasWitness: false,
                witnesses: [
                    {
                        firstName: null,
                        lastName: null,
                        email: null,
                        phoneNumber: null,
                    },
                ],
                isInsuredResponsible: false,
                isThirdPartyResponsible: false,
                responsibleFirstName: null,
                responsibleLastName: null,
                responsibleEmail: null,
                responsiblePhoneNumber: null,
                responsibleLiabilityInsurerName: null,
                responsibleGender: null,
            },
            damageDescription: {
                damageType: [LiabilityDamageType.AnimalDamage],
                injuredParty: {
                    firstName: 'Me',
                    lastName: 'Too',
                    birthdate: '01.01.1980',
                    country: 'CH',
                    email: 'test@test.com',
                    locality: 'Lausanne',
                    phoneNumber: '+41796865959',
                    postalCode: 1001,
                    street: 'ici 3',
                },
                insuredInjuredPartyRelationship: 'friend',
                damagedObjectType: 'dog',
                repairCost: null,
                propertyManagementName: null,
                animalType: 'The one',
                injuriesType: 'death',
                accidentInsurer: null,
                hasWorkIncapacity: null,
                occupation: null,
                employer: null,
            },
        },
        additionalInfo: {
            isRelatedToAnotherDomesticAccident: false,
            domesticClaimNumber: null,
            otherRemarks: 'Comments',
        },
        recaptcha: 'recaptcha',
        files: [],
    };

    beforeEach(async () => {
        subject = new Subject<{ claimNumber: string }>();
        mockLiabilityClaimService = jasmine.createSpyObj<LiabilityClaimService>(
            'LiabilityClaimService',
            ['sendClaimRequest'],
        );
        mockLiabilityClaimService.sendClaimRequest.and.returnValue(subject);

        await TestBed.configureTestingModule({
            imports: [
                getTranslocoTestingModule(),
                ReactiveFormsModule,
                HttpClientTestingModule,
                TooltipModule,
            ],
            declarations: [
                ThirdPartyLiabilityComponent,
                LiabilityInsuranceHolderStepComponent,
                LiabilityHolderContactGroupComponent,
                LiabilityDeclarerContactGroupComponent,
                LiabilityDamageEventStepComponent,
                LiabilityEventDescriptionGroupComponent,
                LiabilityWitnessesGroupComponent,
                LiabilityDamageDescriptionGroupComponent,
                InjuredPartyDamageGroupComponent,
                LiabilityAdditionalInfoStepComponent,
                ...MockComponents(
                    ValidationMessagesComponent,
                    RecaptchaComponentMock,
                    RadioButtonGroupComponent,
                    FieldInfoComponent,
                    PhoneNumberComponent,
                    ClaimFilesComponent,
                    CheckboxGroupComponent,
                ),
            ],
            providers: [
                {
                    provide: LiabilityClaimService,
                    useValue: mockLiabilityClaimService,
                },
                MockProvider(Router),
            ],
            schemas: [CUSTOM_ELEMENTS_SCHEMA],
        }).compileComponents();

        document.body.append(document.createElement('hf-root'));
        fixture = TestBed.createComponent(ThirdPartyLiabilityComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });

    it('should form data be valid', () => {
        fixture.detectChanges();

        component.formGroup.setValue(buildValidFormData);

        expect(component.formGroup.valid).toBeTrue();
    });

    it('should submit', () => {
        fixture.detectChanges();

        component.formGroup.setValue(buildValidFormData);

        expect(component.formGroup.valid).toBeTrue();

        component.onSubmit();
        subject.next({ claimNumber: 'sdfsdf' });

        expect(mockLiabilityClaimService.sendClaimRequest).toHaveBeenCalled();
    });

    it('should display loading panel on form submission', () => {
        component.formGroup.setValue(buildValidFormData);

        component.onSubmit();

        // Check that the loading panel is displayed
        expect(component.isProcessing).toBeTrue();

        // Advance the fixture's clock to allow time for the loading panel to appear
        fixture.detectChanges();

        // Check that the loading panel element is in the DOM
        const loadingPanel =
            fixture.nativeElement.querySelector('.loading-panel');
        expect(loadingPanel).toBeTruthy();

        // Simulate the completion of the form submission
        subject.error({ error: 'failed' });
        expect(component.isProcessing).toBeFalse();

        // Wait for the loading panel to disappear
        fixture.detectChanges();

        // Check that the loading panel element is no longer in the DOM
        const loadingPanelAfterSubmit =
            fixture.nativeElement.querySelector('.loading-panel');
        expect(loadingPanelAfterSubmit).toBeFalsy();
    });

    it('should fail submit', () => {
        fixture.detectChanges();

        component.formGroup.setValue(buildValidFormData);

        expect(component.formGroup.valid).toBeTrue();

        component.onSubmit();
        subject.error({ error: 'failed' });

        expect(mockLiabilityClaimService.sendClaimRequest).toHaveBeenCalled();
    });
});
