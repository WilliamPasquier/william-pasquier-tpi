import { ComponentFixture, TestBed } from '@angular/core/testing';
import {
    FormBuilder,
    FormGroup,
    FormGroupDirective,
    ReactiveFormsModule,
} from '@angular/forms';
import { DeclarerType } from '@models/declarer-type.enum';
import { DeclarerContactFormGroup } from '@models/form-groups/declarer-contact-form-group.model';
import { FieldInfoComponent } from '@shared/components/field-info/field-info.component';
import { RadioButtonGroupComponent } from '@shared/components/radio-button-group/radio-button-group.component';
import { ValidationMessagesComponent } from '@shared/components/validation-messages/validation-messages.component';
import { getTranslocoTestingModule } from '@testing/transloco-testing.module';
import { MockComponents } from 'ng-mocks';
import { DeclarerContactGroupComponent } from './declarer-contact-group/declarer-contact-group.component';
import { HolderContactGroupComponent } from './holder-contact-group/holder-contact-group.component';
import { InsuranceHolderStepComponent } from './insurance-holder-step.component';

describe('InsuranceHolderStepComponent', () => {
    let component: InsuranceHolderStepComponent;
    let fixture: ComponentFixture<InsuranceHolderStepComponent>;

    beforeEach(async () => {
        await TestBed.configureTestingModule({
            imports: [getTranslocoTestingModule(), ReactiveFormsModule],
            declarations: [
                InsuranceHolderStepComponent,
                ...MockComponents(
                    ValidationMessagesComponent,
                    RadioButtonGroupComponent,
                    DeclarerContactGroupComponent,
                    HolderContactGroupComponent,
                    FieldInfoComponent,
                ),
            ],
            providers: [
                FormBuilder,
                {
                    provide: FormGroupDirective,
                },
            ],
        }).compileComponents();

        fixture = TestBed.createComponent(InsuranceHolderStepComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });

    it('should retrieve the formGroup from the formStateService', () => {
        expect(component.formGroup).toBeDefined();
    });

    [
        { declarerType: DeclarerType.Advisor, expectedStatus: false },
        { declarerType: DeclarerType.Broker, expectedStatus: false },
        { declarerType: DeclarerType.Policyholder, expectedStatus: true },
    ].forEach((testObject) => {
        it(`should show the correct fields for declarer type ${testObject.declarerType}`, () => {
            const fb = new FormBuilder();
            component.formGroup.setControl(
                'declarerContact',
                new FormGroup<DeclarerContactFormGroup>({
                    firstName: fb.nonNullable.control<string>(''),
                    lastName: fb.nonNullable.control<string>(''),
                    email: fb.nonNullable.control<string>(''),
                    phoneNumber: fb.nonNullable.control<string>(''),
                }),
            );

            component.declarerType.setValue(testObject.declarerType);
            fixture.detectChanges();

            expect(component.formGroup.controls.declarerContact?.disabled).toBe(
                testObject.expectedStatus,
            );
        });
    });
});
