import { Component, Input, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { HolderContactFormGroup } from '@models/form-groups/holder-contact-form-group.model';
import { maxBirthDateDeltaInYears } from '@shared/constants/constants';
import { DateConstants, dateYearsInThePast } from '@va-ngx-shared';

@Component({
    selector: 'hf-holder-contact-group',
    templateUrl: './holder-contact-group.component.html',
    styleUrls: ['./holder-contact-group.component.scss'],
})
export class HolderContactGroupComponent implements OnInit {
    /**
     * Minimum birthdate allowed.
     */
    minBirthdate = DateConstants.defaultMinDate;

    /**
     * Maximum birthdate allowed.
     */
    maxBirthdate = dateYearsInThePast(maxBirthDateDeltaInYears);

    /**
     * Holder contact form group.
     */
    @Input() formGroup: FormGroup<HolderContactFormGroup>;

    /**
     * ISO 8601 short date format.
     */
    ISO8601ShortDateFormat = DateConstants.ISO8601ShortDateFormat;

    /**
     * Last name control.
     */
    lastName: FormControl<string | null>;

    /**
     * First name control.
     */
    firstName: FormControl<string | null>;

    /**
     * Birthdate control.
     */
    birthdate: FormControl<Date | null>;

    /**
     * Phone number control.
     */
    phoneNumber: FormControl<string | null>;

    /**
     * Email control.
     */
    email: FormControl<string | null>;

    /**
     * Country control.
     */
    country: FormControl<string | null>;

    /**
     * Postal code control.
     */
    postalCode: FormControl<number | null>;

    /**
     * Locality control.
     */
    locality: FormControl<string | null>;

    /**
     * Street code control.
     */
    street: FormControl<string | null>;

    /**
     * Contract number control.
     */
    contractNumber: FormControl<string | null>;

    /**
     * Street code control.
     */
    iban: FormControl<string | null>;

    /**
     * @inheritdoc
     */
    ngOnInit(): void {
        this.lastName = this.formGroup.controls.lastName;
        this.firstName = this.formGroup.controls.firstName;
        this.birthdate = this.formGroup.controls.birthdate;
        this.phoneNumber = this.formGroup.controls.phoneNumber;
        this.email = this.formGroup.controls.email;
        this.country = this.formGroup.controls.country;
        this.postalCode = this.formGroup.controls.postalCode;
        this.locality = this.formGroup.controls.locality;
        this.street = this.formGroup.controls.street;
        this.contractNumber = this.formGroup.controls.contractNumber;
        this.iban = this.formGroup.controls.iban;
    }
}
