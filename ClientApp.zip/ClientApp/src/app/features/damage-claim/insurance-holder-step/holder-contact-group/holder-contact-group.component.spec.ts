import { ComponentFixture, TestBed } from '@angular/core/testing';
import {
    FormBuilder,
    FormGroup,
    ReactiveFormsModule,
    Validators,
} from '@angular/forms';
import { ValidationMessagesComponent } from '@shared/components/validation-messages/validation-messages.component';
import { getTranslocoTestingModule } from '@testing/transloco-testing.module';
import { MockComponents } from 'ng-mocks';
import { HolderContactGroupComponent } from './holder-contact-group.component';
import { PhoneNumberComponent } from '@shared/components/phone-number/phone-number.component';
import { FieldInfoComponent } from '@shared/components/field-info/field-info.component';
import { HolderContactFormGroup } from '@models/form-groups/holder-contact-form-group.model';
import { DamageClaimFormBuilderService } from '@features/damage-claim/services/damage-claim-form-builder.service';
import { rangeDateValidator } from '@shared/validators/date-range.validator';
import { DateConstants, dateYearsInThePast } from '@va-ngx-shared';
import { maxBirthDateDeltaInYears } from '@shared/constants/constants';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';

describe('HolderContactGroupComponent', () => {
    let component: HolderContactGroupComponent;
    let fixture: ComponentFixture<HolderContactGroupComponent>;
    let formGroup: FormGroup<HolderContactFormGroup>;

    beforeEach(async () => {
        formGroup = new DamageClaimFormBuilderService(
            new FormBuilder(),
        ).holderContact();

        await TestBed.configureTestingModule({
            imports: [getTranslocoTestingModule(), ReactiveFormsModule],
            declarations: [
                HolderContactGroupComponent,
                ...MockComponents(
                    ValidationMessagesComponent,
                    PhoneNumberComponent,
                    FieldInfoComponent,
                ),
            ],
            providers: [FormBuilder],
            schemas: [CUSTOM_ELEMENTS_SCHEMA],
        }).compileComponents();

        fixture = TestBed.createComponent(HolderContactGroupComponent);
        component = fixture.componentInstance;
        component.formGroup = formGroup;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });

    it('should show error message for invalid email', () => {
        component.email.setValue('asdasada');

        expect(component.email.errors).not.toBeNull();
    });

    it('should have the required validator for contract number', () => {
        expect(component.contractNumber.hasValidator(Validators.required)).toBe(
            true,
        );
    });

    it('should not show error message for valid email', () => {
        component.email.setValue('asdasada@vaudoise.ch');

        expect(component.email.errors).toBeNull();
    });

    it('should show error message for invalid birth date', () => {
        component.birthdate.setValue(new Date('2012-01-01'));

        expect(component.birthdate.errors).not.toBeNull();
    });

    it('should not show error message for valid birth date', () => {
        component.birthdate.setValue(new Date('2002-01-01'));

        expect(component.birthdate.errors).toBeNull();
    });
});
