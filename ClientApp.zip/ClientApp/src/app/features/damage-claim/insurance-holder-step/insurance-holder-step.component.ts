import { Component, OnInit, inject } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { DeclarerType } from '@models/declarer-type.enum';
import { InsuranceHolderStepFormGroup } from '@models/form-groups/insurance-holder-step-form-group.model';
import { ListItem } from '@shared/models/list-item';
import { DeclarerContactFormGroup } from '@models/form-groups/declarer-contact-form-group.model';
import { HolderContactFormGroup } from '@models/form-groups/holder-contact-form-group.model';
import { DamageClaimFormStateService } from '../services/damage-claim-form-state.service';
import { StepComponent } from '@shared/components/step-component';

@Component({
    selector: 'hf-insurance-holder-step',
    templateUrl: './insurance-holder-step.component.html',
    styleUrls: ['./insurance-holder-step.component.scss'],
})
export class InsuranceHolderStepComponent
    extends StepComponent
    implements OnInit
{
    private readonly formStateService = inject(DamageClaimFormStateService);

    /**
     * Declarer form group to enforce FormGroupDirective on child forms.
     */
    override formGroup: FormGroup<InsuranceHolderStepFormGroup>;

    /**
     * The declarer contact.
     */
    declarerContact: FormGroup<DeclarerContactFormGroup>;

    /**
     * The holder contact.
     */
    holderContact: FormGroup<HolderContactFormGroup>;

    /**
     * List of declarer type for radio button group.
     */
    declarerTypeItems: Array<ListItem> = [
        {
            i18nKey: 'declarerType.policyholder',
            value: DeclarerType.Policyholder,
        },
        { i18nKey: 'declarerType.agent', value: DeclarerType.Advisor },
        { i18nKey: 'declarerType.broker', value: DeclarerType.Broker },
    ];

    /**
     * Reactive form control for declarer type field.
     */
    declarerType: FormControl<DeclarerType | null>;

    /**
     * @inheritdoc
     */
    ngOnInit(): void {
        // Get step form group.
        this.formGroup =
            this.formStateService.getOrCreateFormGroup('insuranceHolder');

        this.declarerType = this.formGroup.controls.declarerType;

        this.declarerContact = this.formGroup.controls.declarerContact;

        this.holderContact = this.formGroup.controls.holderContact;
    }
}
