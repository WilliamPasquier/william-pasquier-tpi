import { Component, Input, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { DeclarerContactFormGroup } from '@models/form-groups/declarer-contact-form-group.model';

@Component({
    selector: 'hf-declarer-contact-group',
    templateUrl: './declarer-contact-group.component.html',
    styleUrls: ['./declarer-contact-group.component.scss'],
})
export class DeclarerContactGroupComponent implements OnInit {
    /**
     * Declarer contact form group.
     */
    @Input() formGroup: FormGroup<DeclarerContactFormGroup>;

    /**
     * The last name form control.
     */
    lastName: FormControl<string>;

    /**
     * The first name form control.
     */
    firstName: FormControl<string>;

    /**
     * The phone number form control.
     */
    phoneNumber: FormControl<string | null>;

    /**
     * The email form control.
     */
    email: FormControl<string>;

    /**
     * @inheritdoc
     */
    ngOnInit(): void {
        this.lastName = this.formGroup.controls.lastName;
        this.firstName = this.formGroup.controls.firstName;
        this.phoneNumber = this.formGroup.controls.phoneNumber;
        this.email = this.formGroup.controls.email;
    }
}
