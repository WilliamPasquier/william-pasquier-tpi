import { ComponentFixture, TestBed } from '@angular/core/testing';
import { FormBuilder, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { FieldInfoComponent } from '@shared/components/field-info/field-info.component';
import { PhoneNumberComponent } from '@shared/components/phone-number/phone-number.component';
import { ValidationMessagesComponent } from '@shared/components/validation-messages/validation-messages.component';
import { getTranslocoTestingModule } from '@testing/transloco-testing.module';
import { MockComponents } from 'ng-mocks';
import { DeclarerContactGroupComponent } from './declarer-contact-group.component';
import { DeclarerContactFormGroup } from '@models/form-groups/declarer-contact-form-group.model';
import { DamageClaimFormBuilderService } from '@features/damage-claim/services/damage-claim-form-builder.service';

describe('DeclarerContactGroupComponent', () => {
    let component: DeclarerContactGroupComponent;
    let fixture: ComponentFixture<DeclarerContactGroupComponent>;
    let formGroup: FormGroup<DeclarerContactFormGroup>;

    beforeEach(async () => {
        formGroup = new DamageClaimFormBuilderService(
            new FormBuilder(),
        ).declarerContact();

        await TestBed.configureTestingModule({
            imports: [getTranslocoTestingModule(), ReactiveFormsModule],
            declarations: [
                DeclarerContactGroupComponent,
                ...MockComponents(
                    ValidationMessagesComponent,
                    PhoneNumberComponent,
                    FieldInfoComponent,
                ),
            ],
            providers: [FormBuilder],
        }).compileComponents();

        fixture = TestBed.createComponent(DeclarerContactGroupComponent);
        component = fixture.componentInstance;
        component.formGroup = formGroup;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });

    it('should validate last name control', () => {
        const lastName = component.lastName;
        expect(lastName?.valid).toBeFalsy();

        lastName?.setValue('');
        expect(lastName?.hasError('required')).toBeTruthy();
    });

    it('should validate first name control', () => {
        const firstName = component.firstName;
        expect(firstName?.valid).toBeFalsy();

        firstName?.setValue('');
        expect(firstName?.hasError('required')).toBeTruthy();
    });

    it('should validate email control', () => {
        const email = component.email;
        expect(email?.valid).toBeFalsy();

        email?.setValue('');
        expect(email?.hasError('required')).toBeTruthy();
    });

    it('should validate phone control', () => {
        const phone = component.phoneNumber;
        expect(phone?.valid).toBeTruthy();

        phone?.setValue('');
        expect(phone?.hasError('required')).toBeFalsy();
    });
});
