import { DamageClaimRoutingModule } from './damage-claim-routing.module';
import { DamageClaimComponent } from './damage-claim.component';
import { DeclarerContactGroupComponent } from './insurance-holder-step/declarer-contact-group/declarer-contact-group.component';
import { HolderContactGroupComponent } from './/insurance-holder-step/holder-contact-group/holder-contact-group.component';
import { DamageEventStepComponent } from './damage-event-step/damage-event-step.component';
import { InsuranceHolderStepComponent } from './insurance-holder-step/insurance-holder-step.component';
import { DamageDescriptionGroupComponent } from './damage-event-step/damage-description-group/damage-description-group.component';
import { EventDescriptionGroupComponent } from './damage-event-step/event-description-group/event-description-group.component';
import { DamageAdditionalInfoStepComponent } from './damage-additional-info-step/damage-additional-info-step.component';
import { SharedModule } from '@shared/shared.module';
import { InventoryDamageGroupComponent } from './damage-event-step/damage-description-group/inventory-damage-group/inventory-damage-group.component';
import { RecaptchaFormsModule, RecaptchaModule } from 'ng-recaptcha';
import { ConfirmationPageComponent } from './confirmation-page/confirmation-page/confirmation-page.component';
import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { ConfirmationService } from 'primeng/api';
import { ConfirmDialogModule } from 'primeng/confirmdialog';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { TooltipModule } from 'primeng/tooltip';
import { DropdownModule } from 'primeng/dropdown';

@NgModule({
    declarations: [
        DamageClaimComponent,
        InsuranceHolderStepComponent,
        DeclarerContactGroupComponent,
        HolderContactGroupComponent,
        DamageEventStepComponent,
        DamageDescriptionGroupComponent,
        EventDescriptionGroupComponent,
        DamageAdditionalInfoStepComponent,
        InventoryDamageGroupComponent,
        ConfirmationPageComponent,
    ],
    imports: [
        DamageClaimRoutingModule,
        SharedModule,
        RecaptchaModule,
        RecaptchaFormsModule,
        ConfirmDialogModule,
        BrowserAnimationsModule,
        TooltipModule,
        DropdownModule,
    ],
    exports: [DamageClaimComponent, SharedModule],
    providers: [ConfirmationService],
    schemas: [CUSTOM_ELEMENTS_SCHEMA],
})
export class DamageClaimModule {}
