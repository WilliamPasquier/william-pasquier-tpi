import { ComponentFixture, TestBed } from '@angular/core/testing';
import { FormBuilder, ReactiveFormsModule } from '@angular/forms';
import { getTranslocoTestingModule } from '@testing/transloco-testing.module';
import { DamageAdditionalInfoStepComponent } from './damage-additional-info-step.component';
import { By } from '@angular/platform-browser';
import { OptionsYesNoMaybe } from '@models/options-yes-no-maybe.enum';
import { MockComponents } from 'ng-mocks';
import { ValidationMessagesComponent } from '@shared/components/validation-messages/validation-messages.component';
import { RadioButtonGroupComponent } from '@shared/components/radio-button-group/radio-button-group.component';
import { FieldInfoComponent } from '@shared/components/field-info/field-info.component';
import { TooltipModule } from 'primeng/tooltip';

describe('DamageAdditionalInfoStepComponent', () => {
    let component: DamageAdditionalInfoStepComponent;
    let fixture: ComponentFixture<DamageAdditionalInfoStepComponent>;

    beforeEach(async () => {
        await TestBed.configureTestingModule({
            imports: [
                getTranslocoTestingModule(),
                ReactiveFormsModule,
                TooltipModule,
            ],
            declarations: [
                DamageAdditionalInfoStepComponent,
                ...MockComponents(
                    ValidationMessagesComponent,
                    RadioButtonGroupComponent,
                    FieldInfoComponent,
                ),
            ],
            providers: [FormBuilder],
        }).compileComponents();

        fixture = TestBed.createComponent(DamageAdditionalInfoStepComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });

    it('form invalid when empty', () => {
        expect(component.formGroup.valid).toBeFalsy();
    });

    describe('Answering yes to has other insurer question', () => {
        it('should show other-insurer-name control element', () => {
            fixture.componentInstance.hasOtherInsurer.setValue(true);
            fixture.detectChanges();

            const element = fixture.debugElement.query(
                By.css('#other-insurer-name'),
            ).nativeElement;
            expect(element.hidden).toBeFalse();
        });
    });

    describe('Answering yes to was damage caused by third party question', () => {
        it('should show third-party-last-name control element', () => {
            fixture.componentInstance.thirdPartyResponsibility.setValue(
                OptionsYesNoMaybe.Yes,
            );
            fixture.detectChanges();

            const element = fixture.debugElement.query(
                By.css('#third-party-last-name'),
            ).nativeElement;
            expect(element.hidden).toBeFalse();
        });
        it('should show third-party-first-name control element', () => {
            fixture.componentInstance.thirdPartyResponsibility.setValue(
                OptionsYesNoMaybe.Yes,
            );
            fixture.detectChanges();

            const element = fixture.debugElement.query(
                By.css('#third-party-first-name'),
            ).nativeElement;
            expect(element.hidden).toBeFalse();
        });
        it('should show third-party-country control element', () => {
            fixture.componentInstance.thirdPartyResponsibility.setValue(
                OptionsYesNoMaybe.Yes,
            );
            fixture.detectChanges();

            const element = fixture.debugElement.query(
                By.css('#third-party-country'),
            ).nativeElement;
            expect(element.hidden).toBeFalse();
        });
        it('should show third-party-locality control element', () => {
            fixture.componentInstance.thirdPartyResponsibility.setValue(
                OptionsYesNoMaybe.Yes,
            );
            fixture.detectChanges();

            const element = fixture.debugElement.query(
                By.css('#third-party-locality'),
            ).nativeElement;
            expect(element.hidden).toBeFalse();
        });
        it('should show third-party-postal-code control element', () => {
            fixture.componentInstance.thirdPartyResponsibility.setValue(
                OptionsYesNoMaybe.Yes,
            );
            fixture.detectChanges();

            const element = fixture.debugElement.query(
                By.css('#third-party-postal-code'),
            ).nativeElement;
            expect(element.hidden).toBeFalse();
        });
        it('should show third-party-street control element', () => {
            fixture.componentInstance.thirdPartyResponsibility.setValue(
                OptionsYesNoMaybe.Yes,
            );
            fixture.detectChanges();

            const element = fixture.debugElement.query(
                By.css('#third-party-street'),
            ).nativeElement;
            expect(element.hidden).toBeFalse();
        });
    });

    describe('Answering to has emergency measures question', () => {
        it('should hide and disable controls when "null"', () => {
            fixture.componentInstance.hasEmergencyMeasures.setValue(null);
            fixture.detectChanges();

            const element = fixture.debugElement.query(
                By.css('[data-tui="emergency-measures-description"]'),
            );
            expect(element).toBeNull();

            expect(component.shouldOrganizeDamagesRepair.enabled).toBeFalse();
            expect(component.emergencyMeasuresDescription.enabled).toBeFalse();
        });

        it('should show/hide enable/disable controls when "true"', () => {
            fixture.componentInstance.hasEmergencyMeasures.setValue(true);
            fixture.detectChanges();

            const element = fixture.debugElement.query(
                By.css('[data-tui="emergency-measures-description"]'),
            ).nativeElement;
            expect(element.hidden).toBeFalse();

            expect(component.shouldOrganizeDamagesRepair.enabled).toBeFalse();
            expect(component.emergencyMeasuresDescription.enabled).toBeTrue();
        });

        it('should show/hide enable/disable controls when "false"', () => {
            fixture.componentInstance.hasEmergencyMeasures.setValue(false);
            fixture.detectChanges();

            const element = fixture.debugElement.query(
                By.css('[data-tui="emergency-measures-description"]'),
            );
            expect(element).toBeNull();

            expect(component.shouldOrganizeDamagesRepair.enabled).toBeTrue();
            expect(component.emergencyMeasuresDescription.enabled).toBeFalse();
        });
    });
});
