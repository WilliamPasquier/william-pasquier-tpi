import { Component, OnInit, inject } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { AdditionalInformationFormGroup } from '@models/form-groups/additional-information-form-group.model';
import { OptionsYesNoMaybe } from '@models/options-yes-no-maybe.enum';
import { ListItem } from '@shared/models/list-item';
import { DamageClaimFormStateService } from '../services/damage-claim-form-state.service';
import { StepComponent } from '@shared/components/step-component';

@Component({
    selector: 'hf-damage-additional-info-step',
    templateUrl: './damage-additional-info-step.component.html',
    styleUrls: ['./damage-additional-info-step.component.scss'],
})
export class DamageAdditionalInfoStepComponent
    extends StepComponent
    implements OnInit
{
    private readonly formStateService = inject(DamageClaimFormStateService);

    /**
     * Damage Additional Info form group to enforce FormGroupDirective on child forms.
     */
    override formGroup: FormGroup<AdditionalInformationFormGroup>;

    /**
     * List of options for yes/no radio button groups.
     */
    radioButtonYesNoItems: Array<ListItem> = [
        { i18nKey: 'common.yes', value: true },
        { i18nKey: 'common.no', value: false },
    ];

    /**
     * List of options for yes/no/maybe radio button groups.
     */
    radioButtonYesNoMaybeItems: Array<ListItem> = [
        { i18nKey: 'common.yes', value: OptionsYesNoMaybe.Yes },
        { i18nKey: 'common.no', value: OptionsYesNoMaybe.No },
        { i18nKey: 'common.maybe', value: OptionsYesNoMaybe.Maybe },
    ];

    /**
     * hasOtherInsurer control.
     */
    hasOtherInsurer: FormControl<boolean | null>;

    /**
     * otherInsurerName control.
     */
    otherInsurerName: FormControl<string | null>;

    /**
     * isOtherInsurerInformed control.
     */
    isOtherInsurerInformed: FormControl<boolean | null>;

    /**
     * thirdPartyResponsibility control.
     */
    thirdPartyResponsibility: FormControl<string | null>;

    /**
     * thirdPartyLastName control.
     */
    thirdPartyLastName: FormControl<string | null>;

    /**
     * thirdPartyFirstName control.
     */
    thirdPartyFirstName: FormControl<string | null>;

    /**
     * thirdPartyCountry control.
     */
    thirdPartyCountry: FormControl<string | null>;

    /**
     * thirdPartyLocality control.
     */
    thirdPartyLocality: FormControl<string | null>;

    /**
     * thirdPartyPostalCode control.
     */
    thirdPartyPostalCode: FormControl<string | null>;

    /**
     * thirdPartyStreet control.
     */
    thirdPartyStreet: FormControl<string | null>;

    /**
     * hasPoliceIncidentReport control.
     */
    hasPoliceIncidentReport: FormControl<boolean | null>;

    /**
     * hasEmergencyMeasures control.
     */
    hasEmergencyMeasures: FormControl<boolean | null>;

    /**
     * hasEmergencyMeasures control.
     */
    shouldOrganizeDamagesRepair: FormControl<boolean | null>;

    /**
     * emergencyMeasuresDescription control.
     */
    emergencyMeasuresDescription: FormControl<string | null>;

    /**
     * otherRemarks control.
     */
    otherRemarks: FormControl<string | null>;

    /**
     * @inheritdoc
     */
    ngOnInit(): void {
        // Get step form group.
        this.formGroup = this.formStateService.getOrCreateFormGroup(
            'additionalInformation',
        );

        this.hasOtherInsurer = this.formGroup.controls.hasOtherInsurer;
        this.otherInsurerName = this.formGroup.controls.otherInsurerName;
        this.isOtherInsurerInformed =
            this.formGroup.controls.isOtherInsurerInformed;
        this.thirdPartyResponsibility =
            this.formGroup.controls.thirdPartyResponsibility;
        this.thirdPartyLastName = this.formGroup.controls.thirdPartyLastName;
        this.thirdPartyFirstName = this.formGroup.controls.thirdPartyFirstName;
        this.thirdPartyCountry = this.formGroup.controls.thirdPartyCountry;
        this.thirdPartyLocality = this.formGroup.controls.thirdPartyLocality;
        this.thirdPartyPostalCode =
            this.formGroup.controls.thirdPartyPostalCode;
        this.thirdPartyStreet = this.formGroup.controls.thirdPartyStreet;
        this.hasPoliceIncidentReport =
            this.formGroup.controls.hasPoliceIncidentReport;
        this.hasEmergencyMeasures =
            this.formGroup.controls.hasEmergencyMeasures;
        this.shouldOrganizeDamagesRepair =
            this.formGroup.controls.shouldOrganizeDamagesRepair;
        this.emergencyMeasuresDescription =
            this.formGroup.controls.emergencyMeasuresDescription;
        this.otherRemarks = this.formGroup.controls.otherRemarks;
    }
}
