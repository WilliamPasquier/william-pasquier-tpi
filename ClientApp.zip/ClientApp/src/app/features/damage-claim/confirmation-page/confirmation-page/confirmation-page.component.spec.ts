import { ComponentFixture, TestBed } from '@angular/core/testing';
import { getTranslocoTestingModule } from '@testing/transloco-testing.module';
import { RouterTestingModule } from '@angular/router/testing';
import { routes } from '@config/app-routing.config';
import { ConfirmationPageComponent } from './confirmation-page.component';
import { By } from '@angular/platform-browser';

const claimNumber = '123';

describe('ConfirmationPageComponent', () => {
    let component: ConfirmationPageComponent;
    let fixture: ComponentFixture<ConfirmationPageComponent>;

    beforeEach(async () => {
        await TestBed.configureTestingModule({
            imports: [
                getTranslocoTestingModule(),
                RouterTestingModule.withRoutes(routes),
            ],
            declarations: [ConfirmationPageComponent],
        }).compileComponents();

        fixture = TestBed.createComponent(ConfirmationPageComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });

    it('should render the claim number', () => {
        fixture.componentInstance.claimNumber = claimNumber;
        fixture.detectChanges();
        const claimNumberParagraph = fixture.debugElement.query(
            By.css('[data-tui=claim-number-paragraph]'),
        ).nativeElement;
        expect(claimNumberParagraph.innerHTML).toContain(claimNumber);
    });
});
