import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
    selector: 'hf-confirmation-page',
    templateUrl: './confirmation-page.component.html',
    styleUrls: ['./confirmation-page.component.scss'],
})
export class ConfirmationPageComponent implements OnInit {
    claimNumber: string | null;

    constructor(private route: ActivatedRoute) {}

    ngOnInit(): void {
        this.claimNumber = this.route.snapshot.paramMap.get('claimNumber');
    }
}
