const confirmationPage = 'confirmation-page';

/**
 * The fragment of url related to the damage claim
 */
export const damageClaimRootFragment = 'damage-claim';

/**
 * Route paths avaible for the steps on damage claim.
 */
export const enum DamageClaimRoute {
    insuranceHolderStepRoute = 'insurance-holder',
    damageEventStepRoute = 'damage-event',
    additionalInfoStepRoute = 'additional-info',
}

/**
 * The fragment of url related to the confirmation page
 */
export const confirmationPageFragment = `${confirmationPage}/:claimNumber`;

/**
 * The route to the confirmation page
 */
export const confirmationPageRoute = `/${confirmationPage}`;
