import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import {
    DamageClaimRoute,
    confirmationPageFragment,
} from './config/route.builder';
import { ConfirmationPageComponent } from './confirmation-page/confirmation-page/confirmation-page.component';
import { DamageClaimComponent } from './damage-claim.component';
import { DamageAdditionalInfoStepComponent } from '@features/damage-claim/damage-additional-info-step/damage-additional-info-step.component';
import { DamageEventStepComponent } from '@features/damage-claim/damage-event-step/damage-event-step.component';
import { InsuranceHolderStepComponent } from '@features/damage-claim/insurance-holder-step/insurance-holder-step.component';
import { canActivateStep } from 'src/app/router-guards/can-activate-step/can-activate-step.guard';

/**
 * List all routes available at the DamageClaim feature level
 */
const routes: Routes = [
    {
        path: '',
        component: DamageClaimComponent,
        children: [
            {
                path: '',
                redirectTo: DamageClaimRoute.insuranceHolderStepRoute,
                pathMatch: 'full',
            },
            {
                path: DamageClaimRoute.insuranceHolderStepRoute,
                component: InsuranceHolderStepComponent,
            },
            {
                path: DamageClaimRoute.damageEventStepRoute,
                component: DamageEventStepComponent,
                canActivate: [canActivateStep],
                runGuardsAndResolvers: 'always',
            },
            {
                path: DamageClaimRoute.additionalInfoStepRoute,
                component: DamageAdditionalInfoStepComponent,
                canActivate: [canActivateStep],
                runGuardsAndResolvers: 'always',
            },
        ],
    },
    {
        path: confirmationPageFragment,
        component: ConfirmationPageComponent,
    },
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule],
    providers: [],
})
export class DamageClaimRoutingModule {}
