import { Component, OnInit, inject } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { DamageType } from '@models/damage-type.enum';
import { DamageEventStepFormGroup } from '@models/form-groups/damage-event-step-form-group.model';
import { DamageClaimFormStateService } from '../services/damage-claim-form-state.service';
import { EventDescriptionFormGroup } from '@models/form-groups/event-description-form-group.model';
import { DamageDescriptionFormGroup } from '@models/form-groups/damage-description-form-group.model';
import { StepComponent } from '@shared/components/step-component';
import { TranslocoService } from '@ngneat/transloco';
import { ListItem } from '@models/list-item';

@Component({
    selector: 'hf-damage-event-step',
    templateUrl: './damage-event-step.component.html',
    styleUrls: ['./damage-event-step.component.scss'],
})
export class DamageEventStepComponent extends StepComponent implements OnInit {
    private readonly formStateService = inject(DamageClaimFormStateService);

    private readonly translocoService = inject(TranslocoService);

    /**
     * Damage event step form group to enforce FormGroupDirective on child forms.
     */
    override formGroup: FormGroup<DamageEventStepFormGroup>;

    /**
     * List of damage type for select.
     */
    damageTypeItems: Array<ListItem> = [];

    /**
     * Reactive form control for damage type field.
     */
    damageType: FormControl<DamageType | null>;

    /**
     * Reactive form control for other damage type field.
     */
    otherDamageType: FormControl<string | null>;

    /**
     * property with the value for other damage cause.
     */
    otherCauseValue = DamageType.Other;

    /**
     * Event description form group
     */
    eventDescription: FormGroup<EventDescriptionFormGroup>;

    /**
     * Damage description form group
     */
    damageDescription: FormGroup<DamageDescriptionFormGroup>;

    /**
     * @inheritdoc
     */
    ngOnInit(): void {
        [
            DamageType.FireDamage,
            DamageType.Theft,
            DamageType.NaturalEvent,
            DamageType.WaterDamage,
            DamageType.GlassBreakage,
            DamageType.InfrastructureDamage,
            DamageType.Other,
        ].forEach((damageType) => {
            const item: ListItem = {
                value: damageType,
                i18nKey: `damageType.${damageType}`,
            };

            this.translocoService
                // eslint-disable-next-line @typescript-eslint/no-non-null-assertion
                .selectTranslate(item.i18nKey!)
                .subscribe((value) => {
                    item.text = value;
                });

            this.damageTypeItems.push(item);
        });

        // Get step form group
        this.formGroup =
            this.formStateService.getOrCreateFormGroup('damageEvent');

        this.damageType = this.formGroup.controls.damageType;
        this.otherDamageType = this.formGroup.controls.otherDamageType;
        this.eventDescription = this.formGroup.controls.eventDescription;
        this.damageDescription = this.formGroup.controls.damageDescription;
    }
}
