import {
    AfterViewInit,
    Component,
    ElementRef,
    Input,
    QueryList,
    ViewChildren,
    inject,
} from '@angular/core';
import { AbstractControl, FormArray, FormGroup } from '@angular/forms';
import { DamageClaimFormBuilderService } from '@features/damage-claim/services/damage-claim-form-builder.service';
import { InventoryDamageFormGroup } from '@models/form-groups/inventory-damage-form-group.model';
import { InventoryDamageTypeFormGroup } from '@models/form-groups/inventory-damage-type-form-group.model';

/**
 * The name of the key for the custom error to be used for the damagedObject prices & repair cost validation
 */
const PRICES_ERROR_KEY = 'priceEmpty';

@Component({
    selector: 'hf-inventory-damage-group',
    templateUrl: './inventory-damage-group.component.html',
    styleUrls: ['./inventory-damage-group.component.scss'],
})
export class InventoryDamageGroupComponent implements AfterViewInit {
    @ViewChildren('damagedInventory') damagedInventory: QueryList<ElementRef>;

    private readonly formBuilderService = inject(DamageClaimFormBuilderService);

    /**
     * Damage description form group.
     */
    @Input() formGroup: FormGroup<InventoryDamageFormGroup>;

    /**
     * If true, the UI sill set the focus on the 1st input of the last item
     */
    shouldFocusOnLastElement = false;

    /**
     * List of booleans to toggle 'optional' label on fields 'object price' and 'object repair cost'.
     * When true, optional label is shown on 'object price' field.
     * When false, optional label is shown on 'object repair cost' field.
     * When 'null', there will be no optional labels.
     */
    shouldShowOptionalForPrice: Array<boolean | null> = [];

    /**
     * Group of inventory damage objects that will be added to the form
     * @returns array of inventory damage objects
     */
    get damagedObjects(): FormArray<FormGroup<InventoryDamageTypeFormGroup>> {
        return this.formGroup.controls.inventoryDamages;
    }

    /**
     * @inheritdoc
     */
    ngAfterViewInit(): void {
        this.damagedInventory.changes.subscribe(() => {
            if (this.shouldFocusOnLastElement) {
                this.focusOnLastElement();
                this.shouldFocusOnLastElement = false;
            }
        });
    }

    /**
     * Builds an object of inventory damage with all its properties
     * @returns inventory damage group object
     */
    buildInventoryDamageGroup(): FormGroup<InventoryDamageTypeFormGroup> {
        const index = this.damagedObjects?.length || 0;

        const inventoryDamage = this.formBuilderService.buildInventoryDamages();

        this.shouldShowOptionalForPrice[index] = null;

        return inventoryDamage;
    }

    /**
     * Returns a value indicating where optional label should be shown for fields 'object price' and 'object repair costs'.
     * @param inventoryDamageAbstract - Inventory damage abtract control.
     * @returns true if should show optional label on 'object price' field, false if should show on 'object repair cost', null if not on anyone.
     */
    shouldShowOptionalLabelFor(
        inventoryDamageAbstract: AbstractControl | null,
    ) {
        const inventoryDamage =
            inventoryDamageAbstract as FormGroup<InventoryDamageTypeFormGroup>;
        let index = -1;

        for (let i = 0; i < this.damagedObjects.length; ++i) {
            if (this.damagedObjects.at(i) === inventoryDamage) {
                index = i;
                break;
            }
        }

        const objectPrice = inventoryDamage.controls.objectPrice;
        const objectRepairCost = inventoryDamage.controls.objectRepairCost;

        if (objectPrice.value && !objectRepairCost.value) {
            this.shouldShowOptionalForPrice[index] = false;
        } else if (!objectPrice.value && objectRepairCost.value) {
            this.shouldShowOptionalForPrice[index] = true;
        } else if (!objectPrice.value && !objectRepairCost.value) {
            this.shouldShowOptionalForPrice[index] = null;
        }

        return this.shouldShowOptionalForPrice[index];
    }

    /**
     * Adds new inventory damage object to the array of damaged objects
     */
    addInventoryDamageObject(): void {
        const damagedObject = this.buildInventoryDamageGroup();
        this.damagedObjects.push(damagedObject);
        this.shouldFocusOnLastElement = true;
    }

    /**
     * Set the focus on the object description input of the last element
     */
    private focusOnLastElement(): void {
        const length = this.damagedObjects.length - 1;
        const id = 'object-description-' + length.toString();
        const element = document.getElementById(id);

        element?.focus();
    }

    /**
     * Removes object from the array with the selected index
     * @param objectIndex - index of the damaged object
     */
    removeInventoryDamageObject(objectIndex: number): void {
        this.damagedObjects.removeAt(objectIndex);
        this.shouldShowOptionalForPrice.splice(objectIndex, 1);
    }

    /**
     * Method to know if the PRICES_ERROR_KEY is "activated" for a given damagedObject
     * @param damagedObject - the damagedObject group control
     * @returns true if the error is "active"
     */
    hasPricesError(damagedObject: AbstractControl): boolean {
        // as the func is added 2x will it be run 2x ? IF yes, how can we optimize that ? => move to a getter ?

        return !!(
            damagedObject &&
            damagedObject.errors &&
            PRICES_ERROR_KEY in damagedObject.errors &&
            (damagedObject.get('objectPrice')?.touched ||
                damagedObject.get('objectRepairCost')?.touched)
        );
    }
}
