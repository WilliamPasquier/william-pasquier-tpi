import { ComponentFixture, TestBed } from '@angular/core/testing';
import { FormBuilder, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { getTranslocoTestingModule } from '@testing/transloco-testing.module';
import { DamageDescriptionGroupComponent } from './damage-description-group.component';
import { By } from '@angular/platform-browser';
import { InventoryDamageGroupComponent } from './inventory-damage-group/inventory-damage-group.component';
import { MockComponents } from 'ng-mocks';
import { ValidationMessagesComponent } from '@shared/components/validation-messages/validation-messages.component';
import { RadioButtonGroupComponent } from '@shared/components/radio-button-group/radio-button-group.component';
import { FieldInfoComponent } from '@shared/components/field-info/field-info.component';
import { DamageDescriptionFormGroup } from '@models/form-groups/damage-description-form-group.model';
import { DamageClaimFormBuilderService } from '@features/damage-claim/services/damage-claim-form-builder.service';
import { TooltipModule } from 'primeng/tooltip';

describe('DamageDescriptionGroupComponent', () => {
    let component: DamageDescriptionGroupComponent;
    let fixture: ComponentFixture<DamageDescriptionGroupComponent>;
    let formGroup: FormGroup<DamageDescriptionFormGroup>;
    const buildingDamageDescription = '#building-damage-description';
    const inventoryDamageForm = '[data-tui="inventory-form"]';
    const addInventoryDamageObjectButton = '[data-tui="add-btn"]';

    beforeEach(async () => {
        formGroup = new DamageClaimFormBuilderService(
            new FormBuilder(),
        ).damageDescription();

        await TestBed.configureTestingModule({
            imports: [
                getTranslocoTestingModule(),
                ReactiveFormsModule,
                TooltipModule,
            ],
            declarations: [
                DamageDescriptionGroupComponent,
                InventoryDamageGroupComponent,
                ...MockComponents(
                    ValidationMessagesComponent,
                    RadioButtonGroupComponent,
                    FieldInfoComponent,
                ),
            ],
            providers: [FormBuilder],
        }).compileComponents();

        fixture = TestBed.createComponent(DamageDescriptionGroupComponent);
        component = fixture.componentInstance;
        component.formGroup = formGroup;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });

    it('should show building damage description field, when choosing has building damage', () => {
        component.hasBuildingDamage.setValue(true);
        fixture.detectChanges();
        expect(
            fixture.debugElement.query(By.css(buildingDamageDescription))
                .nativeElement,
        ).toBeTruthy();
    });

    it('should show inventory form and add inventory damage object button, when choosing has inventory damage', () => {
        component.hasInventoryDamage.setValue(true);
        fixture.detectChanges();
        expect(
            fixture.debugElement.query(By.css(inventoryDamageForm))
                .nativeElement,
        ).toBeTruthy();
        expect(
            fixture.debugElement.query(By.css(addInventoryDamageObjectButton))
                .nativeElement,
        ).toBeTruthy();
    });
});
