import { Component, Input, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { DamageDescriptionFormGroup } from '@models/form-groups/damage-description-form-group.model';
import { InventoryDamageFormGroup } from '@models/form-groups/inventory-damage-form-group.model';
import { ListItem } from '@shared/models/list-item';

@Component({
    selector: 'hf-damage-description-group',
    templateUrl: './damage-description-group.component.html',
    styleUrls: ['./damage-description-group.component.scss'],
})
export class DamageDescriptionGroupComponent implements OnInit {
    /**
     * Damage description form group.
     */
    @Input() formGroup: FormGroup<DamageDescriptionFormGroup>;

    /**
     * List of option for radio button group.
     */
    hasDamageItems: Array<ListItem> = [
        { i18nKey: 'common.yes', value: true },
        { i18nKey: 'common.no', value: false },
    ];

    /**
     * Reactive form control to verify if an object has damage.
     */
    hasInventoryDamage: FormControl<boolean | null>;

    /**
     * Reactive form control to verify if the building has damage.
     */
    hasBuildingDamage: FormControl<boolean | null>;

    /**
     * Object remarks form control
     */
    buildingDamageDescription: FormControl<string | null>;

    inventoryDamage: FormGroup<InventoryDamageFormGroup>;

    /**
     * @inheritdoc
     */
    ngOnInit(): void {
        this.hasInventoryDamage = this.formGroup.controls.hasInventoryDamage;
        this.hasBuildingDamage = this.formGroup.controls.hasBuildingDamage;
        this.buildingDamageDescription =
            this.formGroup.controls.buildingDamageDescription;
        this.inventoryDamage = this.formGroup.controls.inventoryDamage;
    }
}
