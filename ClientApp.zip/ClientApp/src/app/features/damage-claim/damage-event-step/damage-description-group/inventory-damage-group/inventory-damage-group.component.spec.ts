import {
    ComponentFixture,
    fakeAsync,
    TestBed,
    tick,
} from '@angular/core/testing';
import { FormBuilder, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { By } from '@angular/platform-browser';
import { FieldInfoComponent } from '@shared/components/field-info/field-info.component';
import { ValidationMessagesComponent } from '@shared/components/validation-messages/validation-messages.component';
import { getTranslocoTestingModule } from '@testing/transloco-testing.module';
import { MockComponents } from 'ng-mocks';
import { InventoryDamageGroupComponent } from './inventory-damage-group.component';
import { InventoryDamageFormGroup } from '@models/form-groups/inventory-damage-form-group.model';
import { DamageClaimFormBuilderService } from '@features/damage-claim/services/damage-claim-form-builder.service';

describe('InventoryDamageGroupComponent', () => {
    let component: InventoryDamageGroupComponent;
    let fixture: ComponentFixture<InventoryDamageGroupComponent>;
    let formGroup: FormGroup<InventoryDamageFormGroup>;

    beforeEach(async () => {
        formGroup = new DamageClaimFormBuilderService(
            new FormBuilder(),
        ).inventoryDamage();

        await TestBed.configureTestingModule({
            imports: [getTranslocoTestingModule(), ReactiveFormsModule],
            declarations: [
                InventoryDamageGroupComponent,
                ...MockComponents(
                    ValidationMessagesComponent,
                    FieldInfoComponent,
                ),
            ],
            providers: [FormBuilder],
        }).compileComponents();

        fixture = TestBed.createComponent(InventoryDamageGroupComponent);
        component = fixture.componentInstance;
        component.formGroup = formGroup;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });

    it('should contain the expected elements', () => {
        /**
         * Verify if the add button exists when component is created
         */
        const addButton = fixture.debugElement.query(
            By.css('[data-tui="add-btn"]'),
        ).nativeElement;
        expect(addButton).toBeTruthy();

        /**
         * Verify if the remove button does not exist
         */
        const removeButton = fixture.debugElement.query(
            By.css('[data-tui="remove-btn"]'),
        );
        expect(removeButton).toBeFalsy();

        /**
         * Verify if object decription input is created
         */
        const objectDescriptionInputElement = fixture.debugElement.query(
            By.css('[data-tui="object-description"]'),
        );
        const objectDescription =
            component.damagedObjects.at(0).controls.objectDescription;
        const objectDescriptionValue = objectDescription.value;
        expect(objectDescriptionInputElement).toBeTruthy();
        expect(objectDescriptionInputElement.nativeElement.value).toEqual(
            objectDescriptionValue,
        );
        expect(objectDescription.valid).toBeFalse();

        /**
         * Verify if object price input is created
         */
        const objectPriceInputElement = fixture.debugElement.query(
            By.css('[data-tui="object-price"]'),
        );
        const objectPrice = component.damagedObjects.at(0).controls.objectPrice;
        const objectPriceValue = objectPrice.value;
        expect(objectPriceInputElement).toBeTruthy();
        expect(objectPriceInputElement.nativeElement.value).toEqual(
            objectPriceValue,
        );
        expect(objectPrice.valid).toBeTrue();

        /**
         * Verify if object repair cost input is created
         */
        const objectRepairCostInputElement = fixture.debugElement.query(
            By.css('[data-tui="object-repair-cost"]'),
        );
        const objectRepairCost =
            component.damagedObjects.at(0).controls.objectRepairCost;
        const objectRepairCostValue = objectRepairCost.value;
        expect(objectRepairCostInputElement).toBeTruthy();
        expect(objectRepairCostInputElement.nativeElement.value).toEqual(
            objectRepairCostValue,
        );
        expect(objectRepairCost.valid).toBeTrue();

        /**
         * Verify if object remarks input is created
         */
        const objectRemarksInputElement = fixture.debugElement.query(
            By.css('[data-tui="object-remarks"]'),
        );
        const objectRemarks =
            component.damagedObjects.at(0).controls.objectRemarks;
        const objectRemarksValue = objectRemarks.value;
        expect(objectRemarksInputElement).toBeTruthy();
        expect(objectRemarksInputElement.nativeElement.value).toEqual(
            objectRemarksValue,
        );
        expect(objectRemarks.valid).toBeTrue();
    });

    it('form invalid when empty', () => {
        expect(component.formGroup.valid).toBeFalsy();
    });

    it('form group element count', () => {
        const formElement = fixture.debugElement.query(
            By.css('[data-tui="inventory-form"]'),
        ).nativeElement;
        const inputElements = formElement.querySelectorAll('input');
        expect(inputElements.length).toEqual(3);
        const textareaElements = formElement.querySelectorAll('textarea');
        expect(textareaElements.length).toEqual(1);
    });

    it('should add element to array when click addInventoryDamageObject button', fakeAsync(() => {
        const button = fixture.debugElement.query(
            By.css('[data-tui="add-btn"]'),
        ).nativeElement;
        button.click();

        expect(button).toBeTruthy();
        expect(component.damagedObjects.controls.length).toEqual(2);

        fixture.detectChanges();
        tick();

        const buttons = fixture.debugElement.queryAll(
            By.css('[data-tui="remove-btn"]'),
        );
        expect(buttons.length).toBe(2);
    }));

    it('should remove element from array when click removeInventoryDamageObject button', fakeAsync(() => {
        component.addInventoryDamageObject();
        fixture.detectChanges();
        tick();

        const button = fixture.debugElement.query(
            By.css('[data-tui="remove-btn"]'),
        ).nativeElement;
        button.click();
        fixture.detectChanges();
        tick();

        expect(component.damagedObjects.length).toEqual(1);
    }));

    it('should be invalid on 1st render', fakeAsync(() => {
        expect(component.formGroup.valid).toBeFalsy();
    }));

    it('should be valid when all filed are set', fakeAsync(() => {
        const objectDescriptionInputElement = fixture.debugElement.query(
            By.css('[data-tui="object-description"]'),
        );
        objectDescriptionInputElement.nativeElement.value = 'test';
        fixture.detectChanges();
        tick();

        const objectPriceInputElement = fixture.debugElement.query(
            By.css('[data-tui="object-price"]'),
        );
        objectPriceInputElement.nativeElement.value = '234';
        fixture.detectChanges();
        tick();

        const objectRepairCostInputElement = fixture.debugElement.query(
            By.css('[data-tui="object-repair-cost"]'),
        );
        objectRepairCostInputElement.nativeElement.value = '';
        fixture.detectChanges();
        tick();

        const objectRemarksInputElement = fixture.debugElement.query(
            By.css('[data-tui="object-remarks"]'),
        );
        objectRemarksInputElement.nativeElement.value = 'plouf';
        fixture.detectChanges();
        tick();

        const inventoryDamage = {
            objectDescription:
                objectDescriptionInputElement.nativeElement.value,
            objectPrice: objectPriceInputElement.nativeElement.value,
            objectRepairCost: objectRepairCostInputElement.nativeElement.value,
            objectRemarks: objectRemarksInputElement.nativeElement.value,
        };

        component.formGroup.controls.inventoryDamages.setValue([
            inventoryDamage,
        ]);
        expect(component.formGroup.valid).toBeTruthy();
    }));

    it('objectDescription field validity', () => {
        const objectDescription =
            component.damagedObjects.at(0).controls.objectDescription;

        objectDescription.setValue('');
        expect(objectDescription.hasError('required')).toBeTruthy();
    });

    it('objectPrice field validity', fakeAsync(() => {
        const objectPrice = component.damagedObjects.at(0).controls.objectPrice;

        objectPrice.markAsTouched();
        fixture.detectChanges();
        tick();

        const objectPriceDiv = fixture.debugElement.query(
            By.css('[data-tui="object-price-div"]'),
        );
        const objectPriceClasses = objectPriceDiv.classes;
        expect(objectPriceClasses['has-error']).toBeTruthy();

        const objectRepairCostDiv = fixture.debugElement.query(
            By.css('[data-tui="object-repair-cost-div"]'),
        );
        const objectRepairCostClasses = objectRepairCostDiv.classes;
        expect(objectRepairCostClasses['has-error']).toBeTruthy();
    }));

    it('objectRepairCost field validity', fakeAsync(() => {
        const objectRepairCost =
            component.damagedObjects.at(0).controls.objectRepairCost;

        objectRepairCost?.markAsTouched();
        fixture.detectChanges();
        tick();

        const objectRepairCostDiv = fixture.debugElement.query(
            By.css('[data-tui="object-repair-cost-div"]'),
        );
        const classes = objectRepairCostDiv.classes;
        expect(classes['has-error']).toBeTruthy();

        const objectPriceDiv = fixture.debugElement.query(
            By.css('[data-tui="object-price-div"]'),
        );
        const objectPriceClasses = objectPriceDiv.classes;
        expect(objectPriceClasses['has-error']).toBeTruthy();
    }));

    it('cross field validation - objectPrice with value', fakeAsync(() => {
        const objectPrice =
            component.damagedObjects.controls[0].get('objectPrice');
        objectPrice?.setValue('345');
        fixture.detectChanges();
        tick();

        const objectPriceDiv = fixture.debugElement.query(
            By.css('[data-tui="object-price-div"]'),
        );
        const priceClasses = objectPriceDiv.classes;

        const objectRepairCostDiv = fixture.debugElement.query(
            By.css('[data-tui="object-repair-cost-div"]'),
        );
        const repairCostclasses = objectRepairCostDiv.classes;

        expect(priceClasses['has-error']).toBeFalsy();
        expect(repairCostclasses['has-error']).toBeFalsy();
    }));

    it('cross field validation  - objectRepairCost with value', fakeAsync(() => {
        const objectRepairCost =
            component.damagedObjects.controls[0].get('objectRepairCost');
        objectRepairCost?.setValue('345');
        fixture.detectChanges();
        tick();

        const objectPriceDiv = fixture.debugElement.query(
            By.css('[data-tui="object-price-div"]'),
        );
        const priceClasses = objectPriceDiv.classes;

        const objectRepairCostDiv = fixture.debugElement.query(
            By.css('[data-tui="object-repair-cost-div"]'),
        );
        const repairCostclasses = objectRepairCostDiv.classes;

        expect(priceClasses['has-error']).toBeFalsy();
        expect(repairCostclasses['has-error']).toBeFalsy();
    }));

    describe('toogle optional label on object price and repair costs', () => {
        it('should have no optional labels', () => {
            const damagedObject = component.damagedObjects.at(0);

            expect(damagedObject).not.toBeNull();
            expect(component.shouldShowOptionalForPrice.length).toBe(1);
            expect(component.shouldShowOptionalForPrice[0]).toBeNull();
        });

        it('should have optional on object repair costs', () => {
            const damagedObject = component.damagedObjects.at(0);
            damagedObject.controls.objectPrice.setValue('1000');
            fixture.detectChanges();

            expect(component.shouldShowOptionalForPrice.length).toBe(1);
            expect(component.shouldShowOptionalForPrice[0]).toBeFalse();
        });

        it('should have optional on object price', () => {
            const damagedObject = component.damagedObjects.at(0);
            damagedObject.controls.objectRepairCost.setValue('1000');
            fixture.detectChanges();

            expect(damagedObject).not.toBeNull();
            expect(component.shouldShowOptionalForPrice.length).toBe(1);
            expect(component.shouldShowOptionalForPrice[0]).toBeTrue();
        });

        it('should have keep optional on object repair costs', () => {
            const damagedObject = component.damagedObjects.at(0);
            damagedObject.controls.objectPrice.setValue('1000');
            fixture.detectChanges();

            expect(component.shouldShowOptionalForPrice.length).toBe(1);
            expect(component.shouldShowOptionalForPrice[0]).toBeFalse();

            damagedObject.controls.objectRepairCost.setValue('1000');
            fixture.detectChanges();

            expect(damagedObject).not.toBeNull();
            expect(component.shouldShowOptionalForPrice.length).toBe(1);
            expect(component.shouldShowOptionalForPrice[0]).toBeFalse();
        });

        it('should have keep optional on object price', () => {
            const damagedObject = component.damagedObjects.at(0);
            damagedObject.controls.objectRepairCost.setValue('1000');
            fixture.detectChanges();

            expect(component.shouldShowOptionalForPrice.length).toBe(1);
            expect(component.shouldShowOptionalForPrice[0]).toBeTrue();

            damagedObject.controls.objectPrice.setValue('1000');
            fixture.detectChanges();

            expect(damagedObject).not.toBeNull();
            expect(component.shouldShowOptionalForPrice.length).toBe(1);
            expect(component.shouldShowOptionalForPrice[0]).toBeTrue();
        });

        it('should switch optional from object repair costs to object price', () => {
            const damagedObject = component.damagedObjects.at(0);
            damagedObject.controls.objectPrice.setValue('1000');
            fixture.detectChanges();
            damagedObject.controls.objectRepairCost.setValue('1000');
            fixture.detectChanges();

            expect(component.shouldShowOptionalForPrice.length).toBe(1);
            expect(component.shouldShowOptionalForPrice[0]).toBeFalse();

            damagedObject.controls.objectPrice.setValue('');
            fixture.detectChanges();

            expect(component.shouldShowOptionalForPrice[0]).toBeTrue();
        });

        it('should switch optional from object price to object repair costs', () => {
            const damagedObject = component.damagedObjects.at(0);
            damagedObject.controls.objectRepairCost.setValue('1000');
            fixture.detectChanges();
            damagedObject.controls.objectPrice.setValue('1000');
            fixture.detectChanges();

            expect(component.shouldShowOptionalForPrice.length).toBe(1);
            expect(component.shouldShowOptionalForPrice[0]).toBeTrue();

            damagedObject.controls.objectRepairCost.setValue('');
            fixture.detectChanges();

            expect(component.shouldShowOptionalForPrice[0]).toBeFalse();
        });

        it('should have two optional labels', () => {
            component.addInventoryDamageObject();
            const damagedObject1 = component.damagedObjects.at(0);
            damagedObject1.controls.objectPrice.setValue('1000');
            fixture.detectChanges();

            const damagedObject2 = component.damagedObjects.at(1);
            damagedObject2.controls.objectRepairCost.setValue('1000');
            fixture.detectChanges();

            expect(component.shouldShowOptionalForPrice.length).toBe(2);
            expect(component.shouldShowOptionalForPrice[0]).toBeFalse();
            expect(component.shouldShowOptionalForPrice[1]).toBeTrue();
        });

        it('should have two optional labels and switch labels independently', () => {
            component.addInventoryDamageObject();
            const damagedObject1 = component.damagedObjects.at(0);
            damagedObject1.controls.objectPrice.setValue('1000');
            fixture.detectChanges();

            const damagedObject2 = component.damagedObjects.at(1);
            damagedObject2.controls.objectRepairCost.setValue('1000');
            fixture.detectChanges();

            expect(component.shouldShowOptionalForPrice.length).toBe(2);
            expect(component.shouldShowOptionalForPrice[0]).toBeFalse();
            expect(component.shouldShowOptionalForPrice[1]).toBeTrue();

            damagedObject1.controls.objectRepairCost.setValue('1000');
            damagedObject1.controls.objectPrice.setValue('');

            damagedObject2.controls.objectPrice.setValue('1000');
            damagedObject2.controls.objectRepairCost.setValue('');
            fixture.detectChanges();

            expect(component.shouldShowOptionalForPrice[0]).toBeTrue();
            expect(component.shouldShowOptionalForPrice[1]).toBeFalse();
        });

        it('should remove optional label from array', () => {
            component.addInventoryDamageObject();
            component.addInventoryDamageObject();
            const damagedObject1 = component.damagedObjects.at(0);
            damagedObject1.controls.objectPrice.setValue('1000');

            const damagedObject2 = component.damagedObjects.at(1);
            damagedObject2.controls.objectRepairCost.setValue('1000');
            fixture.detectChanges();

            expect(component.shouldShowOptionalForPrice.length).toBe(3);
            expect(component.shouldShowOptionalForPrice[0]).toBeFalse();
            expect(component.shouldShowOptionalForPrice[1]).toBeTrue();
            expect(component.shouldShowOptionalForPrice[2]).toBeNull();

            component.removeInventoryDamageObject(1);
            fixture.detectChanges();

            expect(component.shouldShowOptionalForPrice.length).toBe(2);
            expect(component.shouldShowOptionalForPrice[0]).toBeFalse();
            expect(component.shouldShowOptionalForPrice[1]).toBeNull();
        });
    });
});
