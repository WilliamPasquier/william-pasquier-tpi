import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { FormBuilder, ReactiveFormsModule } from '@angular/forms';
import { By } from '@angular/platform-browser';
import { DamageType } from '@models/damage-type.enum';
import { FieldInfoComponent } from '@shared/components/field-info/field-info.component';
import { ValidationMessagesComponent } from '@shared/components/validation-messages/validation-messages.component';
import { getTranslocoTestingModule } from '@testing/transloco-testing.module';
import { MockComponents } from 'ng-mocks';
import { DamageDescriptionGroupComponent } from './damage-description-group/damage-description-group.component';
import { DamageEventStepComponent } from './damage-event-step.component';
import { EventDescriptionGroupComponent } from './event-description-group/event-description-group.component';

describe('DamageEventStepComponent', () => {
    let component: DamageEventStepComponent;
    let fixture: ComponentFixture<DamageEventStepComponent>;
    const otherDamageType = '#other-damage-type';

    beforeEach(async () => {
        await TestBed.configureTestingModule({
            imports: [getTranslocoTestingModule(), ReactiveFormsModule],
            declarations: [
                DamageEventStepComponent,
                ...MockComponents(
                    ValidationMessagesComponent,
                    EventDescriptionGroupComponent,
                    DamageDescriptionGroupComponent,
                    FieldInfoComponent,
                ),
            ],
            providers: [FormBuilder],
            schemas: [CUSTOM_ELEMENTS_SCHEMA],
        }).compileComponents();

        fixture = TestBed.createComponent(DamageEventStepComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });

    it('should retrieve the formGroup from the formStateService', () => {
        expect(component.formGroup).toBeDefined();
    });

    [
        { damageType: DamageType.FireDamage, expectedStatus: true },
        { damageType: DamageType.Other, expectedStatus: false },
    ].forEach((testObject) => {
        it(`should show other damage type field, when choosing damage cause type other. Damage type: ${testObject.damageType}`, () => {
            component.damageType.setValue(testObject.damageType);
            fixture.detectChanges();
            expect(
                fixture.debugElement.query(By.css(otherDamageType))
                    .nativeElement.disabled,
            ).toBe(testObject.expectedStatus);
        });
    });
});
