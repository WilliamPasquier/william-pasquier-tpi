import { Component, Input, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { ValidatorsConstants } from '@appConstants/validators-constants';
import { EventDescriptionFormGroup } from '@models/form-groups/event-description-form-group.model';
import {
    maxClaimDateDeltaInYears,
    minClaimDateDeltaInYears,
} from '@shared/constants/constants';
import { DateConstants, dateYearsInThePast } from '@va-ngx-shared';

@Component({
    selector: 'hf-event-description-group',
    templateUrl: './event-description-group.component.html',
    styleUrls: ['./event-description-group.component.scss'],
})
export class EventDescriptionGroupComponent implements OnInit {
    /**
     * ISO 8601 short date format.
     */
    ISO8601ShortDateFormat = DateConstants.ISO8601ShortDateFormat;

    /**
     * The minimum Claim Date allowed.
     */
    minClaimDate = dateYearsInThePast(minClaimDateDeltaInYears);

    /**
     * The maximum Claim Date allowed.
     */
    maxClaimDate = dateYearsInThePast(maxClaimDateDeltaInYears);

    /**
     * The maximum Claim Time allowed.
     */
    maxTimeLength = ValidatorsConstants.time.maxLength;

    /**
     * Event description form group.
     */
    @Input() formGroup: FormGroup<EventDescriptionFormGroup>;

    /**
     * Occurrence date control.
     */
    occurrenceDate: FormControl<string | null>;

    /**
     * Occurrence time control.
     */
    occurrenceTime: FormControl<string | null>;

    /**
     * Occurrence place control.
     */
    occurrencePlace: FormControl<string | null>;

    /**
     * Circumstances control.
     */
    circumstances: FormControl<string | null>;

    ngOnInit(): void {
        this.occurrenceDate = this.formGroup.controls.occurrenceDate;
        this.occurrenceTime = this.formGroup.controls.occurrenceTime;
        this.occurrencePlace = this.formGroup.controls.occurrencePlace;
        this.circumstances = this.formGroup.controls.circumstances;
    }
}
