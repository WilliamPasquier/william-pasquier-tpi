import { ComponentFixture, TestBed } from '@angular/core/testing';
import { FormBuilder, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { FieldInfoComponent } from '@shared/components/field-info/field-info.component';
import { ValidationMessagesComponent } from '@shared/components/validation-messages/validation-messages.component';
import { getTranslocoTestingModule } from '@testing/transloco-testing.module';
import { MockComponents } from 'ng-mocks';

import { EventDescriptionGroupComponent } from './event-description-group.component';
import { EventDescriptionFormGroup } from '@models/form-groups/event-description-form-group.model';
import { DamageClaimFormBuilderService } from '@features/damage-claim/services/damage-claim-form-builder.service';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';

describe('BuildingDamageGroupComponent', () => {
    let component: EventDescriptionGroupComponent;
    let fixture: ComponentFixture<EventDescriptionGroupComponent>;
    let formGroup: FormGroup<EventDescriptionFormGroup>;

    beforeEach(async () => {
        formGroup = new DamageClaimFormBuilderService(
            new FormBuilder(),
        ).eventDescription();

        await TestBed.configureTestingModule({
            imports: [getTranslocoTestingModule(), ReactiveFormsModule],
            declarations: [
                EventDescriptionGroupComponent,
                ...MockComponents(
                    ValidationMessagesComponent,
                    FieldInfoComponent,
                ),
            ],
            providers: [FormBuilder],
            schemas: [CUSTOM_ELEMENTS_SCHEMA],
        }).compileComponents();

        fixture = TestBed.createComponent(EventDescriptionGroupComponent);
        component = fixture.componentInstance;
        component.formGroup = formGroup;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });

    it('should validate circumstances control', () => {
        const circumstances = component.circumstances;
        expect(circumstances?.valid).toBeFalsy();

        circumstances?.setValue('');
        expect(circumstances?.hasError('required')).toBeTruthy();
    });

    it('should validate occurrence date control', () => {
        const occurrenceDate = component.occurrenceDate;
        expect(occurrenceDate?.valid).toBeFalsy();

        occurrenceDate?.setValue('');
        expect(occurrenceDate?.hasError('required')).toBeTruthy();
    });

    it('should validate occurrence place control', () => {
        const occurrencePlace = component.occurrencePlace;
        expect(occurrencePlace?.valid).toBeFalsy();

        occurrencePlace?.setValue('');
        expect(occurrencePlace?.hasError('required')).toBeTruthy();
    });

    it('should fail to validate occurrence time control', () => {
        const occurrenceTime = component.occurrenceTime;
        occurrenceTime.setValue('invalid time');
        expect(occurrenceTime.valid).toBeFalsy();
    });

    it('should validate occurrence time control successfully', () => {
        const occurrenceTime = component.occurrenceTime;
        occurrenceTime.setValue('10:00');
        expect(occurrenceTime.valid).toBeTruthy();
    });
});
