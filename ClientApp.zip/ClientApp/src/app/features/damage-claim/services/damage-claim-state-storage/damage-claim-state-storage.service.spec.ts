import { TestBed } from '@angular/core/testing';

import {
    DamageClaimStateStorageService,
    localStorageKey,
} from './damage-claim-state-storage.service';
import { MockProvider } from 'ng-mocks';
import {
    FormArray,
    FormBuilder,
    FormControl,
    FormGroup,
    Validators,
} from '@angular/forms';
import { DamageClaimFormGroup } from '@models/form-groups/damage-claim-form-group.model';
import { DamageClaimFormStateService } from '../damage-claim-form-state.service';
import { FormGroupModel, LocalStorageService } from '@va-ngx-shared';
import { Subject } from 'rxjs';

describe('DamageClaimStateStorageService', () => {
    let formGroup: FormGroup<DamageClaimFormGroup>;
    let valueChangesSubject: Subject<void>;
    let formStateServiceMock: jasmine.SpyObj<DamageClaimFormStateService>;
    let localStorageServiceMock: jasmine.SpyObj<LocalStorageService>;
    let service: DamageClaimStateStorageService;
    let fb: FormBuilder;

    beforeEach(() => {
        fb = new FormBuilder();

        formGroup = new FormGroup<DamageClaimFormGroup>({
            currentStep: new FormControl<string | null>(null),
            recaptcha: new FormControl<string | null>(
                null,
                Validators.required,
            ),
            files: new FormArray<FormControl<File>>([]),
        });

        valueChangesSubject = new Subject();

        formStateServiceMock =
            jasmine.createSpyObj<DamageClaimFormStateService>(
                'FormGroupStateService',
                ['getState', 'getOrCreateFormGroup'],
                {
                    // eslint-disable-next-line no-undefined
                    valueChanged: valueChangesSubject.asObservable(),
                },
            );

        formStateServiceMock.getState.and.returnValue(formGroup);

        localStorageServiceMock = jasmine.createSpyObj<LocalStorageService>([
            'get',
            'set',
            'remove',
        ]);

        TestBed.configureTestingModule({
            providers: [
                MockProvider(DamageClaimFormStateService, formStateServiceMock),
                MockProvider(LocalStorageService, localStorageServiceMock),
            ],
        });
        service = TestBed.inject(DamageClaimStateStorageService);
    });

    it('should be created', () => {
        expect(service).toBeTruthy();
    });

    it('should save state to local storage when state changes', () => {
        valueChangesSubject.next();

        expect(localStorageServiceMock.set).toHaveBeenCalledOnceWith(
            localStorageKey,
            formGroup.getRawValue(),
        );
    });

    it('should reset recaptcha field when saving state to local storage', () => {
        const recaptcha = fb.control<string | null>('asdfasdfasdf');

        const model: FormGroupModel<DamageClaimFormGroup> = {
            currentStep: null,
            recaptcha: recaptcha.getRawValue(),
            files: [],
        };

        model.recaptcha = null;

        valueChangesSubject.next();

        expect(localStorageServiceMock.set).toHaveBeenCalledOnceWith(
            localStorageKey,
            model,
        );
    });

    it('should have saved state', () => {
        localStorageServiceMock.get
            .withArgs(localStorageKey)
            .and.returnValue(null);

        expect(service.hasSavedState()).toBeFalse();
        expect(localStorageServiceMock.get).toHaveBeenCalledOnceWith(
            localStorageKey,
        );
    });

    it('should remove state', () => {
        service.removeSavedState();

        expect(localStorageServiceMock.remove).toHaveBeenCalledOnceWith(
            localStorageKey,
        );
    });
});
