import { Injectable, inject } from '@angular/core';
import { DamageClaimFormGroup } from '@models/form-groups/damage-claim-form-group.model';
import { DamageClaimFormStateService } from '../damage-claim-form-state.service';
import { Observable, Subscriber } from 'rxjs';
import { FormGroupModel, LocalStorageService } from '@va-ngx-shared';

export const localStorageKey = 'va.hio.fnol.state';
const excludedPropertyLoadState: keyof DamageClaimFormGroup = 'currentStep';

@Injectable({
    providedIn: 'root',
})
export class DamageClaimStateStorageService {
    private readonly formStateService = inject(DamageClaimFormStateService);

    private readonly localStorageService = inject(LocalStorageService);

    /**
     * Indicates if state can be saved when form group value changes.
     * It is used to prevent saving state when form groups are being created and when state is being loaded from local storage.
     */
    canSaveState = true;

    constructor() {
        this.formStateService.valueChanged.subscribe(
            this.onValueChanges.bind(this),
        );
    }

    /**
     * Indicates if there was a saved state from previous form interactions.
     * @returns true if there saved state, otherwise false.
     */
    hasSavedState(): boolean {
        return this.localStorageService.get<unknown>(localStorageKey) !== null;
    }

    /**
     * Loads the saved state from previous form interactions.
     * @param subscriber - subscriber that gets notified of observable events.
     */
    loadSavedState(): void {
        this.canSaveState = false;

        try {
            const savedState =
                this.localStorageService.get<
                    FormGroupModel<DamageClaimFormGroup>
                >(localStorageKey);

            // Create all the saved FormGroup
            Object.keys(savedState)
                .filter((key) => key !== excludedPropertyLoadState)
                .forEach((key) => {
                    if (key !== excludedPropertyLoadState) {
                        this.formStateService.getOrCreateFormGroup(
                            key as keyof DamageClaimFormGroup,
                        );
                    }
                });

            const state = this.formStateService.getState();

            state.patchValue(savedState);

            this.canSaveState = true;
        } catch (exc) {
            this.canSaveState = true;
        }
    }

    /**
     * Removes saved state.
     */
    removeSavedState(): void {
        this.localStorageService.remove(localStorageKey);
    }

    /**
     * Callback method that is invoked when from group value changes.
     * Saves the state to local storage.
     */
    onValueChanges(): void {
        // TODO : Return an observable when the report is already being recorded [https://di.vaudoise.ch/browse/VDCH-11667]
        if (this.canSaveState) {
            const stateValue: FormGroupModel<DamageClaimFormGroup> =
                this.formStateService.getState().getRawValue();

            stateValue.recaptcha = null;

            this.localStorageService.set(localStorageKey, stateValue);
        }
    }
}
