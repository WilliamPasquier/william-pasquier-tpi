import { Injectable, inject } from '@angular/core';
import { Router, UrlTree } from '@angular/router';
import { DamageClaimFormGroup } from '@models/form-groups/damage-claim-form-group.model';
import { Step } from '@models/step.model';
import { Subject } from 'rxjs';
import { DamageClaimFormStateService } from '../damage-claim-form-state.service';
import { DamageClaimRoute } from '@features/damage-claim/config/route.builder';

@Injectable({
    providedIn: 'root',
})
export class DamageClaimNavigatorService {
    // eslint-disable-next-line no-undef
    private readonly formStateService = inject(DamageClaimFormStateService);

    /**
     * The subject that emits step changes events for observables.
     */
    private stepChangedSubject = new Subject<Step>();

    /**
     * Observable that can be subscribed for step changes events.
     */
    stepChanged = this.stepChangedSubject.asObservable();

    /**
     * The current step index.
     */
    private currentStepIndex = 0;

    /**
     * The list of steps available on the form in tree structure.
     */
    private stepsTree: Array<Step> = [
        {
            code: 'insuranceHolder',
            routePath: DamageClaimRoute.insuranceHolderStepRoute,
            formGroupName: 'insuranceHolder',
        },
        {
            code: 'damageEvent',
            routePath: DamageClaimRoute.damageEventStepRoute,
            formGroupName: 'damageEvent',
        },
        {
            code: 'additionalInformation',
            routePath: DamageClaimRoute.additionalInfoStepRoute,
            formGroupName: 'additionalInformation',
        },
    ];

    /**
     * List of ordered steps build from steps tree. We use a list because it's easier to navigate back and forward with a list compared
     * to a tree structure.
     */
    private steps: Array<Step> = [];

    constructor(private readonly router: Router) {
        this.generatedStepsFromTree(this.stepsTree);
    }

    /**
     * Fills the list of ordered steps from a step tree. The only steps added to the ordered list are the navigatable ones, with a value in {@link Step#routePath}.
     * @param steps - list of steps on a step tree level.
     */
    generatedStepsFromTree(steps: Array<Step>): void {
        for (let i = 0; i < steps.length; ++i) {
            const step = steps[i];

            if (step.formGroupName) {
                this.steps.push(step);
            }
        }
    }

    /**
     * Gets a step by index
     * @param stepIndex - The step index.
     * @returns - The @see Step instance, otherwise undefined.
     */
    getStep(stepIndex: number): Step {
        return this.steps[stepIndex];
    }

    /**
     * Returns the list of steps tree.
     * @returns Steps tree.
     */
    getStepsTree(): Array<Step> {
        return this.stepsTree;
    }

    /**
     * Gets the current step index (0 based).
     * @returns Current step index.
     */
    getCurrentStepIndex(): number {
        return this.currentStepIndex;
    }

    /**
     * Gets the total number of steps.
     * @returns Total number of steps.
     */
    getStepsCount(): number {
        return this.steps.length;
    }

    /**
     * Navigates to the next step.
     */
    goToNextStep(): void {
        this.goToStep(this.currentStepIndex + 1);
    }

    /**
     * Navigates to previous step.
     */
    goToPreviousStep(): void {
        this.goToStep(this.currentStepIndex - 1);
    }

    /**
     * Resets the navigation.
     */
    resetNavigation(): void {
        this.currentStepIndex = 0;
        this.generatedStepsFromTree(this.stepsTree);
    }

    /**
     * Go to provided step index.
     * @param stepIndex - Step index.
     * @throws - RangeError when index is greater or equal the array size.
     */
    protected goToStep(stepIndex: number): void {
        if (stepIndex >= this.steps.length || stepIndex < 0) {
            throw new RangeError('Index out of bounds');
        }

        this.currentStepIndex = stepIndex;
        const currentStep = this.steps[this.currentStepIndex];

        this.router.navigate([currentStep.routePath], {
            queryParamsHandling: 'preserve',
        });

        this.stepChangedSubject.next(currentStep);
    }

    /**
     * checks if step can be activated by target route path.
     * It will to through all the steps since the beginning until it finds a step with invalid form data, otherwise target step.
     * @param targetRoutePath - The route path of target step.
     * @returns The first invalid step, otherwise target step @see UrlTree.
     */
    canActivateStep(targetRoutePath: string | undefined): boolean | UrlTree {
        let targetStep;

        if (!targetRoutePath) {
            targetStep = this.steps[0];
        } else {
            targetStep = this.getStepToNavigateByPredicate(
                (step) => step.routePath === targetRoutePath,
            ).step;
        }

        return (
            targetStep.routePath === targetRoutePath ||
            this.router.parseUrl(
                // eslint-disable-next-line @typescript-eslint/no-non-null-assertion
                targetStep.routePath!,
            )
        );
    }

    /**
     * tries to navigate to step provided as parameter.
     * It will to through all the steps from start until it finds an invalid step or reaches target step to navigate to.
     * @param targetStepCode - The code of target step.
     */
    tryNavigateToStep(targetStepCode: string): void {
        if (targetStepCode) {
            this.goToStep(
                this.getStepToNavigateByPredicate(
                    (step) => step.code === targetStepCode,
                ).index,
            );
        } else {
            this.goToStep(0);
        }
    }

    /**
     * Gets the step to navigate having as a target the step provided evaluated on provided predicate function.
     * It will to through all the steps since the beginning until it finds a step with invalid form data, otherwise target step evaluated by predicate function.
     * @param isStep - A predicate function that evaluates if provided step is the desired step to navigate to.
     * @returns The first invalid step, otherwise target step evaluated by predicate function.
     */
    private getStepToNavigateByPredicate(isStep: (step: Step) => boolean): {
        step: Step;
        index: number;
    } {
        for (let index = 0; index < this.steps.length; index++) {
            const step = this.steps[index];

            if (step.formGroupName) {
                const formGroup = this.formStateService.getFormGroup(
                    step.formGroupName as keyof DamageClaimFormGroup,
                );

                if (!formGroup?.valid || isStep(step)) {
                    return { step, index };
                }
            }
        }

        return { step: this.steps[0], index: 0 };
    }
}
