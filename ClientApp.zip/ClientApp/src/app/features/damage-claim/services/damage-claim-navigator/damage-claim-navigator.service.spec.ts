/* eslint-disable @typescript-eslint/no-explicit-any */
import { TestBed } from '@angular/core/testing';

import { DamageClaimNavigatorService } from './damage-claim-navigator.service';
import { FormBuilder, FormGroup } from '@angular/forms';
import { DamageClaimFormStateService } from '../damage-claim-form-state.service';
import {
    ActivatedRoute,
    ActivatedRouteSnapshot,
    Router,
    convertToParamMap,
} from '@angular/router';
import { DamageClaimFormGroup } from '@models/form-groups/damage-claim-form-group.model';
import { of } from 'rxjs';
import { MockProvider } from 'ng-mocks';
import { Step } from '@models/step.model';
import { DamageClaimRoute } from '@features/damage-claim/config/route.builder';
import { Injectable } from '@angular/core';

@Injectable({
    providedIn: 'root',
})
export class DamageClaimNavigatorServiceTest extends DamageClaimNavigatorService {
    constructor(router: Router) {
        super(router);
    }

    gotToStepTest(stepIndex: number) {
        return this.goToStep(stepIndex);
    }
}

const steps = [
    DamageClaimRoute.insuranceHolderStepRoute,
    DamageClaimRoute.damageEventStepRoute,
    DamageClaimRoute.additionalInfoStepRoute,
];

describe('DamageClaimNavigatorService', () => {
    const fb = new FormBuilder();
    let service: DamageClaimNavigatorServiceTest;
    let routerMock: jasmine.SpyObj<Router>;
    let formGroupStateServiceMock: jasmine.SpyObj<DamageClaimFormStateService>;
    let damageClaimFormGroup: FormGroup<DamageClaimFormGroup>;

    const activatedRouteMock = {
        queryParams: of({}),
        snapshot: {
            paramMap: convertToParamMap({}),
        } as ActivatedRouteSnapshot,
    };

    beforeEach(() => {
        TestBed.configureTestingModule({});
        routerMock = jasmine.createSpyObj('Router', ['navigate', 'parseUrl']);
        formGroupStateServiceMock = jasmine.createSpyObj(
            'FormGroupStateService',
            ['getFormGroup', 'getState'],
        );
    });

    describe('Default workflow', () => {
        beforeEach(() => {
            damageClaimFormGroup = fb.group<DamageClaimFormGroup>({} as any);
            formGroupStateServiceMock.getState.and.returnValue(
                damageClaimFormGroup,
            );

            TestBed.configureTestingModule({
                providers: [
                    MockProvider(Router, routerMock),
                    MockProvider(
                        DamageClaimFormStateService,
                        formGroupStateServiceMock,
                    ),
                    MockProvider(ActivatedRoute, activatedRouteMock),
                ],
            });
            service = TestBed.inject(DamageClaimNavigatorServiceTest);
        });

        it('should be created', () => {
            expect(service).toBeTruthy();
        });

        it('should navigate next on all steps', () => {
            let lastStep: Step;
            const subscription = service.stepChanged.subscribe((newStep) => {
                lastStep = newStep;
            });

            for (
                let stepIndex = 0;
                stepIndex < service.getStepsCount() - 1;
                ++stepIndex
            ) {
                const nextStepIndex = stepIndex + 1;

                service.goToNextStep();

                expect(service.getCurrentStepIndex()).toBe(nextStepIndex);
                expect(routerMock.navigate).toHaveBeenCalledOnceWith(
                    [steps[nextStepIndex]],
                    {
                        queryParamsHandling: 'preserve',
                    },
                );

                // eslint-disable-next-line @typescript-eslint/no-non-null-assertion
                expect(lastStep!).toBe(service.getStep(nextStepIndex));

                routerMock.navigate.calls.reset();
            }

            subscription.unsubscribe();
        });

        it('should navigate back on all steps', () => {
            let nextSteps = service.getStepsCount() - 1;

            while (nextSteps-- > 0) {
                service.goToNextStep();
            }

            routerMock.navigate.calls.reset();

            let lastStep: Step;
            const subscription = service.stepChanged.subscribe((newStep) => {
                lastStep = newStep;
            });

            for (
                let stepIndex = service.getStepsCount() - 1;
                stepIndex > 0;
                --stepIndex
            ) {
                const nextStepIndex = stepIndex - 1;

                service.goToPreviousStep();

                expect(service.getCurrentStepIndex()).toBe(nextStepIndex);
                expect(routerMock.navigate).toHaveBeenCalledOnceWith(
                    [steps[nextStepIndex]],
                    {
                        queryParamsHandling: 'preserve',
                    },
                );
                // eslint-disable-next-line @typescript-eslint/no-non-null-assertion
                expect(lastStep!).toBe(service.getStep(nextStepIndex));

                routerMock.navigate.calls.reset();
            }

            subscription.unsubscribe();
        });
        describe('tryNavigateToStep', () => {
            ['', 'step1', 'randomStep'].forEach((stepCode) => {
                it(`should navigate to first step for step code "${stepCode}"`, () => {
                    const goToStepSpy = spyOn<any>(service, 'goToStep');

                    service.tryNavigateToStep(stepCode);

                    expect(goToStepSpy).toHaveBeenCalledOnceWith(0);
                });
            });

            it('should navigate to first invalid step', () => {
                const validFormGroup = jasmine.createSpyObj<FormGroup>(
                    'FormGroupValid',
                    [],
                    {
                        valid: true,
                    },
                );

                const invalidFormGroup = jasmine.createSpyObj<FormGroup>(
                    'FormGroupInvalid',
                    [],
                    {
                        valid: false,
                    },
                );

                formGroupStateServiceMock.getFormGroup
                    .withArgs('insuranceHolder')
                    .and.returnValue(validFormGroup as any);

                formGroupStateServiceMock.getFormGroup
                    .withArgs('damageEvent')
                    .and.returnValue(invalidFormGroup as any);

                const goToStepSpy = spyOn<any>(service, 'goToStep');

                service.tryNavigateToStep('additionalInformation');

                expect(
                    formGroupStateServiceMock.getFormGroup,
                ).toHaveBeenCalledTimes(2);
                expect(
                    formGroupStateServiceMock.getFormGroup,
                ).toHaveBeenCalledWith('insuranceHolder');
                expect(
                    formGroupStateServiceMock.getFormGroup,
                ).toHaveBeenCalledWith('damageEvent');

                expect(
                    formGroupStateServiceMock.getFormGroup,
                ).not.toHaveBeenCalledWith('additionalInformation');

                expect(goToStepSpy).toHaveBeenCalledOnceWith(1);
            });

            it('should navigate to target step', () => {
                const validFormGroup = jasmine.createSpyObj<FormGroup>(
                    'FormGroupValid',
                    [],
                    {
                        valid: true,
                    },
                );

                const invalidFormGroup = jasmine.createSpyObj<FormGroup>(
                    'FormGroupInvalid',
                    [],
                    {
                        valid: false,
                    },
                );

                formGroupStateServiceMock.getFormGroup
                    .withArgs('insuranceHolder')
                    .and.returnValue(validFormGroup as any);

                formGroupStateServiceMock.getFormGroup
                    .withArgs('damageEvent')
                    .and.returnValue(invalidFormGroup as any);

                service.tryNavigateToStep('insuranceHolder');

                expect(
                    formGroupStateServiceMock.getFormGroup,
                ).toHaveBeenCalledTimes(1);
                expect(
                    formGroupStateServiceMock.getFormGroup,
                ).toHaveBeenCalledWith('insuranceHolder');
                expect(
                    formGroupStateServiceMock.getFormGroup,
                ).not.toHaveBeenCalledWith('damageEvent');
                expect(
                    formGroupStateServiceMock.getFormGroup,
                ).not.toHaveBeenCalledWith('additionalInformation');

                expect(routerMock.parseUrl).not.toHaveBeenCalled();
            });
        });

        describe('canActivateStep', () => {
            // eslint-disable-next-line no-undefined
            [undefined, ''].forEach((stepCode) => {
                it(`should navigate to first step for step code "${stepCode}"`, () => {
                    service.canActivateStep(stepCode);

                    expect(routerMock.parseUrl).toHaveBeenCalledOnceWith(
                        DamageClaimRoute.insuranceHolderStepRoute,
                    );
                });
            });

            it('should navigate to first invalid step', () => {
                const validFormGroup = jasmine.createSpyObj<FormGroup>(
                    'FormGroupValid',
                    [],
                    {
                        valid: true,
                    },
                );

                const invalidFormGroup = jasmine.createSpyObj<FormGroup>(
                    'FormGroupInvalid',
                    [],
                    {
                        valid: false,
                    },
                );

                formGroupStateServiceMock.getFormGroup
                    .withArgs('insuranceHolder')
                    .and.returnValue(validFormGroup as any);

                formGroupStateServiceMock.getFormGroup
                    .withArgs('damageEvent')
                    .and.returnValue(invalidFormGroup as any);

                service.canActivateStep(
                    DamageClaimRoute.additionalInfoStepRoute,
                );

                expect(
                    formGroupStateServiceMock.getFormGroup,
                ).toHaveBeenCalledTimes(2);
                expect(
                    formGroupStateServiceMock.getFormGroup,
                ).toHaveBeenCalledWith('insuranceHolder');
                expect(
                    formGroupStateServiceMock.getFormGroup,
                ).toHaveBeenCalledWith('damageEvent');

                expect(
                    formGroupStateServiceMock.getFormGroup,
                ).not.toHaveBeenCalledWith('additionalInformation');

                expect(routerMock.parseUrl).toHaveBeenCalledOnceWith(
                    DamageClaimRoute.damageEventStepRoute,
                );
            });

            it('should navigate to target step', () => {
                const validFormGroup = jasmine.createSpyObj<FormGroup>(
                    'FormGroupValid',
                    [],
                    {
                        valid: true,
                    },
                );

                const invalidFormGroup = jasmine.createSpyObj<FormGroup>(
                    'FormGroupInvalid',
                    [],
                    {
                        valid: false,
                    },
                );

                formGroupStateServiceMock.getFormGroup
                    .withArgs('insuranceHolder')
                    .and.returnValue(validFormGroup as any);

                formGroupStateServiceMock.getFormGroup
                    .withArgs('damageEvent')
                    .and.returnValue(invalidFormGroup as any);

                service.canActivateStep(
                    DamageClaimRoute.insuranceHolderStepRoute,
                );

                expect(
                    formGroupStateServiceMock.getFormGroup,
                ).toHaveBeenCalledTimes(1);
                expect(
                    formGroupStateServiceMock.getFormGroup,
                ).toHaveBeenCalledWith('insuranceHolder');
                expect(
                    formGroupStateServiceMock.getFormGroup,
                ).not.toHaveBeenCalledWith('damageEvent');
                expect(
                    formGroupStateServiceMock.getFormGroup,
                ).not.toHaveBeenCalledWith('additionalInformation');

                expect(routerMock.parseUrl).not.toHaveBeenCalled();
            });
        });

        it('should reset navigation', () => {
            const fillStepsFromTreeSpy = spyOn(
                service,
                'generatedStepsFromTree',
            );

            service.resetNavigation();

            expect(service.getCurrentStepIndex()).toBe(0);
            expect(fillStepsFromTreeSpy).toHaveBeenCalledOnceWith(
                service.getStepsTree(),
            );
        });
    });
});
