import { Injectable } from '@angular/core';
import {
    AbstractControl,
    FormBuilder,
    FormGroup,
    ValidationErrors,
    Validators,
} from '@angular/forms';
import { DamageType } from '@models/damage-type.enum';
import { DeclarerType } from '@models/declarer-type.enum';
import { AdditionalInformationFormGroup } from '@models/form-groups/additional-information-form-group.model';
import { DamageClaimFormGroup } from '@models/form-groups/damage-claim-form-group.model';
import { DamageDescriptionFormGroup } from '@models/form-groups/damage-description-form-group.model';
import { DamageEventStepFormGroup } from '@models/form-groups/damage-event-step-form-group.model';
import { DeclarerContactFormGroup } from '@models/form-groups/declarer-contact-form-group.model';
import { EventDescriptionFormGroup } from '@models/form-groups/event-description-form-group.model';
import { HolderContactFormGroup } from '@models/form-groups/holder-contact-form-group.model';
import { InsuranceHolderStepFormGroup } from '@models/form-groups/insurance-holder-step-form-group.model';
import { InventoryDamageFormGroup } from '@models/form-groups/inventory-damage-form-group.model';
import { InventoryDamageTypeFormGroup } from '@models/form-groups/inventory-damage-type-form-group.model';
import { OptionsYesNoMaybe } from '@models/options-yes-no-maybe.enum';
import { maxBirthDateDeltaInYears } from '@shared/constants/constants';
import { date } from '@shared/validators/date';
import { rangeDateValidator } from '@shared/validators/date-range.validator';
import { time } from '@shared/validators/time';
import { DateConstants, dateYearsInThePast } from '@va-ngx-shared';

/**
 * The name of the key for the custom error to be used for the damagedObject prices & repair cost validation
 */
const PRICES_ERROR_KEY = 'priceEmpty';

@Injectable({
    providedIn: 'root',
})
export class DamageClaimFormBuilderService {
    constructor(private readonly fb: FormBuilder) {}

    /**
     * Build rge form group for the requested step.
     * @param stepName - The name of the step for which the form group should be built.
     * @returns The requested form group.
     * @throws An error if the requested name is not supported.
     */
    buildFormGroup<T extends keyof DamageClaimFormGroup>(
        stepName: T,
    ): DamageClaimFormGroup[T] {
        switch (stepName) {
            case 'insuranceHolder':
                return this.insuranceHolderStepFormGroup() as DamageClaimFormGroup[T];
            case 'damageEvent':
                return this.damageEventStepFormGroup() as DamageClaimFormGroup[T];
            case 'additionalInformation':
                return this.additionalInformationStepFormGroup() as DamageClaimFormGroup[T];
            default:
                throw new Error(
                    `Invalid property name ${stepName} provided to buildFormGroup`,
                );
        }
    }

    /**
     * Creates an instance of @see FormGroup<InsuranceHolderStepFormGroup>
     * @returns an instance of @see FormGroup<InsuranceHolderStepFormGroup>
     */
    insuranceHolderStepFormGroup(): FormGroup<InsuranceHolderStepFormGroup> {
        const insuranceHolderStep = this.fb.group<InsuranceHolderStepFormGroup>(
            {
                declarerType: this.fb.control<DeclarerType | null>(null, [
                    Validators.required,
                ]),
                declarerContact: this.declarerContact(),
                holderContact: this.holderContact(),
            },
        );

        insuranceHolderStep.controls.declarerType.valueChanges.subscribe(
            (value) => {
                if (
                    value === DeclarerType.Advisor ||
                    value === DeclarerType.Broker
                ) {
                    insuranceHolderStep.controls.declarerContact.enable();
                } else {
                    insuranceHolderStep.controls.declarerContact.disable();
                }
            },
        );

        return insuranceHolderStep;
    }

    /**
     * Creates an instance of @see FormGroup<DeclarerContactFormGroup>
     * @returns an instance of @see FormGroup<DeclarerContactFormGroup>
     */
    declarerContact(): FormGroup<DeclarerContactFormGroup> {
        const declarerContact = this.fb.group<DeclarerContactFormGroup>({
            lastName: this.fb.nonNullable.control<string>('', [
                Validators.required,
            ]),
            firstName: this.fb.nonNullable.control<string>('', [
                Validators.required,
            ]),
            phoneNumber: this.fb.nonNullable.control<string | null>('', {
                updateOn: 'blur',
            }),
            email: this.fb.nonNullable.control<string>('', {
                validators: [Validators.required, Validators.email],
                updateOn: 'blur',
            }),
        });

        return declarerContact;
    }

    /**
     * Creates an instance of @see FormGroup<HolderContactFormGroup>
     * @returns an instance of @see FormGroup<HolderContactFormGroup>
     */
    holderContact(): FormGroup<HolderContactFormGroup> {
        const holderContact = this.fb.group<HolderContactFormGroup>({
            lastName: this.fb.control<string | null>('', [Validators.required]),
            firstName: this.fb.control<string | null>('', [
                Validators.required,
            ]),
            birthdate: this.fb.control<Date | null>(null, [
                rangeDateValidator(
                    DateConstants.defaultMinDate,
                    dateYearsInThePast(maxBirthDateDeltaInYears),
                ),
            ]),
            phoneNumber: this.fb.control<string | null>('', {
                validators: [Validators.required],
                updateOn: 'blur',
            }),
            email: this.fb.control<string | null>('', {
                validators: [Validators.required, Validators.email],
                updateOn: 'blur',
            }),
            country: this.fb.control<string | null>('', [Validators.required]),
            postalCode: this.fb.control<number | null>(null, [
                Validators.required,
            ]),
            locality: this.fb.control<string | null>(null, [
                Validators.required,
            ]),
            street: this.fb.control<string | null>('', [Validators.required]),
            contractNumber: this.fb.control<string | null>('', [
                Validators.required,
            ]),
            iban: this.fb.control<string | null>(''),
        });

        return holderContact;
    }

    /**
     * Creates an instance of @see FormGroup<DamageEventStepFormGroup>
     * @returns an instance of @see FormGroup<DamageEventStepFormGroup>
     */
    private damageEventStepFormGroup(): FormGroup<DamageEventStepFormGroup> {
        const damageEventStep = this.fb.group<DamageEventStepFormGroup>({
            damageType: this.fb.control<DamageType | null>(null, [
                Validators.required,
            ]),
            otherDamageType: this.fb.control<string | null>(null, [
                Validators.required,
            ]),
            damageDescription: this.damageDescription(),
            eventDescription: this.eventDescription(),
        });

        // Handle value change for damage type form control.
        damageEventStep.controls.damageType.valueChanges.subscribe((value) => {
            if (value === DamageType.Other) {
                damageEventStep.controls.otherDamageType.enable();
            } else {
                damageEventStep.controls.otherDamageType.disable();
            }
        });

        return damageEventStep;
    }

    /**
     * Creates an instance of @see FormGroup<DamageDescriptionFormGroup>
     * @returns an instance of @see FormGroup<DamageDescriptionFormGroup>
     */
    damageDescription(): FormGroup<DamageDescriptionFormGroup> {
        const damageDescription = this.fb.group<DamageDescriptionFormGroup>({
            hasInventoryDamage: this.fb.control<boolean | null>(null, [
                Validators.required,
            ]),
            hasBuildingDamage: this.fb.control<boolean | null>(null, [
                Validators.required,
            ]),
            buildingDamageDescription: this.fb.control<string | null>('', [
                Validators.required,
            ]),
            inventoryDamage: this.inventoryDamage(),
        });

        // Handle value change for hasBuildingDamage form control.
        damageDescription.controls.hasBuildingDamage.valueChanges.subscribe(
            (value) => {
                if (value) {
                    damageDescription.controls.buildingDamageDescription.enable();
                } else {
                    damageDescription.controls.buildingDamageDescription.disable();
                }
            },
        );

        // Handle value change for hasInventoryDamage form control.
        damageDescription.controls.hasInventoryDamage.valueChanges.subscribe(
            (value) => {
                if (value) {
                    damageDescription.controls.inventoryDamage.enable();
                } else {
                    damageDescription.controls.inventoryDamage.disable();
                }
            },
        );

        return damageDescription;
    }

    /**
     * Creates an instance of @see FormGroup<InventoryDamageFormGroup>
     * @returns an instance of @see FormGroup<InventoryDamageFormGroup>
     */
    inventoryDamage(): FormGroup<InventoryDamageFormGroup> {
        const inventoryDamage = this.fb.group<InventoryDamageFormGroup>({
            inventoryDamages: this.fb.array([this.buildInventoryDamages()]),
        });

        return inventoryDamage;
    }

    /**
     * Creates an instance of @see FormGroup<InventoryDamageTypeFormGroup>
     * @returns an instance of @see FormGroup<InventoryDamageTypeFormGroup>
     */
    buildInventoryDamages(): FormGroup<InventoryDamageTypeFormGroup> {
        const inventoryDamage = this.fb.group<InventoryDamageTypeFormGroup>(
            {
                objectDescription: this.fb.control<string>('', [
                    Validators.required,
                ]),
                objectPrice: this.fb.control<string>('', { updateOn: 'blur' }),
                objectRepairCost: this.fb.control<string>('', {
                    updateOn: 'blur',
                }),
                objectRemarks: this.fb.control<string>(''),
            },
            { validators: this.arePricesValid },
        );

        return inventoryDamage;
    }

    /**
     * Validation function for the damagedObject prices & repair cost
     * At least one of these 2 fields should not be empty
     * @param control - the damagedObject group control
     * @returns null if validation pass, object with empty: true when fails.
     */
    private arePricesValid(control: AbstractControl): ValidationErrors | null {
        const objectPrice = control.get('objectPrice');
        const objectRepairCost = control.get('objectRepairCost');

        if (objectPrice?.value === '' && objectRepairCost?.value === '') {
            return { [PRICES_ERROR_KEY]: true };
        }

        return null;
    }

    /**
     * Creates an instance of @see FormGroup<EventDescriptionFormGroup>
     * @returns an instance of @see FormGroup<EventDescriptionFormGroup>
     */
    eventDescription(): FormGroup<EventDescriptionFormGroup> {
        const eventDescription = this.fb.group<EventDescriptionFormGroup>({
            occurrenceDate: this.fb.control<string | null>('', {
                validators: [Validators.required, date],
                updateOn: 'blur',
            }),
            occurrenceTime: this.fb.control<string | null>('', {
                validators: [time],
                updateOn: 'blur',
            }),
            occurrencePlace: this.fb.control<string | null>('', [
                Validators.required,
            ]),
            circumstances: this.fb.control<string | null>('', [
                Validators.required,
            ]),
        });

        return eventDescription;
    }

    /**
     * Creates an instance of @see FormGroup<AdditionalInformationFormGroup>
     * @returns an instance of @see FormGroup<AdditionalInformationFormGroup>
     */
    private additionalInformationStepFormGroup(): FormGroup<AdditionalInformationFormGroup> {
        const additionalInformation =
            this.fb.group<AdditionalInformationFormGroup>({
                hasOtherInsurer: this.fb.control<boolean | null>(null, [
                    Validators.required,
                ]),
                otherInsurerName: this.fb.control<string | null>('', [
                    Validators.required,
                ]),
                isOtherInsurerInformed: this.fb.control<boolean | null>(null, [
                    Validators.required,
                ]),
                thirdPartyResponsibility: this.fb.control<string | null>('', [
                    Validators.required,
                ]),
                thirdPartyLastName: this.fb.control<string | null>(''),
                thirdPartyFirstName: this.fb.control<string | null>(''),
                thirdPartyCountry: this.fb.control<string | null>(''),
                thirdPartyLocality: this.fb.control<string | null>(''),
                thirdPartyPostalCode: this.fb.control<string | null>(''),
                thirdPartyStreet: this.fb.control<string | null>(''),
                hasPoliceIncidentReport: this.fb.control<boolean | null>(null, [
                    Validators.required,
                ]),
                hasEmergencyMeasures: this.fb.control<boolean | null>(null, [
                    Validators.required,
                ]),
                shouldOrganizeDamagesRepair: this.fb.control<boolean | null>(
                    null,
                    [Validators.required],
                ),
                emergencyMeasuresDescription: this.fb.control<string | null>(
                    '',
                    [Validators.required],
                ),
                otherRemarks: this.fb.control<string | null>(''),
            });

        // Handle value change for hasOtherInsurer form control.
        additionalInformation.controls.hasOtherInsurer.valueChanges.subscribe(
            (value) => {
                if (value) {
                    additionalInformation.controls.otherInsurerName?.enable();
                    additionalInformation.controls.isOtherInsurerInformed?.enable();
                } else {
                    additionalInformation.controls.otherInsurerName?.disable();
                    additionalInformation.controls.isOtherInsurerInformed?.disable();
                }
            },
        );

        // Handle value change for thirdPartyResponsibility form control.
        additionalInformation.controls.thirdPartyResponsibility.valueChanges.subscribe(
            (value) => {
                if (value === OptionsYesNoMaybe.Yes) {
                    additionalInformation.controls.thirdPartyLastName.enable();
                    additionalInformation.controls.thirdPartyFirstName.enable();
                    additionalInformation.controls.thirdPartyCountry.enable();
                    additionalInformation.controls.thirdPartyLocality.enable();
                    additionalInformation.controls.thirdPartyPostalCode.enable();
                    additionalInformation.controls.thirdPartyStreet.enable();
                } else {
                    additionalInformation.controls.thirdPartyLastName.disable();
                    additionalInformation.controls.thirdPartyFirstName.disable();
                    additionalInformation.controls.thirdPartyCountry.disable();
                    additionalInformation.controls.thirdPartyLocality.disable();
                    additionalInformation.controls.thirdPartyPostalCode.disable();
                    additionalInformation.controls.thirdPartyStreet.disable();
                }
            },
        );

        // Handle value change for hasEmergencyMeasures form control.
        additionalInformation.controls.hasEmergencyMeasures.valueChanges.subscribe(
            (value) => {
                if (value) {
                    additionalInformation.controls.emergencyMeasuresDescription.enable();
                } else {
                    additionalInformation.controls.emergencyMeasuresDescription.disable();
                }

                if (value === false) {
                    additionalInformation.controls.shouldOrganizeDamagesRepair.enable();
                } else {
                    additionalInformation.controls.shouldOrganizeDamagesRepair.disable();
                }
            },
        );

        return additionalInformation;
    }
}
