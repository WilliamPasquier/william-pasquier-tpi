import { TestBed } from '@angular/core/testing';

import { DamageClaimFormStateService } from './damage-claim-form-state.service';
import { DamageClaimFormGroup } from '@models/form-groups/damage-claim-form-group.model';
import { FormBuilder } from '@angular/forms';
import { DamageClaimFormBuilderService } from './damage-claim-form-builder.service';

describe('DamageClaimFormStateService', () => {
    const formGroupNames: Array<keyof DamageClaimFormGroup> = [
        'insuranceHolder',
        'damageEvent',
        'additionalInformation',
    ];

    const formBuilder = new FormBuilder();
    let formBuilderServiceMock: jasmine.SpyObj<DamageClaimFormBuilderService>;
    let service: DamageClaimFormStateService;

    beforeEach(() => {
        formBuilderServiceMock =
            jasmine.createSpyObj<DamageClaimFormBuilderService>(
                'DamageClaimFormBuilderService',
                ['buildFormGroup'],
            );

        TestBed.configureTestingModule({
            providers: [
                {
                    provide: DamageClaimFormBuilderService,
                    useValue: formBuilderServiceMock,
                },
            ],
        });
        service = TestBed.inject(DamageClaimFormStateService);
    });

    it('should be created', () => {
        expect(service).toBeTruthy();
    });

    formGroupNames.forEach((formGroupName) => {
        it(`should crate form group named "${formGroupName}`, () => {
            // eslint-disable-next-line @typescript-eslint/no-explicit-any
            const formGroup: any = formBuilder.group({});
            formBuilderServiceMock.buildFormGroup
                .withArgs(formGroupName)
                .and.returnValue(formGroup);

            expect(service.getState().get(formGroupName)).toBeNull();

            const createdFormGroup =
                service.getOrCreateFormGroup(formGroupName);

            expect(createdFormGroup).toEqual(formGroup);
            expect(service.getState().get(formGroupName)).toEqual(formGroup);
            expect(
                formBuilderServiceMock.buildFormGroup,
            ).toHaveBeenCalledOnceWith(formGroupName);
        });
    });

    formGroupNames.forEach((formGroupName) => {
        it(`should create and get form group named "${formGroupName}" from cache`, () => {
            // eslint-disable-next-line @typescript-eslint/no-explicit-any
            const formGroup: any = formBuilder.group({});
            formBuilderServiceMock.buildFormGroup
                .withArgs(formGroupName)
                .and.returnValue(formGroup);

            const createdFormGroup =
                service.getOrCreateFormGroup(formGroupName);

            const getFormGroup = service.getOrCreateFormGroup(formGroupName);

            expect(createdFormGroup).toEqual(formGroup);
            expect(getFormGroup).toEqual(formGroup);
            expect(service.getState().get(formGroupName)).toEqual(formGroup);
            expect(
                formBuilderServiceMock.buildFormGroup,
            ).toHaveBeenCalledOnceWith(formGroupName);
        });
    });

    it('should reset state', () => {
        const state = service.getState();

        service.resetState();

        state.controls.currentStep.setValue('step1');

        expect(service.getState()).not.toBe(state);
    });
});
