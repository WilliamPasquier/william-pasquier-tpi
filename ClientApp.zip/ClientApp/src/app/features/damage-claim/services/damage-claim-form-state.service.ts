import { Injectable, inject } from '@angular/core';
import {
    FormBuilder,
    FormControl,
    FormGroup,
    Validators,
} from '@angular/forms';
import { DamageClaimFormGroup } from '@models/form-groups/damage-claim-form-group.model';
import { Subject, Subscription } from 'rxjs';
import { DamageClaimFormBuilderService } from './damage-claim-form-builder.service';

@Injectable({
    providedIn: 'root',
})
export class DamageClaimFormStateService {
    private readonly formBuilderService = inject(DamageClaimFormBuilderService);

    /**
     * The subject that emits state value changes events for observables.
     */
    private valueChangedSubject = new Subject<void>();

    /**
     * Observable that can be subscribed for state value changes events.
     */
    valueChanged = this.valueChangedSubject.asObservable();

    /**
     * HiO damage claim form group state.
     */
    private state: FormGroup<DamageClaimFormGroup>;

    /**
     * @see FormGroup<DamageClaimFormGroup> value changes @see Subscription.
     */
    private valueChangeSubscription: Subscription;

    constructor(private readonly fb: FormBuilder) {
        this.resetState();
    }

    /**
     * Gets the requested form group.
     * @param propertyName - the name of the form group to retrieve.
     * @returns the form group or undefined if it is not yet defined.
     */
    getOrCreateFormGroup<T extends keyof DamageClaimFormGroup>(
        propertyName: T,
    ): Required<DamageClaimFormGroup>[T] {
        let formGroup = this.state.controls[propertyName];
        if (!formGroup) {
            formGroup = this.formBuilderService.buildFormGroup(propertyName);

            this.state.setControl(propertyName, formGroup, {
                emitEvent: false,
            });
        }

        return formGroup as Required<DamageClaimFormGroup>[T];
    }

    /**
     * Gets the requested form group.
     * @param propertyName - The name of the form group to retrive.
     * @returns the form group or undefined if it is not yet defined.
     */
    getFormGroup<T extends keyof DamageClaimFormGroup>(
        propertyName: T,
    ): DamageClaimFormGroup[T] {
        return this.state.controls[propertyName];
    }

    /**
     * Get the current state of the form
     * @returns - The current instance of {@link FormGroup<DamageClaimFormGroup>}.
     */
    getState(): FormGroup<DamageClaimFormGroup> {
        return this.state;
    }

    /**
     * Callback method that is invoked when from group value changes.
     * Triggers service state value changes.
     */
    private onValueChanges(): void {
        this.valueChangedSubject.next();
    }

    /**
     * Resets the current state of the current instance of {@link FormGroup<DamageClaimFormGroup>}
     */
    resetState(): void {
        this.valueChangeSubscription?.unsubscribe();

        this.state = new FormGroup<DamageClaimFormGroup>({
            currentStep: this.fb.control<string | null>(null),
            recaptcha: this.fb.control<string | null>('', Validators.required),
            files: this.fb.array<FormControl<File>>([]),
        });

        this.valueChangeSubscription = this.state.valueChanges.subscribe(
            this.onValueChanges.bind(this),
        );
    }
}
