import { TestBed } from '@angular/core/testing';

import { DamageClaimFormBuilderService } from './damage-claim-form-builder.service';

describe('DamageClaimFormBuilderService', () => {
  let service: DamageClaimFormBuilderService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(DamageClaimFormBuilderService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
