import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { ComponentFixture, TestBed, fakeAsync } from '@angular/core/testing';
import {
    FormArray,
    FormBuilder,
    FormControl,
    FormGroup,
    ReactiveFormsModule,
    Validators,
} from '@angular/forms';
import { RecaptchaComponentMock } from '@shared/components/recaptcha.mock';
import { ValidationMessagesComponent } from '@shared/components/validation-messages/validation-messages.component';
import { getTranslocoTestingModule } from '@testing/transloco-testing.module';
import { MockComponents, MockProvider } from 'ng-mocks';
import { DamageClaimService } from '../../shared/services/damage-claim/damage-claim.service';
import { DamageAdditionalInfoStepComponent } from './damage-additional-info-step/damage-additional-info-step.component';
import { DamageClaimComponent } from './damage-claim.component';
import { DamageEventStepComponent } from './damage-event-step/damage-event-step.component';
import { InsuranceHolderStepComponent } from './insurance-holder-step/insurance-holder-step.component';
import { ClaimFilesComponent } from '@shared/components/claim-files/claim-files.component';
import { Confirmation, ConfirmationService } from 'primeng/api';
import { ConfirmDialogComponent } from '@shared/components/confirm-dialog/confirm-dialog.component';
import { DamageClaimFormStateService } from './services/damage-claim-form-state.service';
import { DamageClaimStateStorageService } from './services/damage-claim-state-storage/damage-claim-state-storage.service';
import { DamageClaimFormGroup } from '@models/form-groups/damage-claim-form-group.model';

describe('DamageClaimComponent', () => {
    let component: DamageClaimComponent;
    let fixture: ComponentFixture<DamageClaimComponent>;
    let confirmationServiceMock: jasmine.SpyObj<ConfirmationService>;
    let formStateServiceMock: jasmine.SpyObj<DamageClaimFormStateService>;
    let stateStorageServiceMock: jasmine.SpyObj<DamageClaimStateStorageService>;

    beforeEach(async () => {
        confirmationServiceMock = jasmine.createSpyObj<ConfirmationService>(
            'ConfirmationService',
            ['confirm'],
        );

        formStateServiceMock =
            jasmine.createSpyObj<DamageClaimFormStateService>(
                'DamageClaimFormStateService',
                ['getState'],
            );

        formStateServiceMock.getState.and.returnValue(
            new FormGroup<DamageClaimFormGroup>({
                currentStep: new FormControl<string | null>(null),
                recaptcha: new FormControl<string | null>(
                    '',
                    Validators.required,
                ),
                files: new FormArray<FormControl<File>>([]),
            }),
        );

        stateStorageServiceMock =
            jasmine.createSpyObj<DamageClaimStateStorageService>([
                'hasSavedState',
                'loadSavedState',
                'removeSavedState',
            ]);

        await TestBed.configureTestingModule({
            imports: [getTranslocoTestingModule(), ReactiveFormsModule],
            declarations: [
                DamageClaimComponent,
                ...MockComponents(
                    ValidationMessagesComponent,
                    InsuranceHolderStepComponent,
                    DamageEventStepComponent,
                    DamageAdditionalInfoStepComponent,
                    RecaptchaComponentMock,
                    ClaimFilesComponent,
                    ConfirmDialogComponent,
                ),
            ],
            providers: [
                FormBuilder,
                { provide: DamageClaimService, useValue: {} },
                MockProvider(ConfirmationService, confirmationServiceMock),
                MockProvider(DamageClaimFormStateService, formStateServiceMock),
                MockProvider(
                    DamageClaimStateStorageService,
                    stateStorageServiceMock,
                ),
            ],
            schemas: [CUSTOM_ELEMENTS_SCHEMA],
        }).compileComponents();

        document.body.append(document.createElement('hf-root')); // needs to be added because of the renderer2
        fixture = TestBed.createComponent(DamageClaimComponent);
        component = fixture.componentInstance;
    });

    it('should create', () => {
        fixture.detectChanges();
        expect(component).toBeTruthy();
    });

    describe('load state', () => {
        let clock = jasmine.clock();

        beforeEach(() => {
            clock = jasmine.clock().install();
        });

        afterEach(() => {
            clock.uninstall();
        });

        it('should display load state confirmation dialog', fakeAsync(() => {
            stateStorageServiceMock.hasSavedState.and.returnValue(true);

            fixture.detectChanges();

            clock.tick(201);

            expect(stateStorageServiceMock.hasSavedState).toHaveBeenCalledTimes(
                1,
            );

            expect(confirmationServiceMock.confirm).toHaveBeenCalledOnceWith({
                message: 'components.confirmationDialog.loadStateConfirmation',
                icon: 'va-icon-info-circle',
                accept: jasmine.any(Function),
                reject: jasmine.any(Function),
            });

            expect(
                stateStorageServiceMock.loadSavedState,
            ).not.toHaveBeenCalled();
            expect(
                stateStorageServiceMock.removeSavedState,
            ).not.toHaveBeenCalled();
        }));

        it('should not load or remove saved state', () => {
            fixture.detectChanges();

            clock.tick(200);

            expect(stateStorageServiceMock.hasSavedState).toHaveBeenCalledTimes(
                1,
            );

            expect(confirmationServiceMock.confirm).not.toHaveBeenCalled();
            expect(
                stateStorageServiceMock.loadSavedState,
            ).not.toHaveBeenCalled();
            expect(
                stateStorageServiceMock.removeSavedState,
            ).not.toHaveBeenCalled();
        });

        it('shoul remove saved state', () => {
            stateStorageServiceMock.hasSavedState.and.returnValue(true);

            fixture.detectChanges();

            clock.tick(200);

            const confirmationOptions: Confirmation =
                confirmationServiceMock.confirm.calls.mostRecent().args[0];

            expect(confirmationOptions.reject).not.toBeNull();

            if (confirmationOptions.reject) {
                confirmationOptions.reject();
            }

            expect(stateStorageServiceMock.hasSavedState).toHaveBeenCalledTimes(
                1,
            );

            expect(confirmationServiceMock.confirm).toHaveBeenCalledOnceWith({
                message: 'components.confirmationDialog.loadStateConfirmation',
                icon: 'va-icon-info-circle',
                accept: jasmine.any(Function),
                reject: jasmine.any(Function),
            });

            expect(stateStorageServiceMock.hasSavedState).toHaveBeenCalledTimes(
                1,
            );
            expect(
                stateStorageServiceMock.loadSavedState,
            ).not.toHaveBeenCalled();
            expect(
                stateStorageServiceMock.removeSavedState,
            ).toHaveBeenCalledTimes(1);
        });
    });
});
