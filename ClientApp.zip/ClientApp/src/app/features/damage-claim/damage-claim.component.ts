/* eslint-disable max-params */
/* eslint-disable no-console */
import {
    AfterViewInit,
    ChangeDetectorRef,
    Component,
    ElementRef,
    Input,
    OnInit,
    Renderer2,
    inject,
} from '@angular/core';
import { FormArray, FormControl, FormGroup } from '@angular/forms';
import { DamageClaimFormGroup } from '@models/form-groups/damage-claim-form-group.model';
import { DamageClaimService } from '@shared/services/damage-claim/damage-claim.service';
import { DamageClaimMapper } from '@mappers/damage-claim.mapper';
import { Router } from '@angular/router';
import { confirmationPageRoute } from './config/route.builder';
import { DamageClaimFormStateService } from './services/damage-claim-form-state.service';
import { DamageClaimStateStorageService } from './services/damage-claim-state-storage/damage-claim-state-storage.service';
import { ConfirmationService } from 'primeng/api';
import { DialogIcon } from '@va-ngx-shared';
import { TranslocoService } from '@ngneat/transloco';
import { StepComponent } from '@shared/components/step-component';
import { DamageClaimNavigatorService } from './services/damage-claim-navigator/damage-claim-navigator.service';
import { Subscription } from 'rxjs';

@Component({
    selector: 'hf-damage-claim',
    templateUrl: './damage-claim.component.html',
    styleUrls: ['./damage-claim.component.scss'],
})
export class DamageClaimComponent implements OnInit, AfterViewInit {
    private readonly formStateService = inject(DamageClaimFormStateService);

    private readonly stateStorageService = inject(
        DamageClaimStateStorageService,
    );

    private readonly confirmationService = inject(ConfirmationService);

    private readonly translocoService = inject(TranslocoService);

    private readonly navigatorService = inject(DamageClaimNavigatorService);

    private readonly damageClaimService = inject(DamageClaimService);

    formGroup: FormGroup<DamageClaimFormGroup>;

    /**
     * Recaptcha form control.
     */
    recaptcha: FormControl<string | null>;

    /**
     * List of selected files.
     */
    files: FormArray<FormControl<File>>;

    /**
     * The data protection page url.
     */
    dataProtectionPageUrl: string;

    /**
     * The cookie policy page url.
     */
    cookiePolicyPageUrl: string;

    /**
     * The confirmation text displayed when loading state from local storage.
     */
    loadStateConfirmationText: string;

    /**
     * The current step index.
     */
    currentStepIndex = 0;

    /**
     * The current active step.
     */
    currentStepComponent: StepComponent;

    /**
     * Number of total steps on current workflow.
     */
    numberOfSteps: number;

    /**
     * Submit is in progress.
     */
    @Input()
    isProcessing: boolean;

    /**
     * The subscription of step changed events of @see NavigatorService
     */
    stepChangedSubscription: Subscription;

    constructor(
        private damageClaimMapper: DamageClaimMapper,
        private router: Router,
        private renderer: Renderer2,
        private el: ElementRef,
        private cdr: ChangeDetectorRef,
    ) {
        const rootComponent = this.renderer.selectRootElement('hf-root', true);
        this.dataProtectionPageUrl = rootComponent.getAttribute(
            'data-data-protection-page',
        );
        this.cookiePolicyPageUrl = rootComponent.getAttribute(
            'data-cookie-policy-page',
        );
    }

    ngOnInit(): void {
        this.translocoService
            .selectTranslate(
                'components.confirmationDialog.loadStateConfirmation',
            )
            .subscribe((value) => (this.loadStateConfirmationText = value));

        this.numberOfSteps = this.navigatorService.getStepsCount();

        this.stepChangedSubscription =
            this.navigatorService.stepChanged.subscribe((step) => {
                const newStepIndex =
                    this.navigatorService.getCurrentStepIndex();

                if (newStepIndex !== this.currentStepIndex) {
                    this.currentStepIndex = newStepIndex;
                    this.formStateService
                        .getState()
                        .controls.currentStep.setValue(step.code);
                }
            });

        this.formGroup = this.formStateService.getState();

        this.recaptcha = this.formGroup.controls.recaptcha;
        this.files = this.formGroup.controls.files;
    }

    ngAfterViewInit(): void {
        if (this.stateStorageService.hasSavedState()) {
            setTimeout(
                () =>
                    this.confirmationService.confirm({
                        message: this.loadStateConfirmationText,
                        icon: DialogIcon.InfoCircle,
                        accept: this.loadSavedState.bind(this),
                        reject: this.resetSavedState.bind(this),
                    }),
                200,
            );
        }
    }

    /**
     * Load the state saved on local storage from previous form interactions and navigate to first invalid step.
     */
    private loadSavedState(): void {
        this.stateStorageService.loadSavedState();
        const stepToNavigate =
            this.formStateService.getState().controls.currentStep.value;

        if (stepToNavigate) {
            this.navigatorService.tryNavigateToStep(stepToNavigate);
        }
    }

    /**
     * Removes the state saved on local storage from previous form interactions.
     */
    private resetSavedState(): void {
        this.stateStorageService.removeSavedState();
    }

    /**
     * Handler for router outlet active event.
     * @param stepComponent - Activated step component.
     */
    onRouterOutletActivate(stepComponent: StepComponent) {
        this.numberOfSteps = this.navigatorService.getStepsCount();
        this.currentStepComponent = stepComponent;
        // this.isConfirmationPage = this.router.url === '/confirmation';
        this.cdr.detectChanges();
    }

    /**
     * Handles on go to previous step button is clicked.
     * @param event - The event.
     */
    onPreviousStep(event: Event): void {
        const element = event.currentTarget as HTMLButtonElement;
        element.blur();
        this.navigatorService.goToPreviousStep();
    }

    /**
     * Handles on go to next step button is clicked.
     * @param event - The event.
     */
    onNextStep(event: Event): void {
        const stepFormGroup = this.currentStepComponent.formGroup;

        if (!this.currentStepComponent.isCustomNextStep()) {
            if (stepFormGroup.status === 'INVALID') {
                this.focusErrors();
                stepFormGroup.markAllAsTouched();
            } else {
                const element = event.currentTarget as HTMLButtonElement;
                element.blur();
                this.navigatorService.goToNextStep();
            }
        }
    }

    /**
     * Focus first invalid element
     */
    focusErrors() {
        setTimeout(() => {
            const invalidElement = this.el.nativeElement.querySelector(
                '.has-error input:not(.no-error-focus), .has-error textarea',
            );
            if (invalidElement) {
                const header =
                    this.el.nativeElement.querySelector('.is-sticky');
                const offSetTopDifference = header
                    ? invalidElement.offsetTop - header.offsetTop
                    : 100;
                if (offSetTopDifference < 100) {
                    window.scroll(0, invalidElement.offsetTop - 100);
                }
                invalidElement.focus();
            }
        });
    }

    /**
     * Submit damage claim form
     */
    onSubmit(): void {
        if (!this.formGroup.valid) {
            this.formGroup.markAllAsTouched();
            return;
        }

        const damageClaim = this.damageClaimMapper.map(this.formGroup);

        this.formGroup.disable();
        this.isProcessing = true;

        this.damageClaimService
            .sendDamageClaimRequest(
                damageClaim,
                this.formGroup.controls.files.value,
            )
            .subscribe({
                next: (response) => {
                    this.formGroup.reset();
                    this.formGroup.enable();
                    this.formStateService.resetState();
                    this.navigatorService.resetNavigation();
                    this.resetSavedState();
                    this.currentStepIndex = 0;
                    this.router.navigate([confirmationPageRoute, response]);
                },
                error: (error) => {
                    console.log(error);
                    this.formGroup.enable();
                    this.isProcessing = false;
                },
            });
    }
}
