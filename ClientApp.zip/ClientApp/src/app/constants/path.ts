const srcAssetsPath = 'src/ng-assets'; // if you change this path, have a look in angular.json file
const baseUrl = `${window.location.origin}/${window.location.pathname}`;
const publicAssetsPath = `${baseUrl}/ng-assets`;

/**
 * Object to store some path that are used across the app.
 * Mostly assets path as they are subject to changes based on the BFF used (sitefinity, azure...)
 * ⚠ This object don't manage routes ⚠
 */
export const paths = {
    src: {
        assets: srcAssetsPath,
        i18n: `${srcAssetsPath}/i18n`, // used in transloco-testing.module.ts imports
    },
    public: {
        assets: publicAssetsPath,
        i18n: `${publicAssetsPath}/i18n`,
        config: `${publicAssetsPath}/config/config.json`,
        hioFnolApi: '/public-api/hio-fnol',
    },
};
