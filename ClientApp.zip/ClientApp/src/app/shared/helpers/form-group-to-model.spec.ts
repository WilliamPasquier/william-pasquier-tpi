import { FormGroup, FormControl, FormArray } from '@angular/forms';
import { FormGroupToModel } from './form-group-to-model';

describe('FormGroupToModel', () => {
    it('should support simple FormGroup interface with null', () => {
        interface SimpleNullableFormGroup {
            hasOtherInsurer: FormControl<boolean | null>;
            otherRemarks: FormControl<string | null>;
        }

        const formGroup = new FormGroup<SimpleNullableFormGroup>({
            hasOtherInsurer: new FormControl<boolean | null>(null),
            otherRemarks: new FormControl<string | null>(null),
        });
        formGroup.setValue({ hasOtherInsurer: false, otherRemarks: 'value' });

        const test1 =
            formGroup.value as FormGroupToModel<SimpleNullableFormGroup>;
        expect(test1.hasOtherInsurer).toBe(false);
        expect(test1.otherRemarks).toBe('value');

        const test2: FormGroupToModel<SimpleNullableFormGroup> = {
            hasOtherInsurer: null,
            otherRemarks: null,
        };
        expect(test2.hasOtherInsurer).toBe(null);
        expect(test2.otherRemarks).toBe(null);
    });

    it('should support simple FormGroup interface non nullable', () => {
        interface SimpleFormGroup {
            hasOtherInsurer: FormControl<boolean>;
            otherRemarks: FormControl<string>;
        }

        const test1: FormGroupToModel<SimpleFormGroup> = {
            hasOtherInsurer: false,
            otherRemarks: 'value',
        };
        expect(test1.hasOtherInsurer).toBe(false);
        expect(test1.otherRemarks).toBe('value');
    });

    it('should support FormGroup interface with subgroup', () => {
        interface SubGroup {
            hasOtherInsurer: FormControl<boolean | null>;
            otherRemarks: FormControl<string | null>;
        }

        interface FormGroupWithSubGroup {
            recaptcha: FormControl<string | null>;
            additionalInfo: FormGroup<SubGroup>;
        }

        const test1: FormGroupToModel<FormGroupWithSubGroup> = {
            recaptcha: null,
            additionalInfo: { hasOtherInsurer: null, otherRemarks: null },
        };
        expect(test1.recaptcha).toBe(null);
        expect(test1.additionalInfo?.hasOtherInsurer).toBe(null);
        expect(test1.additionalInfo?.otherRemarks).toBe(null);

        const test2: FormGroupToModel<FormGroupWithSubGroup> = {
            recaptcha: 'value',
            additionalInfo: { hasOtherInsurer: false, otherRemarks: 'value' },
        };
        expect(test2.recaptcha).toBe('value');
        expect(test2.additionalInfo?.hasOtherInsurer).toBe(false);
        expect(test2.additionalInfo?.otherRemarks).toBe('value');
    });

    it('should support FormGroup interface with optional subgroup', () => {
        interface OptionalSubGroup {
            hasOtherInsurer: FormControl<boolean | null>;
            otherRemarks: FormControl<string | null>;
        }

        interface FormGroupWithOptionalSubGroup {
            recaptcha: FormControl<string | null>;
            additionalInfo?: FormGroup<OptionalSubGroup>;
        }

        const test1: FormGroupToModel<FormGroupWithOptionalSubGroup> = {
            recaptcha: null,
        };
        expect(test1.recaptcha).toBe(null);
        expect(test1.additionalInfo).not.toBeDefined();

        const test2: FormGroupToModel<FormGroupWithOptionalSubGroup> = {
            recaptcha: 'value',
            additionalInfo: { hasOtherInsurer: false, otherRemarks: 'value' },
        };
        expect(test2.recaptcha).toBe('value');
        expect(test2.additionalInfo?.hasOtherInsurer).toBe(false);
        expect(test2.additionalInfo?.otherRemarks).toBe('value');
    });

    it('should support FormGroup interface with FormArray', () => {
        interface ArrayFormGroup {
            lastName: FormControl<string | null>;
            firstName: FormControl<string | null>;
        }

        interface SimpleGroupWithArray {
            hasOtherInsurer: FormControl<boolean | null>;
            otherRemarks: FormControl<string | null>;
            witnesses?: FormArray<FormGroup<ArrayFormGroup>>;
        }

        const test1: FormGroupToModel<SimpleGroupWithArray> = {
            hasOtherInsurer: null,
            otherRemarks: 'value',
        };
        expect(test1.hasOtherInsurer).toBe(null);
        expect(test1.witnesses).not.toBeDefined();

        const test2: FormGroupToModel<SimpleGroupWithArray> = {
            hasOtherInsurer: false,
            otherRemarks: 'value',
            witnesses: [{ lastName: null, firstName: null }],
        };
        expect(test2.hasOtherInsurer).toBe(false);

        expect(test2.witnesses).toBeDefined();
        expect(test2.witnesses?.[0].lastName).toBe(null);
        expect(test2.witnesses?.[0].firstName).toBe(null);
    });

    it('should support FormGroup interface with FormArray in subgroup', () => {
        interface ArrayFormSubGroup {
            lastName: FormControl<string | null>;
            firstName: FormControl<string | null>;
        }

        interface SubGroupWithArray {
            hasOtherInsurer: FormControl<boolean | null>;
            otherRemarks: FormControl<string | null>;
            witnesses?: FormArray<FormGroup<ArrayFormSubGroup>>;
        }

        interface GroupWithSubGroupArray {
            recaptcha: FormControl<string | null>;
            additionalInfo?: FormGroup<SubGroupWithArray>;
        }

        const test1: FormGroupToModel<GroupWithSubGroupArray> = {
            recaptcha: null,
            additionalInfo: { hasOtherInsurer: false, otherRemarks: 'value' },
        };
        expect(test1.recaptcha).toBe(null);
        expect(test1.additionalInfo?.witnesses).not.toBeDefined();

        const test2: FormGroupToModel<GroupWithSubGroupArray> = {
            recaptcha: null,
            additionalInfo: {
                hasOtherInsurer: false,
                otherRemarks: 'value',
                witnesses: [{ lastName: 'value', firstName: null }],
            },
        };

        expect(test1.recaptcha).toBe(null);
        expect(test2.additionalInfo?.witnesses).toBeDefined();
        expect(test2.additionalInfo?.witnesses?.[0].lastName).toBe('value');
        expect(test2.additionalInfo?.witnesses?.[0].firstName).toBe(null);
    });
});
