/**
 * Represents an instance of VaInputPhone web component.
 */
export interface VaInputPhone {
    /**
     * Gets a value indicating whether value is a valid phone number or not.
     */
    get isValidNumber(): boolean;
}
