/**
 * The application settings
 */
export interface ApplicationSettings {
    recaptchaKey: string;
}
