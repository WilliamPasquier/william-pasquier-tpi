/**
 * Generic interface for components that render list of items.
 */
export interface ListItem {
    value: string | boolean;
    i18nKey: string;
    text?: string;
}
