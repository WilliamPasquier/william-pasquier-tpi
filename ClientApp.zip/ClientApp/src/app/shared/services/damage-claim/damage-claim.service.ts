import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Claim } from '@models/claim';
import { Observable } from 'rxjs';
import { TranslocoService } from '@ngneat/transloco';
import { ClaimHttpClientService } from '@services/claim-http-client.service';

@Injectable({
    providedIn: 'root',
})
export class DamageClaimService extends ClaimHttpClientService {
    constructor(http: HttpClient, translocoService: TranslocoService) {
        super(http, translocoService);
    }

    /**
     * Send damage claim request
     * @param damageClaim - damage claim to send
     * @param files - List of uploaded files.
     * @returns - true is the creation was successful
     */
    sendDamageClaimRequest(
        damageClaim: Claim,
        files: Array<File> | null,
    ): Observable<string> {
        return this.postClaim(damageClaim, files, 'submit-damage-claim');
    }
}
