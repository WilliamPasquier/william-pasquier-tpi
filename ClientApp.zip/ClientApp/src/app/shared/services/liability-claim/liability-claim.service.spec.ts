import { HttpClient } from '@angular/common/http';
import { TestBed } from '@angular/core/testing';
import {
    HttpClientTestingModule,
    HttpTestingController,
} from '@angular/common/http/testing';
import { LiabilityClaimService } from './liability-claim.service';
import { getTranslocoTestingModule } from '@testing/transloco-testing.module';
import { TranslocoService } from '@ngneat/transloco';
import { paths } from '@appConstants/path';
import { LiabilityClaim } from '@models/liability-claim';
import { LiabilityDeclarerType } from '@models/liability-declarer-type.enum';
import { LiabilityDamageCausedBy } from '@models/liability-damage-caused-by.enum';
import { LiabilityDamageType } from '@models/liability-damage-type.enum';

describe('LiabilityClaimService', () => {
    let service: LiabilityClaimService;
    let httpClient: HttpClient;
    let httpTestingController: HttpTestingController;

    beforeEach(() => {
        TestBed.configureTestingModule({
            imports: [HttpClientTestingModule, getTranslocoTestingModule()],
        });

        httpClient = TestBed.inject(HttpClient);
        httpTestingController = TestBed.inject(HttpTestingController);
        service = TestBed.inject(LiabilityClaimService);
        service = new LiabilityClaimService(
            httpClient,
            TestBed.inject(TranslocoService),
        );
    });

    afterEach(() => {
        // After every test, assert that there are no more pending requests.
        httpTestingController.verify();
    });

    it('should be created', () => {
        expect(service).toBeTruthy();
    });

    [
        null,
        [],
        [new File([], 'fileName1.txt')],
        [new File([], 'fileName1.txt'), new File([], 'fileName2.txt')],
    ].forEach((testFiles) => {
        it('should submit', () => {
            const request: LiabilityClaim = {
                declarerType: LiabilityDeclarerType.Policyholder,
                holderContact: {
                    firstName: 'John',
                    lastName: 'Smith',
                    birthdate: '01.01.1993',
                    country: 'Portugal',
                    email: 'example@vaudoise.ch',
                    iban: '78654325674534',
                    locality: 'Porto',
                    phoneNumber: '+3516536353',
                    postalCode: 4458,
                    contractNumber: '123456 1 2921',
                    street: 'No 1 Avenue',
                    legalProtection: null,
                },
                declarerContact: null,
                eventDescription: {
                    circumstances: 'House Fire',
                    occurrenceDate: '12.12.2022',
                    occurrencePlace: 'Porto',
                    occurrenceTime: '14:32',
                    hasPoliceReport: false,
                    hasWitness: false,
                    witnesses: null,
                    isInsuredResponsible: false,
                    isThirdPartyResponsible: false,
                    thirdPartyResponsible: null,
                },
                damageCausedBy: LiabilityDamageCausedBy.AnimalDamage,
                damageDescription: {
                    accidentInsurer: null,
                    animalType: 'beauty',
                    damagedObjectType: '',
                    damageType: [LiabilityDamageType.AnimalDamage],
                    employer: null,
                    hasWorkIncapacity: false,
                    injuriesType: null,
                    insuredInjuredPartyRelationship: '',
                    occupation: null,
                    propertyManagementName: null,
                    repairCost: null,
                    injuredParty: {
                        firstName: 'Me',
                        lastName: 'Too',
                        birthdate: '1980.01.01',
                        country: 'CH',
                        email: 'test@test.com',
                        locality: 'Lausanne',
                        phoneNumber: '+41796865959',
                        postalCode: 1001,
                        street: 'ici 3',
                    },
                },
                additionalInfo: {
                    isRelatedToAnotherDomesticAccident: false,
                    domesticClaimNumber: null,
                    otherRemarks: 'other',
                },
                reCaptcha: 'recaptcha',
            };

            service
                .sendClaimRequest(request, testFiles)
                .subscribe((data) => expect(data).not.toBeNull);

            const req = httpTestingController.expectOne(
                `${paths.public.hioFnolApi}/submit-liability-claim`,
            );
            const body = JSON.stringify(request);

            expect(req.request.method).toEqual('POST');
            expect(req.request.body).not.toBeNull();

            const formData = req.request.body as FormData;
            expect(formData.get('claim')).toEqual(body);

            if (testFiles && testFiles.length > 0) {
                for (let i = 0; i < testFiles.length; ++i) {
                    const file = formData.get(`file${i}`) as File;

                    expect(file).not.toBeNull();
                    expect(file.name).toBe(`fileName${i + 1}.txt`);
                }
            } else {
                for (let i = 0; i < 2; ++i) {
                    expect(formData.has(`file${i + 1}`)).toBeFalse();
                }
            }

            // Finally, assert that there are no outstanding requests.
            httpTestingController.verify();
        });
    });
});
