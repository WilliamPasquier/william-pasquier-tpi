import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { TranslocoService } from '@ngneat/transloco';
import { LiabilityClaim } from '@models/liability-claim';
import { ClaimHttpClientService } from '@services/claim-http-client.service';

@Injectable({
    providedIn: 'root',
})
export class LiabilityClaimService extends ClaimHttpClientService {
    constructor(http: HttpClient, translocoService: TranslocoService) {
        super(http, translocoService);
    }

    /**
     * Send claim request
     * @param claim - The claim to send
     * @param files - List of uploaded files.
     * @returns - true is the creation was successful
     */
    sendClaimRequest(
        claim: LiabilityClaim,
        files: Array<File> | null,
    ): Observable<{ claimNumber: string }> {
        return this.postClaim(claim, files, 'submit-liability-claim');
    }
}
