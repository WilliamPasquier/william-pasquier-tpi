import { HttpClient, HttpHeaders } from '@angular/common/http';
import { paths } from '@appConstants/path';
import { Claim } from '@models/claim';
import { LiabilityClaim } from '@models/liability-claim';
import { TranslocoService } from '@ngneat/transloco';
import { Observable } from 'rxjs';

export abstract class ClaimHttpClientService {
    constructor(
        private readonly http: HttpClient,
        private readonly translocoService: TranslocoService,
    ) {}

    /**
     * Posts a claim.
     * @param claim - claim instance.
     * @param files - List of uploaded files.
     * @param relativeUrl - The relative endpoint to submit the request.
     * @returns - Return data.
     */
    protected postClaim<TReturn>(
        claim: Claim | LiabilityClaim,
        files: Array<File> | null,
        relativeUrl: string,
    ): Observable<TReturn> {
        const headers = new HttpHeaders().append(
            'Accept-Language',
            this.translocoService.getActiveLang(),
        );

        const formData = new FormData();
        formData.append('claim', JSON.stringify(claim));

        if (files) {
            files.forEach((file, index) => {
                formData.append(`file${index}`, file, file.name);
            });
        }

        return this.http.post<TReturn>(
            `${paths.public.hioFnolApi}/${relativeUrl}`,
            formData,
            { headers },
        );
    }
}
