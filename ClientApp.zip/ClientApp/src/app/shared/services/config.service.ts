import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { paths } from '@appConstants/path';
import { ApplicationSettings } from '@models/application-settings';
import { Observable, tap } from 'rxjs';

@Injectable({
    providedIn: 'root',
})
export class ConfigService {
    constructor(private http: HttpClient) {}

    private configSettings: ApplicationSettings;

    /**
     * Gets the settings.
     * @returns The settings
     */
    get settings() {
        return this.configSettings;
    }

    /**
     * Loads the settings.
     * @returns The promise with the settings.
     */
    load(): Observable<ApplicationSettings> {
        return this.http.get<ApplicationSettings>(paths.public.config).pipe(
            tap((response: ApplicationSettings) => {
                this.configSettings = response;
            }),
        );
    }
}
