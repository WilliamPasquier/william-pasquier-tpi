import {
    APP_INITIALIZER,
    CUSTOM_ELEMENTS_SCHEMA,
    NgModule,
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RadioButtonGroupComponent } from './components/radio-button-group/radio-button-group.component';
import { TranslocoModule } from '@ngneat/transloco';
import { ValidationMessagesComponent } from './components/validation-messages/validation-messages.component';
import { ConfigService } from '@services/config.service';
import { RECAPTCHA_SETTINGS } from 'ng-recaptcha';
import { PhoneNumberComponent } from './components/phone-number/phone-number.component';
import { FieldInfoComponent } from './components/field-info/field-info.component';
import { FileInputComponent } from './components/file-input/file-input.component';
import { ClaimFilesComponent } from './components/claim-files/claim-files.component';
import { CheckboxGroupComponent } from './components/checkbox-group/checkbox-group.component';
import { FileDropZoneComponent } from './components/file-drop-zone/file-drop-zone.component';
import { ConfirmDialogComponent } from './components/confirm-dialog/confirm-dialog.component';

/**
 * The Shared Module is where we want everything to live that is shared throughout the application.
 * Components, directives, guards, & pipes can all live in the Shared Module.
 * https://thetombomb.com/posts/app-core-shared-feature-modules
 */
@NgModule({
    declarations: [
        RadioButtonGroupComponent,
        ValidationMessagesComponent,
        PhoneNumberComponent,
        FieldInfoComponent,
        FileInputComponent,
        ClaimFilesComponent,
        CheckboxGroupComponent,
    ],
    imports: [
        CommonModule,
        FormsModule,
        ReactiveFormsModule,
        TranslocoModule,
        FileDropZoneComponent,
        ConfirmDialogComponent,
    ],
    exports: [
        RadioButtonGroupComponent,
        CommonModule,
        FormsModule,
        ReactiveFormsModule,
        TranslocoModule,
        ValidationMessagesComponent,
        PhoneNumberComponent,
        FieldInfoComponent,
        FileInputComponent,
        ClaimFilesComponent,
        CheckboxGroupComponent,
        ConfirmDialogComponent,
    ],
    providers: [
        {
            provide: APP_INITIALIZER,
            useFactory: (configService: ConfigService) => {
                return () => configService.load();
            },
            deps: [ConfigService],
            multi: true,
        },
        {
            provide: RECAPTCHA_SETTINGS,
            useFactory: (configService: ConfigService) => {
                return { siteKey: configService.settings.recaptchaKey };
            },
            deps: [ConfigService],
        },
    ],
    schemas: [CUSTOM_ELEMENTS_SCHEMA],
})
export class SharedModule {}
