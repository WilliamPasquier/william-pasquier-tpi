import { AbstractControl, FormControl } from '@angular/forms';
import { customMaxLength } from './custom-max-length';

describe('listMaxNumber', () => {
    let control: AbstractControl;

    beforeEach(() => {
        control = new FormControl();
    });

    [
        null,
        'st',
        123,
        new File([], 'filename1.txt'),
        [],
        ['string'],
        [new File([], 'filename1.txt'), new File([], 'filename2.txt')],
    ].forEach((testValue) => {
        it(`should be valid for value ${JSON.stringify(testValue)}`, () => {
            control.setValue(testValue);

            expect(customMaxLength('customName', 2)(control)).toBeNull();
        });
    });

    [
        'stre',
        [1, 2, 3],
        ['string1', 'string2', 'string3'],
        [
            new File([], 'filename1.txt'),
            new File([], 'filename2.txt'),
            new File([], 'filename3.txt'),
        ],
    ].forEach((testValue) => {
        it(`should be invalid for value ${JSON.stringify(testValue)}`, () => {
            control.setValue(testValue);

            const error = customMaxLength('customName', 2)(control);

            expect(error).not.toBeNull();

            // eslint-disable-next-line dot-notation
            const customError = error?.['customName'];

            expect(customError).not.toBeNull();
            // eslint-disable-next-line dot-notation
            expect(customError?.requiredLength).toBe(2);
            expect(customError?.actualLength).toBe(testValue.length);
        });
    });
});
