import {
    AbstractControl,
    ValidationErrors,
    ValidatorFn,
    Validators,
} from '@angular/forms';
// eslint-disable-next-line @typescript-eslint/no-unused-vars
import { ValidationMessagesComponent } from '@shared/components/validation-messages/validation-messages.component';

/**
 * Performs a {@link Validators.maxLength} validation with a custom named error that can be picked by {@link ValidationMessagesComponent} to show a custom max length message.
 * For more information @see {@link Validators.maxLength}.
 * @param name - The name of the property on returned {@link ValidationErrors} object.
 * @param maxLength - The maximum length allowed.
 * @returns Returns null is valid, error object if not.
 */
export function customMaxLength(name: string, maxLength: number): ValidatorFn {
    return (control: AbstractControl): ValidationErrors | null => {
        const result = Validators.maxLength(maxLength)(control);

        if (result) {
            return {
                // eslint-disable-next-line dot-notation -- Reason: TS will warn about dot-notation as object is typed with [key: string]
                [name]: result['maxlength'],
            };
        }

        return null;
    };
}
