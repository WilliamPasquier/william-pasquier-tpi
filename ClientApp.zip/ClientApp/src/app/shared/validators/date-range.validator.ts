import { AbstractControl, ValidatorFn } from '@angular/forms';
import { format } from 'date-fns';
import { DateConstants } from '@va-ngx-shared';

/**
 * The type of the error object returned
 */
export interface RangeDateError {
    rangeDate: {
        min: string;
        max: string;
    };
}

/**
 * Validate a date range
 * @param min - The minimum value
 * @param max - The maximum value
 * @returns the error object or null if the value is within range
 */
export function rangeDateValidator(min: Date, max: Date): ValidatorFn {
    return (control: AbstractControl): RangeDateError | null => {
        const value = control.value;
        const dateValue = new Date(value).valueOf();

        if (
            !value ||
            (dateValue >= min.valueOf() && dateValue <= max.valueOf())
        ) {
            return null;
        }

        return {
            rangeDate: {
                min: format(min, DateConstants.defaultDateDisplayFormat),
                max: format(max, DateConstants.defaultDateDisplayFormat),
            },
        };
    };
}
