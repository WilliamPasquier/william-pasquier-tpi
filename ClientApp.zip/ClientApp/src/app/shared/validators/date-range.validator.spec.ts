import { FormControl } from '@angular/forms';
import { rangeDateValidator, RangeDateError } from './date-range.validator';
import { format } from 'date-fns';
import { DateConstants } from '@va-ngx-shared';

describe('range validator', () => {
    const maxDate = new Date('2022-09-23');
    const minDate = new Date('2022-09-20');

    describe('factory', () => {
        it('should create a validator function', () => {
            const validatorFn = rangeDateValidator(minDate, maxDate);
            expect(typeof validatorFn).toBe('function');
        });
    });

    describe('generated validator', () => {
        let control: FormControl;

        beforeEach(() => {
            control = new FormControl('', rangeDateValidator(minDate, maxDate));
        });

        it('should not return an error if value is empty', () => {
            control.setValue('');
            expect(control.errors).toBeFalsy();
        });

        it('should not return an error if value is valid', () => {
            control.setValue(new Date('2022-09-22'));
            expect(control.errors).toBeFalsy();
        });

        it('should return a error if value is too big', () => {
            control.setValue(new Date('2022-09-24'));
            const error = control.errors as RangeDateError;
            expect(error).toBeTruthy();
            expect(error.rangeDate.max).toBe(
                format(maxDate, DateConstants.defaultDateDisplayFormat),
            );
            expect(error.rangeDate.min).toBe(
                format(minDate, DateConstants.defaultDateDisplayFormat),
            );
        });

        it('should return a error if value is too small', () => {
            control.setValue(new Date('2022-09-19'));
            const error = control.errors as RangeDateError;
            expect(error).toBeTruthy();
            expect(error.rangeDate.max).toBe(
                format(maxDate, DateConstants.defaultDateDisplayFormat),
            );
            expect(error.rangeDate.min).toBe(
                format(minDate, DateConstants.defaultDateDisplayFormat),
            );
        });
    });
});
