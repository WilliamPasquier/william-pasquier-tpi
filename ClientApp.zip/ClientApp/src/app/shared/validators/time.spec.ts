import { FormControl } from '@angular/forms';
import { time } from './time';

describe('time validator', () => {
    it('should validate successfully', () => {
        const formControl = new FormControl();
        for (let hour = 0; hour <= 23; ++hour) {
            for (let minute = 0; minute <= 59; ++minute) {
                formControl.setValue(
                    `${hour.toString().padStart(2, '0')}:${minute
                        .toString()
                        .padStart(2, '0')}`,
                );
                const result = time(formControl);

                expect(result).toBeNull();
            }
        }
    });

    ['1:10', ':10', '1:1', '24:01', '00:60'].forEach((value) => {
        it(`should fail for ${value} `, () => {
            const formControl = new FormControl();

            formControl.setValue(value);
            const result = time(formControl);

            expect(result).not.toBeNull();
            // eslint-disable-next-line dot-notation
            expect(result?.['time']).not.toBeNull();
        });
    });
});
