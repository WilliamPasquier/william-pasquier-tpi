import { AbstractControl, ValidationErrors, Validators } from '@angular/forms';
import { ValidatorsConstants } from '@appConstants/validators-constants';

/**
 * Performs date format validation (dd.mm.yyyy).
 * @param control - Form control.
 * @returns Validations errors if format validation fails, otherwise null.
 */
export function date(control: AbstractControl): ValidationErrors | null {
    const errors = Validators.pattern(ValidatorsConstants.date.pattern)(
        control,
    );

    if (errors) {
        return {
            date: ValidatorsConstants.date.pattern,
        };
    }

    return null;
}
