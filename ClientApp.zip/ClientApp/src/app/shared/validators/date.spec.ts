import { FormControl } from '@angular/forms';
import { date } from './date';

describe('date validator', () => {
    it('should validate successfully for days', () => {
        const formControl = new FormControl();
        for (let day = 1; day <= 31; ++day) {
            formControl.setValue(`${day.toString().padStart(2, '0')}.01.2000`);
            const result = date(formControl);

            expect(result).toBeNull();
        }
    });

    it('should validate successfully for months', () => {
        const formControl = new FormControl();
        for (let month = 1; month <= 12; ++month) {
            formControl.setValue(
                `01.${month.toString().padStart(2, '0')}.2000`,
            );
            const result = date(formControl);

            expect(result).toBeNull();
        }
    });

    it('should validate successfully for years', () => {
        const formControl = new FormControl();
        for (let year = 2000; year <= 2022; ++year) {
            formControl.setValue(`01.01.${year}`);
            const result = date(formControl);

            expect(result).toBeNull();
        }
    });

    it('should validate successfully for year 9999', () => {
        const formControl = new FormControl();

        formControl.setValue('01.01.9999');
        const result = date(formControl);

        expect(result).toBeNull();
    });

    it('should fail for day 32', () => {
        const formControl = new FormControl();
        formControl.setValue('32.01.2000');
        const result = date(formControl);

        expect(result).not.toBeNull();
        // eslint-disable-next-line dot-notation
        expect(result?.['date']).not.toBeNull();
    });

    it('should fail for month 13', () => {
        const formControl = new FormControl();
        formControl.setValue('01.13.2000');
        const result = date(formControl);

        expect(result).not.toBeNull();
        // eslint-disable-next-line dot-notation
        expect(result?.['date']).not.toBeNull();
    });

    it('should fail for year 99999', () => {
        const formControl = new FormControl();
        formControl.setValue('01.01.99999');
        const result = date(formControl);

        expect(result).not.toBeNull();
        // eslint-disable-next-line dot-notation
        expect(result?.['date']).not.toBeNull();
    });
});
