import { AbstractControl, ValidationErrors, Validators } from '@angular/forms';
import { ValidatorsConstants } from '@appConstants/validators-constants';

/**
 * Performs time format validation (hh:mm).
 * @param control - Form control.
 * @returns Validations errors if format validation fails, otherwise null.
 */
export function time(control: AbstractControl): ValidationErrors | null {
    const errors = Validators.pattern(ValidatorsConstants.time.pattern)(
        control,
    );

    if (errors) {
        return {
            time: ValidatorsConstants.time.pattern,
        };
    }

    return null;
}
