import { AbstractControl, ValidatorFn } from '@angular/forms';

/**
 * The type of the error object returned
 */
export interface MaxFileSizeError {
    maxFileSize: {
        maxSize: number;
    };
}

/**
 * Validates file max size.
 * @param maxSizeMb - The maximum file size allowed in MB
 * @returns the error object if one or more files exceed maximum file size allowed, null otherwise
 */
export function maxFileSize(maxSizeMb: number): ValidatorFn {
    return (control: AbstractControl): MaxFileSizeError | null => {
        if (!control.value) {
            return null;
        }

        const files = Array.isArray(control.value)
            ? control.value
            : [control.value];
        const maxSizeBytes = maxSizeMb * 1024 * 1024;

        if (files.length === 0) {
            return null;
        }

        if (files.find((file) => file.size > maxSizeBytes)) {
            return {
                maxFileSize: {
                    maxSize: maxSizeMb,
                },
            };
        }

        return null;
    };
}
