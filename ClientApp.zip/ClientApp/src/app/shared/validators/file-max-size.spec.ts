import { FormControl } from '@angular/forms';
import { maxFileSize } from './file-max-size';

describe('fileMaxSize validator', () => {
    const testMaxFileSize = 2;
    const testMaxFileSizeMb = testMaxFileSize * 1024 * 1024;

    it('should be valid for null File', () => {
        expect(
            maxFileSize(testMaxFileSize)(new FormControl<File | null>(null)),
        ).toBeNull();
    });

    describe('single file', () => {
        let file: FormControl<File | null>;

        beforeEach(() => {
            file = new FormControl<File | null>(null);
        });

        [0, testMaxFileSizeMb / 2, testMaxFileSizeMb].forEach(
            (testFileSizeMb) =>
                it(`should be valid for file size ${testFileSizeMb}MB`, () => {
                    file.setValue(
                        new File(
                            [new Blob([new ArrayBuffer(testFileSizeMb)])],
                            'test.pdf',
                        ),
                    );
                    expect(maxFileSize(testMaxFileSize)(file)).toBeNull();
                }),
        );

        it('should be invalid for size greater than allowed', () => {
            file.setValue(
                new File(
                    [new Blob([new ArrayBuffer(testMaxFileSizeMb + 1)])],
                    'test.pdf',
                ),
            );

            const error = maxFileSize(testMaxFileSize)(file);
            expect(error).not.toBeNull();
            // eslint-disable-next-line dot-notation
            expect(error?.['maxFileSize']?.['maxSize']).toBe(testMaxFileSize);
        });
    });

    describe('multiple files', () => {
        let files: FormControl<Array<File> | null>;

        beforeEach(() => {
            files = new FormControl<Array<File> | null>(null);
        });

        [0, testMaxFileSizeMb / 2, testMaxFileSizeMb].forEach(
            (testFileSizeMb) =>
                it(`should be valid for file size ${testFileSizeMb}MB`, () => {
                    files.setValue([
                        new File(
                            [new Blob([new ArrayBuffer(testFileSizeMb)])],
                            'test.pdf',
                        ),
                        new File(
                            [
                                new Blob([
                                    new ArrayBuffer(
                                        testFileSizeMb +
                                            (testFileSizeMb === 0 ? 100 : -100),
                                    ),
                                ]),
                            ],
                            'test1.pdf',
                        ),
                    ]);
                    expect(maxFileSize(testMaxFileSize)(files)).toBeNull();
                }),
        );

        it('should be invalid for sizes greater than allowed', () => {
            files.setValue([
                new File(
                    [new Blob([new ArrayBuffer(testMaxFileSizeMb + 1)])],
                    'test.pdf',
                ),
                new File(
                    [new Blob([new ArrayBuffer(testMaxFileSizeMb + 2)])],
                    'test1.pdf',
                ),
            ]);

            const error = maxFileSize(testMaxFileSize)(files);
            expect(error).not.toBeNull();
            // eslint-disable-next-line dot-notation
            expect(error?.['maxFileSize']?.['maxSize']).toBe(testMaxFileSize);
        });

        it('should be invalid when one file has size greater than allowed', () => {
            files.setValue([
                new File(
                    [new Blob([new ArrayBuffer(testMaxFileSizeMb - 200)])],
                    'test.pdf',
                ),
                new File(
                    [new Blob([new ArrayBuffer(testMaxFileSizeMb + 2)])],
                    'test1.pdf',
                ),
            ]);

            const error = maxFileSize(testMaxFileSize)(files);
            expect(error).not.toBeNull();
            // eslint-disable-next-line dot-notation
            expect(error?.['maxFileSize']?.['maxSize']).toBe(testMaxFileSize);
        });
    });
});
