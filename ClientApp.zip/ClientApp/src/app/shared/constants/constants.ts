/**
 * Switzerland country code.
 */
export const SwitzerlandCountryCode = 'CH';

/**
 * Minimum claim date delta use in claim date validation.
 */
export const minClaimDateDeltaInYears = 5;

/**
 * Maximum claim date delta use in claim date validation.
 */
export const maxClaimDateDeltaInYears = 0;

/**
 * Maximum birth date delta use in claim date validation.
 */
export const maxBirthDateDeltaInYears = 16;
