/**
 * The file allowed extensions
 */
export const fileAllowedExtensions = [
    '.png',
    '.jpg',
    '.jpeg',
    '.odt',
    '.docx',
    '.doc',
    '.pdf',
];

/**
 * The file max size in Mb
 */
export const fileMaxSizeInMb = 1.5;

/**
 * The maximum number of files to be uploaded.
 */
export const maxFileNumber = 10;
