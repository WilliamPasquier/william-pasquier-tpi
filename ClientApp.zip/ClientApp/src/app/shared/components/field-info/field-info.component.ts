import { Component, Input } from '@angular/core';
import { AbstractControl, Validators } from '@angular/forms';

/**
 * Show information about optional field.
 */
@Component({
    selector: 'field-info',
    templateUrl: './field-info.component.html',
    styleUrls: ['./field-info.component.scss'],
})
export class FieldInfoComponent {
    @Input() control: AbstractControl | null;

    /**
     * Indicates whether field is optional or not.
     * @returns True if is optional, otherwise false.
     */
    isOptional(): boolean {
        return this.control?.hasValidator(Validators.required) === false;
    }
}
