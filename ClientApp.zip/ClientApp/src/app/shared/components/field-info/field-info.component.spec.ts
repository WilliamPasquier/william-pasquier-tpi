import { ComponentFixture, TestBed } from '@angular/core/testing';
import { FormControl, Validators } from '@angular/forms';
import { By } from '@angular/platform-browser';
import { getTranslocoTestingModule } from '@testing/transloco-testing.module';

import { FieldInfoComponent } from './field-info.component';

describe('FieldInfoComponent', () => {
    let component: FieldInfoComponent;
    let fixture: ComponentFixture<FieldInfoComponent>;

    beforeEach(async () => {
        await TestBed.configureTestingModule({
            declarations: [FieldInfoComponent],
            imports: [getTranslocoTestingModule()],
        }).compileComponents();

        fixture = TestBed.createComponent(FieldInfoComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });

    it('should have empty content when form control is null', () => {
        expect(fixture.debugElement.query(By.css('span'))).toBeFalsy();
    });

    it('should have empty content when form control is required', () => {
        component.control = new FormControl();
        component.control.setValidators([Validators.required]);
        fixture.detectChanges();

        expect(fixture.debugElement.query(By.css('span'))).toBeFalsy();
    });

    it('should have optional field when form control is other than required', () => {
        component.control = new FormControl();
        component.control.setValidators([Validators.email]);
        fixture.detectChanges();

        const span = fixture.debugElement.query(By.css('span'))
            .nativeElement as HTMLSpanElement;
        expect(span).toBeTruthy();
        expect(span.innerHTML).toBe('(components.optionalFieldInfo)');
    });

    it('should have optional field info when form control is not required', () => {
        component.control = new FormControl();
        fixture.detectChanges();
        const span = fixture.debugElement.query(By.css('span'))
            .nativeElement as HTMLSpanElement;
        expect(span).toBeTruthy();
        expect(span.innerHTML).toBe('(components.optionalFieldInfo)');
    });
});
