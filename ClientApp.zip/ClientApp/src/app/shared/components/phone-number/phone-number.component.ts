import {
    AfterContentInit,
    Component,
    ElementRef,
    forwardRef,
    Injector,
    Input,
    ViewChild,
} from '@angular/core';
import {
    AbstractControl,
    ControlValueAccessor,
    FormControl,
    NgControl,
    NG_VALIDATORS,
    NG_VALUE_ACCESSOR,
    ValidationErrors,
    Validators,
} from '@angular/forms';
import { VaInputPhone } from '@models/va-input-phone';

@Component({
    selector: 'phone-number',
    templateUrl: './phone-number.component.html',
    styleUrls: ['./phone-number.component.scss'],
    providers: [
        {
            provide: NG_VALUE_ACCESSOR,
            // eslint-disable-next-line no-use-before-define
            useExisting: forwardRef(() => PhoneNumberComponent),
            multi: true,
        },
        {
            provide: NG_VALIDATORS,
            // eslint-disable-next-line no-use-before-define
            useExisting: PhoneNumberComponent,
            multi: true,
        },
    ],
})
export class PhoneNumberComponent
    implements ControlValueAccessor, AfterContentInit
{
    @ViewChild('phoneNumber') phoneNumber: ElementRef;

    /**
     * Unique identifier.
     */
    @Input() inputId: string;

    /**
     * The field value.
     */
    value: string | null;

    /**
     * Form formControl bound to this component.
     */
    private formControl: FormControl;

    constructor(private injector: Injector) {}

    /**
     * The changed handler.
     */
    changed: (value: string | null) => void;

    /**
     * The touched handler.
     */
    touched: () => void;

    /**
     * The disabled status.
     */
    isDisabled: boolean;

    /**
     * Notify value change to parent form.
     */
    notifyChange() {
        if (this.changed) {
            this.changed(this.value);
        }
    }

    /**
     * @inheritDoc
     */
    writeValue(value: string | null): void {
        this.value = value;
    }

    /**
     * @inheritDoc
     */
    registerOnChange(fn: (value: string | null) => void): void {
        this.changed = fn;
    }

    /**
     * @inheritDoc
     */
    registerOnTouched(fn: () => void): void {
        this.touched = fn;
    }

    /**
     * @inheritDoc
     */
    setDisabledState?(isDisabled: boolean): void {
        this.isDisabled = isDisabled;
    }

    /**
     * Checks whether value is required or not.
     * @returns True if required, false otherwise.
     */
    isRequired(): boolean {
        return this.formControl?.hasValidator(Validators.required);
    }

    /**
     * @inheritdoc
     */
    ngAfterContentInit(): void {
        this.formControl = this.injector.get(NgControl, null)
            ?.control as FormControl;
    }

    /**
     * @inheritdoc
     */
    validate(formControl: AbstractControl): ValidationErrors | null {
        if (formControl.value) {
            if (
                !(this.phoneNumber.nativeElement as VaInputPhone).isValidNumber
            ) {
                return {
                    inputPhone: formControl.value,
                };
            }
        }

        return null;
    }
}
