import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import {
    FormControl,
    FormGroup,
    FormGroupDirective,
    FormsModule,
    ValidationErrors,
} from '@angular/forms';
import { VaInputPhone } from '@models/va-input-phone';

import { PhoneNumberComponent } from './phone-number.component';

describe('PhoneNumberComponent', () => {
    let component: PhoneNumberComponent;
    let fixture: ComponentFixture<PhoneNumberComponent>;
    let formControl: FormControl;

    beforeEach(async () => {
        const formGroup = new FormGroup({
            formControl: (formControl = new FormControl('')),
        });
        const directive: FormGroupDirective = new FormGroupDirective([], []);
        directive.form = formGroup;

        await TestBed.configureTestingModule({
            declarations: [PhoneNumberComponent],
            imports: [FormsModule],
            schemas: [CUSTOM_ELEMENTS_SCHEMA],
        }).compileComponents();

        fixture = TestBed.createComponent(PhoneNumberComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });

    describe('validation', () => {
        let instanceMock: jasmine.SpyObj<VaInputPhone>;

        beforeEach(() => {
            instanceMock = jasmine.createSpyObj(
                'instanceMock',
                [],
                ['isValidNumber'],
            );
            component.phoneNumber = {
                nativeElement: instanceMock,
            };
        });

        // eslint-disable-next-line no-undefined
        [null, '', undefined].forEach((value) => {
            it(`should be valid with empty value ${value}`, () => {
                instanceMock = jasmine.createSpyObj<VaInputPhone>(
                    'instanceMock',
                    ['isValidNumber'],
                );
                formControl.setValue(value);
                const errors = component.validate(formControl);

                expect(errors).toBeNull();
                expect(instanceMock.isValidNumber).not.toHaveBeenCalled();
            });
        });

        ['+41 123 12 12 12', '+351 123 12 12 12'].forEach((value) => {
            it(`should be valid with value ${value}`, () => {
                const spyIsValidNumber = (
                    Object.getOwnPropertyDescriptor(
                        instanceMock,
                        'isValidNumber',
                    )?.get as jasmine.Spy
                ).and.returnValue(true);
                formControl.setValue(value);
                const errors = component.validate(formControl);

                expect(errors).toBeNull();
                expect(spyIsValidNumber).toHaveBeenCalled();
            });
        });

        ['+41 123 ', '+351 123 22', 'aaaaaa'].forEach((value) => {
            it(`should not be valid with value ${value}`, () => {
                const spyIsValidNumber = (
                    Object.getOwnPropertyDescriptor(
                        instanceMock,
                        'isValidNumber',
                    )?.get as jasmine.Spy
                ).and.returnValue(false);
                formControl.setValue(value);
                const errors = component.validate(
                    formControl,
                ) as ValidationErrors;

                expect(errors).not.toBeNull();
                expect(Object.keys(errors)).toContain('inputPhone');
                // eslint-disable-next-line dot-notation
                expect(errors['inputPhone']).toBe(value);
                expect(spyIsValidNumber).toHaveBeenCalled();
            });
        });
    });
});
