import { AfterViewInit, Component, Input } from '@angular/core';
import {
    FormArray,
    FormBuilder,
    FormControl,
    FormsModule,
    ReactiveFormsModule,
} from '@angular/forms';
import { FileUpload } from 'primeng/fileupload';
import { FileUploadModule } from 'primeng/fileupload';
import { DropdownModule } from 'primeng/dropdown';
import { InputTextModule } from 'primeng/inputtext';
import { CommonModule } from '@angular/common';
import { ListItem } from '@models/list-item';
import { TranslocoModule } from '@ngneat/transloco';
import { fileAllowedExtensions } from '@shared/constants/file.constants';

@Component({
    standalone: true,
    selector: 'hf-p-file-drop-zone',
    templateUrl: './file-drop-zone.component.html',
    styleUrls: ['./file-drop-zone.component.scss'],
    imports: [
        FileUploadModule,
        TranslocoModule,
        DropdownModule,
        InputTextModule,
        FormsModule,
        ReactiveFormsModule,
        CommonModule,
    ],
})
// eslint-disable-next-line @typescript-eslint/no-explicit-any
export class FileDropZoneComponent implements AfterViewInit {
    @Input() files!: FormArray<FormControl<File>>;

    /**
     * List of allowed extensions.
     */
    @Input() allowedExtensions = fileAllowedExtensions.toString();

    /**
     * Max size allowed in bytes.
     */
    @Input() allowedMaxSize = 10 * 1024 * 1024;

    /**
     * Parent tag data-tui value
     */
    @Input() dataTui?: string;

    /**
     * Max size in Mb.
     */
    maxSize = this.bytesToMb(this.allowedMaxSize);

    /**
     * List of available document category items.
     */
    documentCategoryItems: Array<ListItem> = [];

    /**
     * Variable that says if the file was already added or not.
     */
    hasFileAlreadyBeenAdded = false;

    constructor(private readonly fb: FormBuilder) {}

    ngAfterViewInit(): void {
        // Workaround to move the select files button and error messages to the dragable area, since we can not modify it.
        const selectFileButton = document.querySelector(
            'p-fileupload .p-fileupload-buttonbar',
        ) as Node;

        const selectFileButtonDestination =
            document.querySelector('#file-select');

        const errorMessage = document.querySelector(
            'p-fileupload p-messages',
        ) as Node;

        const errorMessageDestination =
            document.querySelector('#error-message');

        selectFileButtonDestination?.append(selectFileButton);
        errorMessageDestination?.append(errorMessage);
    }

    /**
     * Converts bytes to megabytes
     * @param bytes - bytes to convert.
     * @returns bytes in megabytes
     */
    bytesToMb(bytes: number): number {
        let i = 0;

        for (i; bytes > 1024; i++) {
            bytes /= 1024;
        }

        return parseFloat(bytes.toFixed(2));
    }

    /**
     * Method that allow to add files with a category to an array.
     * @param event - File selection event.
     * @param event.currentFiles - The selected files.
     * @param uploader - The file uploader component.
     */
    onSelectFile(
        event: { currentFiles: Array<File> },
        uploader: FileUpload,
    ): void {
        this.hasFileAlreadyBeenAdded = false;
        for (let i = 0; i < event.currentFiles.length; ++i) {
            if (!this.checkExistingFile(event.currentFiles[i].name)) {
                this.files.push(
                    this.fb.nonNullable.control<File>(event.currentFiles[i]),
                    { emitEvent: i === event.currentFiles.length - 1 },
                );
            }
        }

        uploader.files = [];
    }

    /**
     * Method that checks if the file name was already added.
     * @param fileName - File name.
     * @returns a boolean
     */
    checkExistingFile(fileName: string): boolean {
        for (let i = 0; i < this.files.length; i++) {
            if (this.files.value[i]?.name === fileName) {
                this.hasFileAlreadyBeenAdded = true;
                return true;
            }
        }
        return false;
    }
}
