/* eslint-disable no-use-before-define */
import { Component, forwardRef, Input } from '@angular/core';
import {
    ControlValueAccessor,
    FormControl,
    NG_VALUE_ACCESSOR,
} from '@angular/forms';
import { nanoid } from 'nanoid';
import { ListItem } from '@shared/models/list-item';

@Component({
    selector: 'radio-button-group',
    templateUrl: './radio-button-group.component.html',
    styleUrls: ['./radio-button-group.component.scss'],
    providers: [
        {
            provide: NG_VALUE_ACCESSOR,
            useExisting: forwardRef(() => RadioButtonGroupComponent),
            multi: true,
        },
    ],
})
export class RadioButtonGroupComponent implements ControlValueAccessor {
    /**
     * A component id to allow the use of id's in the template.
     * Prefixed with ID to ensure it is a valid HTML ID (must start with a letter).
     */
    componentId = 'ID' + nanoid();

    @Input() items: Array<ListItem>;

    @Input() formControl: FormControl<unknown | null>;

    /**
     * Indicates if the radio button should be stack displayed on devices with screen sizes lower than sm.
     */
    @Input() isStackedSm = false;

    /**
     * The field value.
     */
    value: string | null;

    /**
     * The changed handler.
     */
    changed: (value: string | null) => void;

    /**
     * The touched handler.
     */
    touched: () => void;

    /**
     * The disabled status.
     */
    isDisabled: boolean;

    /**
     * Notify value change to parent form.
     */
    notifyChange() {
        if (this.changed) {
            this.changed(this.value);
        }
    }

    /**
     * @inheritDoc
     */
    writeValue(value: string | null): void {
        this.value = value;
    }

    /**
     * @inheritDoc
     */
    registerOnChange(fn: (value: string | null) => void): void {
        this.changed = fn;
    }

    /**
     * @inheritDoc
     */
    registerOnTouched(fn: () => void): void {
        this.touched = fn;
    }

    /**
     * @inheritDoc
     */
    setDisabledState?(isDisabled: boolean): void {
        this.isDisabled = isDisabled;
    }
}
