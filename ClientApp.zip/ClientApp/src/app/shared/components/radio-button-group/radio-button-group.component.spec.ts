import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ListItem } from '@shared/models/list-item';
import { FormControl, FormsModule } from '@angular/forms';

import { RadioButtonGroupComponent } from './radio-button-group.component';
import { getTranslocoTestingModule } from '@testing/transloco-testing.module';

describe('RadioButtonGroupComponent', () => {
    let fixture: ComponentFixture<RadioButtonGroupComponent>;
    let component: RadioButtonGroupComponent;
    let element: HTMLElement;

    const items: Array<ListItem> = [
        { value: 'item1', i18nKey: 'text1' },
        { value: 'item2', i18nKey: 'text2' },
        { value: 'item3', i18nKey: 'text3' },
    ];

    const formControl: FormControl = new FormControl();

    beforeEach(async () => {
        await TestBed.configureTestingModule({
            declarations: [RadioButtonGroupComponent],
            imports: [getTranslocoTestingModule(), FormsModule],
        }).compileComponents();

        fixture = TestBed.createComponent(RadioButtonGroupComponent);
        component = fixture.componentInstance;
        element = fixture.nativeElement;

        component.items = items;
        component.formControl = formControl;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });

    it('should not be disabled', async () => {
        component.isDisabled = false;
        fixture.detectChanges();
        await fixture.whenStable();

        const radios = element.querySelectorAll<HTMLInputElement>(
            '.multichoice__input',
        );

        expect(radios[0].disabled).toBe(false);
        expect(radios[1].disabled).toBe(false);
        expect(radios[2].disabled).toBe(false);
    });

    it('should be disabled', async () => {
        component.isDisabled = true;
        fixture.detectChanges();
        await fixture.whenStable();

        const radios = element.querySelectorAll<HTMLInputElement>(
            '.multichoice__input',
        );

        expect(radios[0].disabled).toBe(true);
        expect(radios[1].disabled).toBe(true);
        expect(radios[2].disabled).toBe(true);
    });

    it('should have radio buttons', () => {
        const labels = element.querySelectorAll<HTMLLabelElement>(
            '.multichoice__label',
        );

        expect(labels).not.toBeNull();
        expect(labels.length).toBe(3);

        labels.forEach((label) => {
            const radio = element.querySelector<HTMLInputElement>(
                `[id="${label.htmlFor}"]`,
            );

            expect(radio).not.toBeNull();
            expect(radio?.type).toBe('radio');
            expect(radio?.classList.contains('multichoice__input')).toBeTrue();
        });
    });

    it('should auto select radio button', async () => {
        component.value = 'item1';
        fixture.detectChanges();
        await fixture.whenStable();

        const radios = element.querySelectorAll<HTMLInputElement>(
            '.multichoice__input',
        );

        expect(radios).not.toBeNull();
        expect(radios.length).toBe(3);

        const selectedRadio = radios[0];
        expect(selectedRadio?.checked).toBeTrue();
        const notSelectedRadio1 = radios[1];
        expect(notSelectedRadio1?.checked).toBeFalse();
        const notSelectedRadio2 = radios[1];
        expect(notSelectedRadio2?.checked).toBeFalse();
    });

    it('should manual select radio button', () => {
        const radios = element.querySelectorAll<HTMLInputElement>(
            '.multichoice__input',
        );

        expect(radios).not.toBeNull();
        expect(radios.length).toBe(3);
        expect(component.value).toBeUndefined();

        const radio = radios[1];

        expect(radio.checked).toBeFalse();

        radio.click();

        expect(radio.checked).toBeTrue();
        expect(component.value).toBe('item2');
    });

    it('should change selected radio button', async () => {
        component.value = 'item1';
        fixture.detectChanges();
        await fixture.whenStable();

        const radios = element.querySelectorAll<HTMLInputElement>(
            '.multichoice__input',
        );

        expect(radios).not.toBeNull();
        expect(radios.length).toBe(3);
        expect(component.value).toBe('item1');

        const radio1 = radios[0];
        const radio2 = radios[1];

        expect(radio1.checked).toBeTrue();
        expect(radio2.checked).toBeFalse();

        radio2.click();

        expect(radio1.checked).toBeFalse();
        expect(radio2.checked).toBeTrue();
        expect(component.value).toBe('item2');
    });
});
