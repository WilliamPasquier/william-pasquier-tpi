import { AbstractControl, FormGroup } from '@angular/forms';

/**
 * The interface with common fields of a form step component.
 */
export abstract class StepComponent<
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    TControl extends { [K in keyof TControl]: AbstractControl<any> } = any,
> {
    /**
     * The form group of the step.
     */
    formGroup: FormGroup<TControl>;

    /**
     * Indicates if the next step event will be handled in custom code of the step.
     * @returns True if next step is handled by the step, false otherwise
     */
    isCustomNextStep(): boolean {
        return false;
    }
}
