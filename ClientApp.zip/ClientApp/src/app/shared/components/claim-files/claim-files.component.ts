import { Component, Input } from '@angular/core';
import { FormArray, FormBuilder, FormControl } from '@angular/forms';
import { fileAllowedExtensions } from '@shared/constants/file.constants';

@Component({
    selector: 'hf-claim-files',
    templateUrl: './claim-files.component.html',
    styleUrls: ['./claim-files.component.scss'],
})
export class ClaimFilesComponent {
    allowedExtensions = fileAllowedExtensions;

    /**
     * List of selected files.
     */
    @Input() filesControl: FormArray<FormControl<File>>;

    constructor(private readonly fb: FormBuilder) {}

    /**
     * Removes object from the array with the selected index
     * @param objectIndex - index of the damaged items object
     */
    removeDamageItemObject(objectIndex: number): void {
        this.filesControl.removeAt(objectIndex);
    }
}
