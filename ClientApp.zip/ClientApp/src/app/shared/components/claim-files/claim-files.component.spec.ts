import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ClaimFilesComponent } from './claim-files.component';
import { MockComponent } from 'ng-mocks';
import { FileInputComponent } from '../file-input/file-input.component';

describe('ClaimFilesComponent', () => {
    let component: ClaimFilesComponent;
    let fixture: ComponentFixture<ClaimFilesComponent>;

    beforeEach(async () => {
        await TestBed.configureTestingModule({
            declarations: [
                ClaimFilesComponent,
                MockComponent(FileInputComponent),
            ],
        }).compileComponents();

        fixture = TestBed.createComponent(ClaimFilesComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });
});
