import { ComponentFixture, TestBed } from '@angular/core/testing';
import { CheckboxGroupComponent } from './checkbox-group.component';
import { ListItem } from '@shared/models/list-item';
import {
    FormControl,
    ReactiveFormsModule,
} from '@angular/forms';
import { By } from '@angular/platform-browser';
import { CommonModule } from '@angular/common';

const items: Array<ListItem> = [
    { value: 'item1', i18nKey: 'text1', text: 'text1' },
    { value: 'item2', i18nKey: 'text2', text: 'text2' },
    { value: 'item3', i18nKey: 'text3', text: 'text3' },
];

describe('CheckboxGroupComponent', () => {
    let component: CheckboxGroupComponent;
    let fixture: ComponentFixture<CheckboxGroupComponent>;

    beforeEach(async () => {
        await TestBed.configureTestingModule({
            declarations: [CheckboxGroupComponent],
            imports: [CommonModule, ReactiveFormsModule],
        }).compileComponents();

        fixture = TestBed.createComponent(CheckboxGroupComponent);
        component = fixture.componentInstance;
        component.formControl = new FormControl<Array<string>>([]);
        component.items = items;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });

    it('should generate all checkboxes', () => {
        items.forEach((item) => {
            const value = item.value;

            const checkbox = fixture.debugElement.query(
                By.css(`input[value="${value}"]`),
            );

            expect(checkbox).toBeTruthy();
        });
    });

    items.forEach((item) => {
        it(`should add form control when checkbox is clicked`, () => {
            const value = item.value as string;
            const checkbox = fixture.debugElement.query(
                By.css(`input[value="${value}"]`),
            ).nativeElement as HTMLInputElement;

            checkbox.click();

            expect(component.value).not.toBeNull();
            expect(component.value).toEqual([value]);
        });
    });

    it(`should remove form control when checkbox is clicked after being checked`, () => {
        // check all the items
        items.forEach((item) => {
            component.formControl.patchValue([...component.formControl.value, item.value]);
            fixture.detectChanges();

            const value = item.value;
            const checkbox = fixture.debugElement.query(
                By.css(`input[value="${value}"]`),
            ).nativeElement as HTMLInputElement;

            checkbox.click();
        });

        // uncheck all the items
        items.forEach((item) => {
            const value = item.value;
            const checkbox = fixture.debugElement.query(
                By.css(`input[value="${value}"]`),
            ).nativeElement as HTMLInputElement;

            checkbox.click();
        });
        expect(component.value).toEqual([]);
    });

    items.forEach((item) => {
        it(`should check checkbox when form control value is added`, () => {
            const value = item.value;
            component.formControl.setValue([item.value]);
            const checkbox = fixture.debugElement.query(
                By.css(`input[value="${value}"]`),
            ).nativeElement as HTMLInputElement;

            checkbox.click();

            expect(checkbox.checked).toBeTrue();
        });
    });
});
