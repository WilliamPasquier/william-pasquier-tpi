/* eslint-disable no-use-before-define */
import { Component, Input, forwardRef } from '@angular/core';
import {
    ControlValueAccessor,
    FormBuilder,
    FormControl,
    NG_VALUE_ACCESSOR,
} from '@angular/forms';
import { nanoid } from 'nanoid';
import { ListItem } from '@shared/models/list-item';

@Component({
    selector: 'checkbox-group',
    templateUrl: './checkbox-group.component.html',
    styleUrls: ['./checkbox-group.component.scss'],
    providers: [
        {
            provide: NG_VALUE_ACCESSOR,
            useExisting: forwardRef(() => CheckboxGroupComponent),
            multi: true,
        },
    ],
})
export class CheckboxGroupComponent implements ControlValueAccessor {
    /**
     * The css classes to be applied to the component.
     */
    @Input() cssClass?: string;

    /**
     * List of items used in the checkboxes.
     */
    @Input() items: Array<ListItem> = [];

    /**
     * The the form control to get the value.
     */
    @Input() formControl!: FormControl;

    /**
     * A component id to allow the use of id's in the template.
     * Prefixed with ID to ensure it is a valid HTML ID (must start with a letter).
     */
    componentId = 'ID' + nanoid();

    /**
     * The field value.
     */
    value: Array<string> = [];

    /**
     * The changed handler.
     */
    changed: (value: Array<string>) => void;

    /**
     * The touched handler.
     */
    touched: () => void;

    /**
     * The disabled status.
     */
    isDisabled: boolean;

    constructor(private readonly fb: FormBuilder) {}

    /**
     * @inheritDoc
     */
    writeValue(value: Array<string>): void {
        this.value = value;
    }

    /**
     * @inheritDoc
     */
    registerOnChange(fn: (value: Array<string>) => void): void {
        this.changed = fn;
    }

    /**
     * @inheritDoc
     */
    registerOnTouched(fn: () => void): void {
        this.touched = fn;
    }

    /**
     * @inheritDoc
     */
    setDisabledState?(isDisabled: boolean): void {
        this.isDisabled = isDisabled;
    }

    /**
     * Captures the checkbox change event and adds or removes control from array.
     * @param event - The checkbox change event.
     */
    onCheckboxChange(event: Event): void {
        const e = event.currentTarget as unknown as {
            checked: boolean;
            value: string;
        };

        if (e.checked) {
            this.value = [...this.value, e.value];
        } else {
            this.value = this.value.filter((value) => value !== e.value);
        }

        if (this.changed) {
            this.changed(this.value);
        }
    }
}
