import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FileInputComponent } from './file-input.component';

describe('FileInputComponent', () => {
    let component: FileInputComponent;
    let fixture: ComponentFixture<FileInputComponent>;

    beforeEach(async () => {
        await TestBed.configureTestingModule({
            declarations: [FileInputComponent],
        }).compileComponents();

        fixture = TestBed.createComponent(FileInputComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });

    [
        [new File([], 'test.pdf')],
        [new File([], 'test.pdf'), new File([], 'test1.pdf')],
    ].forEach((files) => {
        it(`should set value when number of files is ${files.length}`, () => {
            const inputElement = jasmine.createSpyObj<HTMLInputElement>(
                'HTMLInputElment',
                [],
                ['files'],
            );
            (
                Object.getOwnPropertyDescriptor(inputElement, 'files')
                    // eslint-disable-next-line @typescript-eslint/no-explicit-any
                    ?.get as any
            ).and.returnValue(files);

            component.onFileChange(inputElement);

            expect(component.value).toEqual(files);
        });
    });

    [null, []].forEach((files) => {
        it(`should not set value when files are ${files}`, () => {
            const inputElement = jasmine.createSpyObj<HTMLInputElement>(
                'HTMLInputElment',
                [],
                ['files'],
            );
            (
                Object.getOwnPropertyDescriptor(inputElement, 'files')
                    // eslint-disable-next-line @typescript-eslint/no-explicit-any
                    ?.get as any
            ).and.returnValue(files);

            component.onFileChange(inputElement);

            expect(component.value).toBeFalsy();
        });
    });
});
