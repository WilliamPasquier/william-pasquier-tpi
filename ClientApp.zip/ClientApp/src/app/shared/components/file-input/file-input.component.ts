import { Component, Input, forwardRef } from '@angular/core';
import {
    AbstractControl,
    ControlValueAccessor,
    NG_VALUE_ACCESSOR,
} from '@angular/forms';
import { fileAllowedExtensions } from '@shared/constants/file.constants';
import { nanoid } from 'nanoid';

@Component({
    selector: 'hf-file-input',
    templateUrl: './file-input.component.html',
    styleUrls: ['./file-input.component.scss'],
    providers: [
        {
            provide: NG_VALUE_ACCESSOR,
            // eslint-disable-next-line no-use-before-define
            useExisting: forwardRef(() => FileInputComponent),
            multi: true,
        },
    ],
})
export class FileInputComponent implements ControlValueAccessor {
    /**
     * Indicates if allows multiple file selection.s
     */
    @Input() multiple: boolean;

    /**
     * The field allowed extensions.
     */
    fileAllowedExtensions = fileAllowedExtensions;

    /**
     * A component id to allow the use of id's in the template.
     * Prefixed with ID to ensure it is a valid HTML ID (must start with a letter).
     */
    componentId = 'ID' + nanoid();

    /**
     * The field value.
     */
    value: Array<File> | null;

    /**
     * The changed handler.
     */
    changed: (value: Array<File> | null) => void;

    /**
     * The touched handler.
     */
    touched: () => void;

    /**
     * The disabled status.
     */
    isDisabled: boolean;

    /**
     * Expose the parent form control to be able to bind the validation errors.
     */
    fileControl: AbstractControl<Array<File> | null> | null;

    /**
     * Notify value change to parent form.
     * @param target - The file input element.
     */
    onFileChange(target: EventTarget | null): void {
        const element = target as HTMLInputElement;

        if ((element.files?.length || 0) > 0) {
            // eslint-disable-next-line @typescript-eslint/no-non-null-assertion
            this.value = Array.from(element.files!);
        } else {
            this.value = null;
        }

        if (this.changed) {
            this.changed(this.value);
        }

        if (this.touched) {
            this.touched();
        }
    }

    /**
     * @inheritDoc
     */
    writeValue(value: Array<File> | null): void {
        this.value = value;
    }

    /**
     * @inheritDoc
     */
    registerOnChange(fn: (value: Array<File> | null) => void): void {
        this.changed = fn;
    }

    /**
     * @inheritDoc
     */
    registerOnTouched(fn: () => void): void {
        this.touched = fn;
    }

    /**
     * @inheritDoc
     */
    setDisabledState?(isDisabled: boolean): void {
        this.isDisabled = isDisabled;
    }
}
