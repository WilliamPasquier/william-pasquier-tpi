/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-empty-function */
import { Component, forwardRef } from '@angular/core';
import { ControlValueAccessor, NG_VALUE_ACCESSOR } from '@angular/forms';

@Component({
    selector: 're-captcha',
    template: '',
    providers: [
        {
            provide: NG_VALUE_ACCESSOR,
            // eslint-disable-next-line no-use-before-define
            useExisting: forwardRef(() => RecaptchaComponentMock),
            multi: true,
        },
    ],
})
export class RecaptchaComponentMock implements ControlValueAccessor {
    writeValue(obj: any): void {}

    /** @inheritdoc */
    registerOnChange(fn: any): void {}

    /** @inheritdoc */
    registerOnTouched(fn: any): void {}

    /** @inheritdoc */
    setDisabledState?(isDisabled: boolean): void {}
}
