import { NgIf } from '@angular/common';
import { Component, Input } from '@angular/core';
import { ConfirmDialogModule } from 'primeng/confirmdialog';

@Component({
    standalone: true,
    selector: 'hf-p-confirm-dialog',
    templateUrl: './confirm-dialog.component.html',
    styleUrls: ['./confirm-dialog.component.scss'],
    imports: [ConfirmDialogModule, NgIf],
})
export class ConfirmDialogComponent {
    /**
     * The text to be displayed on the header of confirmation dialog.
     */
    @Input() headerText = '';

    /**
     * The text to be displayed on the confirmation button.
     */
    @Input() btnConfirmText = '';

    /**
     * The text to be displayed on the cancel button.
     */
    @Input() btnCancelText = '';
}
