import { Component, Input } from '@angular/core';
import { AbstractControl, NgModel } from '@angular/forms';

@Component({
    selector: 'validation-messages',
    templateUrl: './validation-messages.component.html',
    styleUrls: ['./validation-messages.component.scss'],
})
export class ValidationMessagesComponent {
    /**
     * The control from which we should check the errors
     */
    control: AbstractControl | null;

    @Input('control')
    set field(val: AbstractControl | NgModel | null) {
        this.control = val instanceof NgModel ? val.control : val;
    }
}
