import { NgModule } from '@angular/core';

import {
    TranslocoTestingModule,
    TranslocoTestingOptions,
} from '@ngneat/transloco';
import { availableLangs, defaultLang } from '@models/locale.model';

/**
 * Transloco Module factory used for unit tests
 * @param options - some options to configure transloco
 * @returns the created ngmodule
 */
export function getTranslocoTestingModule(
    options: TranslocoTestingOptions = {},
): NgModule {
    return TranslocoTestingModule.forRoot({
        langs: {
            fr: {
                confirmationPage: {
                    claimNumberMessage: '{{ claimNumber }}',
                },
            },
            de: {},
            it: {},
        },
        translocoConfig: {
            availableLangs,
            defaultLang,
        },
        preloadLangs: true,
        ...options,
    });
}
