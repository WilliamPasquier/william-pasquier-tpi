import { Component } from '@angular/core';
import { availableLangs } from '@models/locale.model';
import { TranslocoService } from '@ngneat/transloco';

@Component({
    selector: 'hf-root',
    templateUrl: './app.component.html',
    styleUrls: ['./app.component.scss'],
})
export class AppComponent {
    title = 'hio-fnol';

    constructor(private translocoService: TranslocoService) {
        // Define transloco locale based on <html lang="">
        const lang = window.document.documentElement.lang;
        if (
            availableLangs.find(
                (availableLang: string) => availableLang === lang,
            )
        ) {
            translocoService.setActiveLang(lang);
        }
    }
}
