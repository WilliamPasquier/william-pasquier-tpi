const PROXY_CONFIG = [
    {
        context: '/ResourcePackages/Vaudoise/assets/',
        target: 'https://www-dci.vaudoise.ch',
        secure: false,
        changeOrigin: true,
    },
    {
        context: '/public-api/hio-fnol/submit-liability-claim',
        pathRewrite: {
            '/public-api/hio-fnol/submit-liability-claim': '/liability-claims',
        },
        target: 'http://localhost:5000',
        secure: false,
        changeOrigin: true,
    },
];
module.exports = PROXY_CONFIG;
