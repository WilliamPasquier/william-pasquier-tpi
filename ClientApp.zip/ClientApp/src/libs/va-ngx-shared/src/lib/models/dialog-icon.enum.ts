/**
 * The list of possible icon for the dialog page
 */
export enum DialogIcon {
    /**
     * Vaudoise icon information circle
     */
    InfoCircle = 'va-icon-info-circle',
    /**
     * Vaudoise icon warning triangle
     */
    WarningTriangle = 'va-icon-warning-triangle'
}