/* eslint-disable no-use-before-define */
import { Component, Input } from '@angular/core';
import { ControlValueAccessor } from '@angular/forms';
import { nanoid } from 'nanoid';

/**
 * Angular component that renders an input text box with phone number masking and validation.
 * Requires a reference to va.cms web components javascript libraries.
 */
@Component({
    template: '',
})
export abstract class ControlValueAccessorComponent<T>
    implements ControlValueAccessor
{
    /**
     * A component id to allow the use of id's in the template.
     * Prefixed with ID to ensure it is a valid HTML ID (must start with a letter).
     */
    componentId = 'ID' + nanoid();

    /**
     * The data tui for unit tests.
     */
    @Input() dataTui!: string;

    /**
     * The field value.
     */
    @Input() value!: T;

    /**
     * The disabled status.
     */
    @Input() isDisabled!: boolean;

    /**
     * The changed handler.
     */
    changed!: (value: T) => void;

    /**
     * The touched handler.
     */
    touched!: () => void;

    /**
     * Notify value change to parent form.
     * @param event - The change event.
     */
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    notifyChange(event?: Event) {
        if (this.changed) {
            this.changed(this.value);
        }
    }

    /**
     * Notify that the input was touched.
     */
    notifyTouched() {
        if (this.touched) {
            this.touched();
        }
    }

    /**
     * @inheritDoc
     */
    writeValue(value: T): void {
        this.value = value;
    }

    /**
     * @inheritDoc
     */
    registerOnChange(fn: (value: T) => void): void {
        this.changed = fn;
    }

    /**
     * @inheritDoc
     */
    registerOnTouched(fn: () => void): void {
        this.touched = fn;
    }

    /**
     * @inheritDoc
     */
    setDisabledState?(isDisabled: boolean): void {
        this.isDisabled = isDisabled;
    }
}
