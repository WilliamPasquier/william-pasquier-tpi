import { Injectable } from '@angular/core';
import { BaseStorageService } from '../base-storage.service';

/**
 * Provides access and management to browsers session storage.
 * It encodes the content saved to local storage so that is not stored in plain text.
 * It also serializes the content into JSON format and back to javacripts object instances when deserializing.
 */
@Injectable({
    providedIn: 'root',
})
export class SessionStorageService extends BaseStorageService {
    /**
     * @inheritdoc
     */
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    protected setItem(key: string, value: any) {
        window.sessionStorage.setItem(key, value);
    }

    /**
     * @inheritdoc
     */
    protected getItem(key: string): string | null {
        return window.sessionStorage.getItem(key);
    }

    /**
     * @inheritdoc
     */
    protected removeItem(key: string): void {
        window.sessionStorage.removeItem(key);
    }
}
