/**
 * Regex expression to match ISO 8601 date format.
 */
const isoDateRegex =
    /^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2}):(\d{2}(?:\.\d*))(?:Z|(\+|-)([\d|:]*))?$/;

/**
 * {@link JSON.parse} reviver function to deserialize ISO 8601 date.
 * @param key - The key associated with the value.
 * @param value - The value produced by parsing.
 * @returns an instance of {@link Date} if value matches ISO 8601 date format, otherwise the parsed value.
 */
function dateReviver(key: string, value: unknown) {
    if (typeof value !== 'string' || !isoDateRegex.test(value)) {
        return value;
    }

    return new Date(value);
}

/**
 * Base class for access and management to storage.
 * It encodes the content saved to storage so that is not stored in plain text.
 * It also serializes the content into JSON format and back to javacripts object instances when deserializing.
 */
export abstract class BaseStorageService {
    /**
     * Set's a value on storage identified by a key.
     * @param key - The key on local storage.
     * @param value - The value to store on local storage.
     */
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    set(key: string, value: any) {
        this.setItem(btoa(key), btoa(JSON.stringify(value)));
    }

    /**
     * Get's a typed value from storage identified by a key.
     * @param key - The key on storage.
     * @returns Storage typed value.
     */
    get<T>(key: string) {
        let value = this.getItem(btoa(key));

        if (value) {
            value = JSON.parse(atob(value), dateReviver);
        }

        return value as T;
    }

    /**
     * Removes a value from storage identified by a key.
     * @param key - The key on storage.
     */
    remove(key: string): void {
        this.removeItem(btoa(key));
    }

    /**
     * Sets an item on dedicated storage.
     * @param key - The key on dedicated storage.
     * @param value - The value on dedicated storage.
     */
    protected abstract setItem(key: string, value: string): void;

    /**
     * Gets an item from dedicated storage.
     * @param key - The key on dedicated storage.
     * @returns The value on dedicated storage.
     */
    protected abstract getItem(key: string): string | null;

    /**
     * Removes an item from dedicated storage.
     * @param key - The key on dedicated storage.
     */
    protected abstract removeItem(key: string): void;
}
