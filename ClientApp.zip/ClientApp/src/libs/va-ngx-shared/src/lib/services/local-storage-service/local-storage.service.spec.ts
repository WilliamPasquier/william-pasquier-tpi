import { TestBed } from '@angular/core/testing';

import { LocalStorageService } from './local-storage.service';

describe('LocalStorageService', () => {
    let service: LocalStorageService;
    const testCases = [
        null,
        '',
        'string 1',
        new Date(2023, 1, 2, 3, 4, 5),
        10,
        20.1,
        ['string 1', 'string2'],
        {
            null: null,
            emptyString: '',
            string1: 'string 1',
            date: new Date(2023, 1, 2, 3, 4, 5),
            int: 10,
            decimal: 20.1,
            array: ['string 1', 'string2'],
            innerObj: {
                null: null,
                emptyString: '',
                string1: 'string 1',
                date: new Date(2023, 1, 2, 3, 4, 5),
                int: 10,
                decimal: 20.1,
                array: ['string 1', 'string2'],
            },
        },
    ];

    beforeEach(() => {
        TestBed.configureTestingModule({});
        service = TestBed.inject(LocalStorageService);
    });

    it('should be created', () => {
        expect(service).toBeTruthy();
        window.localStorage.clear();
    });

    testCases.forEach((value, index) => {
        it(`should set item with value ${value}`, () => {
            const key = `test-key-${index}`;
            service.set(key, value);

            const localStorageValue = window.localStorage.getItem(btoa(key));

            // eslint-disable-next-line @typescript-eslint/no-non-null-assertion
            const serializedValue = btoa(JSON.stringify(value));

            // eslint-disable-next-line @typescript-eslint/no-non-null-assertion
            expect(serializedValue).toEqual(localStorageValue!);
        });
    });

    testCases.forEach((value, index) => {
        it(`should get item with value ${value}`, () => {
            const key = `test-key-${index}`;
            service.set(key, value);

            // eslint-disable-next-line @typescript-eslint/no-explicit-any
            const localStorageValue = service.get(key);

            // eslint-disable-next-line @typescript-eslint/no-non-null-assertion
            expect(localStorageValue).toEqual(value);
        });
    });

    testCases.forEach((value, index) => {
        it(`should remove item with value ${value}`, () => {
            const key = `test-key-${index}`;
            service.set(key, value);
            service.remove(key);

            // eslint-disable-next-line @typescript-eslint/no-explicit-any
            const localStorageValue = service.get(key);

            expect(window.localStorage.getItem(key)).toBeNull();
            // eslint-disable-next-line @typescript-eslint/no-non-null-assertion
            expect(localStorageValue).toBeNull();
        });
    });
});
