// File for html helper functions

/**
 * Builds an id for HTML elements placed on Angular components.
 * @param componentId - Component id.
 * @param elementId - Element id.
 * @returns A unique identifier for HTML element inside a Angular component.
 */
export function buildComponentElementId(
    componentId: string,
    elementId: string,
): string {
    return `${componentId}_${elementId}`;
}
