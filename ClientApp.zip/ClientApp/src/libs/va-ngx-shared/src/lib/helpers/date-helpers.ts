import { subYears } from 'date-fns';
/**
 * Function to calculate the birth date for a specific age.
 * @param age - age for which we want the birthdate.
 * @returns the birthdate.
 */
export function dateYearsInThePast(age: number): Date {
    return subYears(new Date(), age);
}
