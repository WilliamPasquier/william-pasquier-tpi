import { buildComponentElementId } from './html-helpers';

describe('Html helpers', () => {
    it('should build component element id successfully', () => {
        expect(buildComponentElementId('component-1', 'element-1')).toBe(
            'component-1_element-1',
        );
    });
});
