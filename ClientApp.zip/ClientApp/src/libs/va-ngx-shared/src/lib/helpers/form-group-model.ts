import { FormArray, FormControl, FormGroup } from '@angular/forms';

type OptionalKeys<T> = {
    [K in keyof T]-?: Record<string, never> extends { [P in K]: T[K] }
        ? K
        : never;
}[keyof T];

/**
 * Create the model type from the FromGroup interface.
 */
export type FormGroupModel<T> = {
    [P in keyof Omit<T, OptionalKeys<T>>]: T[P] extends FormControl<infer U>
        ? null extends U
            ? U | null
            : U
        : T[P] extends FormGroup<infer U>
        ? FormGroupModel<U>
        : T[P] extends FormArray<FormGroup<infer U>>
        ? Array<FormGroupModel<U>>
        : T[P] extends FormArray<FormControl<infer U>>
        ? Array<U>
        : never;
} & {
    [P in keyof Pick<T, OptionalKeys<T>>]: T[P] extends
        | FormControl<infer U>
        | undefined
        ? null extends U
            ? U | null
            : U
        : T[P] extends FormGroup<infer U> | undefined
        ? FormGroupModel<U>
        : T[P] extends FormArray<FormGroup<infer U>> | undefined
        ? Array<FormGroupModel<U>>
        : never;
};
