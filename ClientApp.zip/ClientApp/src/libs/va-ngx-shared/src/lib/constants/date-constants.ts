export class DateConstants {
    /**
     * The default format used for the dates
     */
    static defaultDateDisplayFormat = 'dd.MM.yyyy';

    /**
     * The ISO8601ShortDate format used for the dates
     */
    static ISO8601ShortDateFormat = 'yyyy-MM-dd';

    /**
     * The default minimum date
     */
    static defaultMinDate = new Date('1920-01-01');
}
