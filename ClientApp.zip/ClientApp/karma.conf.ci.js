/* eslint-disable @typescript-eslint/no-var-requires */

const originalConfigFn = require('./karma.conf.js');
let properties;

originalConfigFn({
    set(arg) {
        properties = arg;
    },
});

// export settings
module.exports = function (config) {
    config.set({
        ...properties,
        // new settings here:
        colors: false,
        singleRun: true,
        autoWatch: false,
        browsers: ['ChromeHeadless'],
        customLaunchers: {
            ChromeHeadless: {
                base: 'Chrome',
                flags: [
                    '--headless',
                    '--disable-gpu',
                    '--no-sandbox',
                    '--remote-debugging-port=9222',
                ],
            },
        },
    });
};
